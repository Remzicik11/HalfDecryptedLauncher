// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

public interface e
{
    void h(final Object[] p0);
    
    void e(final Object[] p0);
    
    void i(final Object[] p0);
    
    void g(final Object[] p0);
    
    void a(final Object[] p0);
    
    void d(final Object[] p0);
    
    void b(final Object[] p0);
    
    void c(final Object[] p0);
    
    void f(final Object[] p0);
    
    void j(final Object[] p0);
}
