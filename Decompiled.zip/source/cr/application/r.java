// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.scene.layout.Pane;

public interface r
{
    void f(final Object[] p0);
    
    void b(final Object[] p0);
    
    void m(final Object[] p0);
    
    double b(final Object[] p0);
    
    double a(final Object[] p0);
    
    String a(final Object[] p0);
    
    Pane b(final Object[] p0);
    
    Pane a(final Object[] p0);
    
    void c(final Object[] p0);
    
    void j(final Object[] p0);
    
    void n(final Object[] p0);
    
    void d(final Object[] p0);
    
    void g(final Object[] p0);
    
    void i(final Object[] p0);
    
    void l(final Object[] p0);
    
    void k(final Object[] p0);
    
    void h(final Object[] p0);
    
    void e(final Object[] p0);
    
    void a(final Object[] p0);
}
