// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;

public class p
{
    public static void a(final Node p0, final EventHandler<Event> p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljavafx/scene/Node;
        //     7: astore_1       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljavafx/event/EventHandler;
        //    14: astore_2       
        //    15: pop            
        //    16: getstatic       cr/application/f.b:I
        //    19: aload_1        
        //    20: aload_2        
        //    21: iconst_2       
        //    22: anewarray       Ljava/lang/Object;
        //    25: dup_x1         
        //    26: swap           
        //    27: iconst_1       
        //    28: swap           
        //    29: aastore        
        //    30: dup_x1         
        //    31: swap           
        //    32: iconst_0       
        //    33: swap           
        //    34: aastore        
        //    35: invokestatic    cr/application/p.b:([Ljava/lang/Object;)V
        //    38: istore_3       
        //    39: aload_1        
        //    40: iload_3        
        //    41: ifne            59
        //    44: instanceof      Ljavafx/scene/Parent;
        //    47: ifeq            126
        //    50: goto            54
        //    53: athrow         
        //    54: aload_1        
        //    55: goto            59
        //    58: athrow         
        //    59: checkcast       Ljavafx/scene/Parent;
        //    62: astore          4
        //    64: aload           4
        //    66: invokevirtual   javafx/scene/Parent.getChildrenUnmodifiable:()Ljavafx/collections/ObservableList;
        //    69: astore          5
        //    71: aload           5
        //    73: invokeinterface javafx/collections/ObservableList.iterator:()Ljava/util/Iterator;
        //    78: astore          7
        //    80: iload_3        
        //    81: ifeq            116
        //    84: aload           7
        //    86: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    91: checkcast       Ljavafx/scene/Node;
        //    94: astore          6
        //    96: aload           6
        //    98: aload_2        
        //    99: iconst_2       
        //   100: anewarray       Ljava/lang/Object;
        //   103: dup_x1         
        //   104: swap           
        //   105: iconst_1       
        //   106: swap           
        //   107: aastore        
        //   108: dup_x1         
        //   109: swap           
        //   110: iconst_0       
        //   111: swap           
        //   112: aastore        
        //   113: invokestatic    cr/application/p.a:([Ljava/lang/Object;)V
        //   116: aload           7
        //   118: invokeinterface java/util/Iterator.hasNext:()Z
        //   123: ifne            84
        //   126: return         
        //    Signature:
        //  (Ljavafx/scene/Node;Ljavafx/event/EventHandler<Ljavafx/event/Event;>;)V
        //    StackMapTable: 00 07 FF 00 35 00 04 07 00 19 07 00 0B 07 00 0D 01 00 01 07 00 09 00 43 07 00 09 40 07 00 0B FF 00 18 00 08 07 00 19 07 00 0B 07 00 0D 01 07 00 17 07 00 1F 00 07 00 25 00 00 1F FF 00 09 00 04 07 00 19 07 00 0B 07 00 0D 01 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  39     50     53     54     Ljava/lang/IllegalStateException;
        //  44     55     58     59     Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.assembler.ir.StackMappingVisitor.push(StackMappingVisitor.java:290)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:833)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void b(final Node p0, final EventHandler<Event> p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljavafx/scene/Node;
        //     7: astore_2       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljavafx/event/EventHandler;
        //    14: astore_1       
        //    15: pop            
        //    16: aload_2        
        //    17: getstatic       javafx/scene/input/MouseEvent.MOUSE_MOVED:Ljavafx/event/EventType;
        //    20: aload_1        
        //    21: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    24: aload_2        
        //    25: getstatic       javafx/scene/input/MouseEvent.MOUSE_PRESSED:Ljavafx/event/EventType;
        //    28: aload_1        
        //    29: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    32: aload_2        
        //    33: getstatic       javafx/scene/input/MouseEvent.MOUSE_DRAGGED:Ljavafx/event/EventType;
        //    36: aload_1        
        //    37: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    40: aload_2        
        //    41: getstatic       javafx/scene/input/MouseEvent.MOUSE_EXITED:Ljavafx/event/EventType;
        //    44: aload_1        
        //    45: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    48: aload_2        
        //    49: getstatic       javafx/scene/input/MouseEvent.MOUSE_EXITED_TARGET:Ljavafx/event/EventType;
        //    52: aload_1        
        //    53: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    56: getstatic       cr/application/f.b:I
        //    59: aload_2        
        //    60: getstatic       javafx/scene/input/MouseEvent.MOUSE_CLICKED:Ljavafx/event/EventType;
        //    63: aload_1        
        //    64: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    67: aload_2        
        //    68: getstatic       javafx/scene/input/MouseEvent.MOUSE_ENTERED:Ljavafx/event/EventType;
        //    71: aload_1        
        //    72: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    75: istore_3       
        //    76: aload_2        
        //    77: getstatic       javafx/scene/input/MouseEvent.MOUSE_RELEASED:Ljavafx/event/EventType;
        //    80: aload_1        
        //    81: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    84: aload_2        
        //    85: getstatic       javafx/scene/input/KeyEvent.KEY_PRESSED:Ljavafx/event/EventType;
        //    88: aload_1        
        //    89: invokevirtual   javafx/scene/Node.addEventHandler:(Ljavafx/event/EventType;Ljavafx/event/EventHandler;)V
        //    92: iload_3        
        //    93: ifeq            109
        //    96: getstatic       cr/application/RiseApplication.b:I
        //    99: istore          4
        //   101: iinc            4, 1
        //   104: iload           4
        //   106: putstatic       cr/application/RiseApplication.b:I
        //   109: return         
        //    Signature:
        //  (Ljavafx/scene/Node;Ljavafx/event/EventHandler<Ljavafx/event/Event;>;)V
        //    StackMapTable: 00 01 FE 00 6D 07 00 0D 07 00 0B 01
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.assembler.ir.StackMappingVisitor.push(StackMappingVisitor.java:290)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:833)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
