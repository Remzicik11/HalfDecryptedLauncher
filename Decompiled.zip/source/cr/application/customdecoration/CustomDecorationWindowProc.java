// 
// Decompiled by Procyon v0.5.36
// 

package cr.application.customdecoration;

import javafx.stage.Stage;
import com.sun.jna.platform.win32.WinNT;
import com.sun.jna.NativeLibrary;
import java.lang.reflect.Method;
import com.sun.javafx.tk.TKStage;
import com.sun.jna.Pointer;
import javafx.stage.Window;
import com.sun.jna.platform.win32.WinDef;
import java.util.Map;
import com.sun.jna.Native;
import com.sun.jna.win32.W32APIOptions;
import cr.application.RiseApplication;
import com.sun.jna.platform.win32.BaseTSD;
import com.sun.jna.platform.win32.WinUser;

public class CustomDecorationWindowProc implements WinUser.WindowProc, CustomDecoration
{
    private User32Ex INSTANCE;
    private BaseTSD.LONG_PTR DEF_PROC;
    private RiseApplication app;
    private boolean is64Bit;
    public static int WS_CAPTION;
    
    static {
        CustomDecorationWindowProc.WS_CAPTION = 12582912;
    }
    
    public CustomDecorationWindowProc(final RiseApplication app) {
        this.app = app;
        this.is64Bit = this.setup64Bit();
        try {
            this.INSTANCE = Native.load("user32", User32Ex.class, W32APIOptions.DEFAULT_OPTIONS);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }
    
    public RiseApplication getApp() {
        return this.app;
    }
    
    public void fixMinimize(final WinDef.HWND hwnd) {
        this.setWindowLong(hwnd, -16, this.INSTANCE.GetWindowLong(hwnd, -16) | 0x20000);
    }
    
    private Pointer getWindowPointer(final Window window) {
        try {
            final TKStage impl_getPeer = window.impl_getPeer();
            final Method declaredMethod = impl_getPeer.getClass().getDeclaredMethod("getPlatformWindow", (Class<?>[])new Class[0]);
            declaredMethod.setAccessible(true);
            final Object invoke = declaredMethod.invoke(impl_getPeer, new Object[0]);
            final Method method = invoke.getClass().getMethod("getNativeHandle", (Class<?>[])new Class[0]);
            method.setAccessible(true);
            return new Pointer((long)method.invoke(invoke, new Object[0]));
        }
        catch (Throwable t) {
            System.err.println("Error getting Window Pointer");
            return null;
        }
    }
    
    public void hideWindow(final WinDef.HWND hwnd) {
        this.INSTANCE.ShowWindow(hwnd, 0);
    }
    
    public void showWindow(final WinDef.HWND hwnd) {
        this.INSTANCE.ShowWindow(hwnd, 5);
    }
    
    public void setWindowLong(final WinDef.HWND hwnd, final int n, final int n2) {
        this.INSTANCE.SetWindowLong(hwnd, n, n2);
    }
    
    public int getWindowLong(final WinDef.HWND hwnd, final int n) {
        return this.INSTANCE.GetWindowLong(hwnd, n);
    }
    
    private void setupWindowProc(final WinDef.HWND hwnd) {
        try {
            if (this.is64Bit()) {
                this.DEF_PROC = this.INSTANCE.SetWindowLongPtr(hwnd, -4, this);
                return;
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        this.DEF_PROC = this.INSTANCE.SetWindowLong(hwnd, -4, this);
    }
    
    private void setupFrameArea(final WinDef.HWND p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ljava/lang/Object;
        //     4: invokestatic    invokestatic   !!! ERROR
        //     7: ifeq            26
        //    10: aload_0        
        //    11: invokevirtual   cr/application/customdecoration/CustomDecorationWindowProc.is64Bit:()Z
        //    14: ifne            26
        //    17: goto            21
        //    20: athrow         
        //    21: iconst_1       
        //    22: goto            27
        //    25: athrow         
        //    26: iconst_0       
        //    27: istore_2       
        //    28: iconst_0       
        //    29: anewarray       Ljava/lang/Object;
        //    32: invokestatic    invokestatic   !!! ERROR
        //    35: ifeq            53
        //    38: new             Lcr/application/customdecoration/MARGINS;
        //    41: dup            
        //    42: iconst_0       
        //    43: iconst_0       
        //    44: iconst_0       
        //    45: iconst_0       
        //    46: invokespecial   cr/application/customdecoration/MARGINS.<init>:(IIII)V
        //    49: goto            64
        //    52: athrow         
        //    53: new             Lcr/application/customdecoration/MARGINS;
        //    56: dup            
        //    57: iconst_0       
        //    58: iconst_0       
        //    59: iconst_1       
        //    60: iconst_0       
        //    61: invokespecial   cr/application/customdecoration/MARGINS.<init>:(IIII)V
        //    64: astore_3       
        //    65: iload_2        
        //    66: ifeq            81
        //    69: new             Lcr/application/customdecoration/MARGINS;
        //    72: dup            
        //    73: iconst_m1      
        //    74: iconst_m1      
        //    75: iconst_m1      
        //    76: iconst_m1      
        //    77: invokespecial   cr/application/customdecoration/MARGINS.<init>:(IIII)V
        //    80: astore_3       
        //    81: aload_0        
        //    82: aload_1        
        //    83: aload_3        
        //    84: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.setupFrameArea:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcr/application/customdecoration/MARGINS;)V
        //    87: return         
        //    StackMapTable: 00 09 54 07 00 BC 00 43 07 00 BC 00 40 01 FF 00 18 00 03 07 00 02 07 00 0F 01 00 01 07 00 BC 00 4A 07 00 D2 FC 00 10 07 00 D2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  0      17     20     21     Ljava/lang/IllegalStateException;
        //  10     25     25     26     Ljava/lang/IllegalStateException;
        //  28     52     52     53     Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferBinaryExpression(TypeAnalysis.java:2104)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1531)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:778)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1551)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void setupFrameArea(final WinDef.HWND hwnd, final MARGINS margins) {
        NativeLibrary.getInstance("dwmapi").getFunction("DwmExtendFrameIntoClientArea").invoke(WinNT.HRESULT.class, new Object[] { hwnd, margins });
    }
    
    private boolean isProvideVersion() {
        return true;
    }
    
    private void onShowPopup(final Window p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.isProvideVersion:()Z
        //     4: ifne            9
        //     7: return         
        //     8: athrow         
        //     9: iconst_0       
        //    10: anewarray       Ljava/lang/Object;
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: ifeq            35
        //    19: aload_0        
        //    20: invokevirtual   cr/application/customdecoration/CustomDecorationWindowProc.is64Bit:()Z
        //    23: ifne            35
        //    26: goto            30
        //    29: athrow         
        //    30: iconst_1       
        //    31: goto            36
        //    34: athrow         
        //    35: iconst_0       
        //    36: istore_2       
        //    37: new             Lcom/sun/jna/platform/win32/WinDef$HWND;
        //    40: dup            
        //    41: aload_0        
        //    42: aload_1        
        //    43: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.getWindowPointer:(Ljavafx/stage/Window;)Lcom/sun/jna/Pointer;
        //    46: invokespecial   com/sun/jna/platform/win32/WinDef$HWND.<init>:(Lcom/sun/jna/Pointer;)V
        //    49: astore_3       
        //    50: aload_0        
        //    51: aload_3        
        //    52: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.setupWindowProc:(Lcom/sun/jna/platform/win32/WinDef$HWND;)V
        //    55: iload_2        
        //    56: ifeq            104
        //    59: aload_0        
        //    60: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    63: aload_3        
        //    64: iconst_0       
        //    65: invokeinterface cr/application/customdecoration/User32Ex.ShowWindow:(Lcom/sun/jna/platform/win32/WinDef$HWND;I)Z
        //    70: pop            
        //    71: aload_0        
        //    72: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    75: aload_3        
        //    76: bipush          -20
        //    78: ldc             524288
        //    80: invokeinterface cr/application/customdecoration/User32Ex.SetWindowLong:(Lcom/sun/jna/platform/win32/WinDef$HWND;II)I
        //    85: pop            
        //    86: aload_0        
        //    87: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    90: aload_3        
        //    91: iconst_0       
        //    92: iconst_0       
        //    93: iconst_1       
        //    94: invokeinterface cr/application/customdecoration/User32Ex.SetLayeredWindowAttributes:(Lcom/sun/jna/platform/win32/WinDef$HWND;IBI)Z
        //    99: pop            
        //   100: goto            104
        //   103: athrow         
        //   104: getstatic       cr/application/customdecoration/CustomDecorationWindowProc.WS_CAPTION:I
        //   107: ldc             524288
        //   109: ior            
        //   110: ldc             262144
        //   112: ior            
        //   113: ldc             131072
        //   115: ior            
        //   116: ldc_w           65536
        //   119: ior            
        //   120: istore          4
        //   122: aload_0        
        //   123: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //   126: aload_3        
        //   127: bipush          -16
        //   129: iload           4
        //   131: invokeinterface cr/application/customdecoration/User32Ex.SetWindowLong:(Lcom/sun/jna/platform/win32/WinDef$HWND;II)I
        //   136: pop            
        //   137: aload_0        
        //   138: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //   141: aload_3        
        //   142: iconst_5       
        //   143: invokeinterface cr/application/customdecoration/User32Ex.ShowWindow:(Lcom/sun/jna/platform/win32/WinDef$HWND;I)Z
        //   148: pop            
        //   149: new             Ljava/util/Timer;
        //   152: dup            
        //   153: iconst_1       
        //   154: invokespecial   java/util/Timer.<init>:(Z)V
        //   157: astore          5
        //   159: aload           5
        //   161: new             Lcr/application/customdecoration/CustomDecorationWindowProc$1;
        //   164: dup            
        //   165: aload_0        
        //   166: aload_3        
        //   167: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc$1.<init>:(Lcr/application/customdecoration/CustomDecorationWindowProc;Lcom/sun/jna/platform/win32/WinDef$HWND;)V
        //   170: ldc2_w          30
        //   173: invokevirtual   java/util/Timer.schedule:(Ljava/util/TimerTask;J)V
        //   176: return         
        //    StackMapTable: 00 09 48 07 00 BC 00 53 07 00 BC 00 43 07 00 BC 00 40 01 FF 00 42 00 04 07 00 02 07 00 76 01 07 00 0F 00 01 07 00 BC 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  0      8      8      9      Ljava/lang/IllegalStateException;
        //  9      26     29     30     Ljava/lang/IllegalStateException;
        //  19     34     34     35     Ljava/lang/IllegalStateException;
        //  50     100    103    104    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferBinaryExpression(TypeAnalysis.java:2104)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1531)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:778)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1551)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void onShowMainWindow(final Stage p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.isProvideVersion:()Z
        //     4: ifne            9
        //     7: return         
        //     8: athrow         
        //     9: iconst_0       
        //    10: anewarray       Ljava/lang/Object;
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: ifeq            35
        //    19: aload_0        
        //    20: invokevirtual   cr/application/customdecoration/CustomDecorationWindowProc.is64Bit:()Z
        //    23: ifne            35
        //    26: goto            30
        //    29: athrow         
        //    30: iconst_1       
        //    31: goto            36
        //    34: athrow         
        //    35: iconst_0       
        //    36: istore_2       
        //    37: new             Lcom/sun/jna/platform/win32/WinDef$HWND;
        //    40: dup            
        //    41: aload_0        
        //    42: aload_1        
        //    43: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.getWindowPointer:(Ljavafx/stage/Window;)Lcom/sun/jna/Pointer;
        //    46: invokespecial   com/sun/jna/platform/win32/WinDef$HWND.<init>:(Lcom/sun/jna/Pointer;)V
        //    49: astore_3       
        //    50: aload_0        
        //    51: aload_3        
        //    52: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc.setupWindowProc:(Lcom/sun/jna/platform/win32/WinDef$HWND;)V
        //    55: iload_2        
        //    56: ifeq            104
        //    59: aload_0        
        //    60: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    63: aload_3        
        //    64: iconst_0       
        //    65: invokeinterface cr/application/customdecoration/User32Ex.ShowWindow:(Lcom/sun/jna/platform/win32/WinDef$HWND;I)Z
        //    70: pop            
        //    71: aload_0        
        //    72: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    75: aload_3        
        //    76: bipush          -20
        //    78: ldc             524288
        //    80: invokeinterface cr/application/customdecoration/User32Ex.SetWindowLong:(Lcom/sun/jna/platform/win32/WinDef$HWND;II)I
        //    85: pop            
        //    86: aload_0        
        //    87: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //    90: aload_3        
        //    91: iconst_0       
        //    92: iconst_0       
        //    93: iconst_1       
        //    94: invokeinterface cr/application/customdecoration/User32Ex.SetLayeredWindowAttributes:(Lcom/sun/jna/platform/win32/WinDef$HWND;IBI)Z
        //    99: pop            
        //   100: goto            104
        //   103: athrow         
        //   104: ldc_w           13565952
        //   107: istore          4
        //   109: aload_0        
        //   110: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //   113: aload_3        
        //   114: bipush          -16
        //   116: iload           4
        //   118: invokeinterface cr/application/customdecoration/User32Ex.SetWindowLong:(Lcom/sun/jna/platform/win32/WinDef$HWND;II)I
        //   123: pop            
        //   124: aload_0        
        //   125: getfield        cr/application/customdecoration/CustomDecorationWindowProc.INSTANCE:Lcr/application/customdecoration/User32Ex;
        //   128: aload_3        
        //   129: iconst_5       
        //   130: invokeinterface cr/application/customdecoration/User32Ex.ShowWindow:(Lcom/sun/jna/platform/win32/WinDef$HWND;I)Z
        //   135: pop            
        //   136: new             Ljava/util/Timer;
        //   139: dup            
        //   140: iconst_1       
        //   141: invokespecial   java/util/Timer.<init>:(Z)V
        //   144: astore          5
        //   146: aload           5
        //   148: new             Lcr/application/customdecoration/CustomDecorationWindowProc$2;
        //   151: dup            
        //   152: aload_0        
        //   153: aload_3        
        //   154: invokespecial   cr/application/customdecoration/CustomDecorationWindowProc$2.<init>:(Lcr/application/customdecoration/CustomDecorationWindowProc;Lcom/sun/jna/platform/win32/WinDef$HWND;)V
        //   157: ldc2_w          80
        //   160: invokevirtual   java/util/Timer.schedule:(Ljava/util/TimerTask;J)V
        //   163: return         
        //    StackMapTable: 00 09 48 07 00 BC 00 53 07 00 BC 00 43 07 00 BC 00 40 01 FF 00 42 00 04 07 00 02 07 01 11 01 07 00 0F 00 01 07 00 BC 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  0      8      8      9      Ljava/lang/IllegalStateException;
        //  9      26     29     30     Ljava/lang/IllegalStateException;
        //  19     34     34     35     Ljava/lang/IllegalStateException;
        //  50     100    103    104    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferBinaryExpression(TypeAnalysis.java:2104)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1531)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:778)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1551)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final boolean setup64Bit() {
        final String property = System.getProperty("sun.arch.data.model", System.getProperty("com.ibm.vm.bitmode"));
        try {
            if (property != null) {
                return "64".equals(property);
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        return false;
    }
    
    public boolean is64Bit() {
        return this.is64Bit;
    }
    
    @Override
    public void onPreShow(final Stage stage, final boolean b) {
    }
    
    @Override
    public void onShow(final Stage stage, final boolean b) {
        try {
            if (b) {
                this.onShowPopup((Window)stage);
                return;
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        this.onShowMainWindow(stage);
    }
    
    public void printByte(final int n) {
        final byte[] array;
        final int length = (array = new byte[] { (byte)n }).length;
        int n2 = 0;
        while (true) {
            try {
                if (n2 >= length) {
                    return;
                }
            }
            catch (IllegalStateException ex) {
                throw ex;
            }
            System.out.format("0x%x ", array[n2]);
            ++n2;
        }
    }
    
    @Override
    public WinDef.LRESULT callback(final WinDef.HWND hwnd, final int n, final WinDef.WPARAM wparam, final WinDef.LPARAM lparam) {
        Label_0099: {
            try {
                switch (n) {
                    case 131: {
                        return new WinDef.LRESULT(0L);
                    }
                    case 132: {
                        break;
                    }
                    case 2: {
                        break Label_0099;
                    }
                    default: {
                        return this.INSTANCE.CallWindowProc(this.DEF_PROC, hwnd, n, wparam, lparam);
                    }
                }
            }
            catch (IllegalStateException ex) {
                throw ex;
            }
            final WinDef.LRESULT borderLessHitTest = this.BorderLessHitTest(hwnd, n, wparam, lparam);
            try {
                if (borderLessHitTest.intValue() == new WinDef.LRESULT(0L).intValue()) {
                    return this.INSTANCE.CallWindowProc(this.DEF_PROC, hwnd, n, wparam, lparam);
                }
            }
            catch (IllegalStateException ex2) {
                throw ex2;
            }
            return borderLessHitTest;
            try {
                if (this.is64Bit()) {
                    this.INSTANCE.SetWindowLongPtr(hwnd, -4, this.DEF_PROC);
                    return new WinDef.LRESULT(0L);
                }
            }
            catch (IllegalStateException ex3) {
                throw ex3;
            }
        }
        this.INSTANCE.SetWindowLong(hwnd, -4, this.DEF_PROC);
        return new WinDef.LRESULT(0L);
    }
    
    public WinDef.LRESULT BorderLessHitTest(final WinDef.HWND p0, final int p1, final WinDef.WPARAM p2, final WinDef.LPARAM p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore          5
        //     3: iconst_0       
        //     4: istore          6
        //     6: new             Lcom/sun/jna/platform/win32/WinDef$POINT;
        //     9: dup            
        //    10: invokespecial   com/sun/jna/platform/win32/WinDef$POINT.<init>:()V
        //    13: astore          7
        //    15: new             Lcom/sun/jna/platform/win32/WinDef$RECT;
        //    18: dup            
        //    19: invokespecial   com/sun/jna/platform/win32/WinDef$RECT.<init>:()V
        //    22: astore          8
        //    24: getstatic       com/sun/jna/platform/win32/User32.INSTANCE:Lcom/sun/jna/platform/win32/User32;
        //    27: aload           7
        //    29: invokeinterface com/sun/jna/platform/win32/User32.GetCursorPos:(Lcom/sun/jna/platform/win32/WinDef$POINT;)Z
        //    34: pop            
        //    35: getstatic       com/sun/jna/platform/win32/User32.INSTANCE:Lcom/sun/jna/platform/win32/User32;
        //    38: aload_1        
        //    39: aload           8
        //    41: invokeinterface com/sun/jna/platform/win32/User32.GetWindowRect:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcom/sun/jna/platform/win32/WinDef$RECT;)Z
        //    46: pop            
        //    47: iconst_1       
        //    48: istore          9
        //    50: iconst_1       
        //    51: istore          10
        //    53: iconst_0       
        //    54: istore          11
        //    56: iconst_0       
        //    57: istore          12
        //    59: iload           6
        //    61: istore          13
        //    63: aload           7
        //    65: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //    68: aload           8
        //    70: getfield        com/sun/jna/platform/win32/WinDef$RECT.top:I
        //    73: if_icmplt       206
        //    76: aload           7
        //    78: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //    81: aload           8
        //    83: getfield        com/sun/jna/platform/win32/WinDef$RECT.top:I
        //    86: iload           13
        //    88: iadd           
        //    89: iload           5
        //    91: iadd           
        //    92: if_icmpge       206
        //    95: goto            99
        //    98: athrow         
        //    99: aload           7
        //   101: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //   104: aload           8
        //   106: getfield        com/sun/jna/platform/win32/WinDef$RECT.top:I
        //   109: iload           6
        //   111: iadd           
        //   112: if_icmpge       124
        //   115: goto            119
        //   118: athrow         
        //   119: iconst_1       
        //   120: goto            125
        //   123: athrow         
        //   124: iconst_0       
        //   125: istore          11
        //   127: iload           11
        //   129: ifne            200
        //   132: aload           7
        //   134: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //   137: aload           8
        //   139: getfield        com/sun/jna/platform/win32/WinDef$RECT.top:I
        //   142: iload           5
        //   144: iadd           
        //   145: if_icmpgt       197
        //   148: goto            152
        //   151: athrow         
        //   152: aload           7
        //   154: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   157: aload           8
        //   159: getfield        com/sun/jna/platform/win32/WinDef$RECT.right:I
        //   162: iload           5
        //   164: isub           
        //   165: if_icmpge       197
        //   168: goto            172
        //   171: athrow         
        //   172: aload           7
        //   174: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   177: aload           8
        //   179: getfield        com/sun/jna/platform/win32/WinDef$RECT.left:I
        //   182: iload           5
        //   184: iadd           
        //   185: if_icmple       197
        //   188: goto            192
        //   191: athrow         
        //   192: iconst_1       
        //   193: goto            198
        //   196: athrow         
        //   197: iconst_0       
        //   198: istore          12
        //   200: iconst_0       
        //   201: istore          9
        //   203: goto            242
        //   206: aload           7
        //   208: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //   211: aload           8
        //   213: getfield        com/sun/jna/platform/win32/WinDef$RECT.bottom:I
        //   216: if_icmpge       242
        //   219: aload           7
        //   221: getfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //   224: aload           8
        //   226: getfield        com/sun/jna/platform/win32/WinDef$RECT.bottom:I
        //   229: iload           6
        //   231: isub           
        //   232: if_icmplt       242
        //   235: goto            239
        //   238: athrow         
        //   239: iconst_2       
        //   240: istore          9
        //   242: aload           7
        //   244: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   247: aload           8
        //   249: getfield        com/sun/jna/platform/win32/WinDef$RECT.left:I
        //   252: if_icmplt       281
        //   255: aload           7
        //   257: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   260: aload           8
        //   262: getfield        com/sun/jna/platform/win32/WinDef$RECT.left:I
        //   265: iload           6
        //   267: iadd           
        //   268: if_icmpge       281
        //   271: goto            275
        //   274: athrow         
        //   275: iconst_0       
        //   276: istore          10
        //   278: goto            317
        //   281: aload           7
        //   283: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   286: aload           8
        //   288: getfield        com/sun/jna/platform/win32/WinDef$RECT.right:I
        //   291: if_icmpge       317
        //   294: aload           7
        //   296: getfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   299: aload           8
        //   301: getfield        com/sun/jna/platform/win32/WinDef$RECT.right:I
        //   304: iload           6
        //   306: isub           
        //   307: if_icmplt       317
        //   310: goto            314
        //   313: athrow         
        //   314: iconst_2       
        //   315: istore          10
        //   317: bipush          13
        //   319: istore          14
        //   321: bipush          12
        //   323: istore          15
        //   325: iconst_2       
        //   326: istore          16
        //   328: bipush          14
        //   330: istore          17
        //   332: bipush          10
        //   334: istore          18
        //   336: iconst_0       
        //   337: istore          19
        //   339: bipush          11
        //   341: istore          20
        //   343: bipush          16
        //   345: istore          21
        //   347: bipush          15
        //   349: istore          22
        //   351: bipush          17
        //   353: istore          23
        //   355: iconst_3       
        //   356: istore          24
        //   358: iconst_3       
        //   359: anewarray       [I
        //   362: dup            
        //   363: iconst_0       
        //   364: iconst_3       
        //   365: newarray        I
        //   367: dup            
        //   368: iconst_0       
        //   369: bipush          13
        //   371: iastore        
        //   372: dup            
        //   373: iconst_1       
        //   374: iload           11
        //   376: ifeq            385
        //   379: bipush          12
        //   381: goto            396
        //   384: athrow         
        //   385: iload           12
        //   387: ifeq            395
        //   390: iconst_2       
        //   391: goto            396
        //   394: athrow         
        //   395: iconst_0       
        //   396: iastore        
        //   397: dup            
        //   398: iconst_2       
        //   399: bipush          14
        //   401: iastore        
        //   402: aastore        
        //   403: dup            
        //   404: iconst_1       
        //   405: iconst_3       
        //   406: newarray        I
        //   408: dup            
        //   409: iconst_0       
        //   410: bipush          10
        //   412: iastore        
        //   413: dup            
        //   414: iconst_2       
        //   415: bipush          11
        //   417: iastore        
        //   418: aastore        
        //   419: dup            
        //   420: iconst_2       
        //   421: iconst_3       
        //   422: newarray        I
        //   424: dup            
        //   425: iconst_0       
        //   426: bipush          16
        //   428: iastore        
        //   429: dup            
        //   430: iconst_1       
        //   431: bipush          15
        //   433: iastore        
        //   434: dup            
        //   435: iconst_2       
        //   436: bipush          17
        //   438: iastore        
        //   439: aastore        
        //   440: astore          25
        //   442: new             Lcom/sun/jna/platform/win32/WinDef$LRESULT;
        //   445: dup            
        //   446: aload           25
        //   448: iload           9
        //   450: aaload         
        //   451: iload           10
        //   453: iaload         
        //   454: i2l            
        //   455: invokespecial   com/sun/jna/platform/win32/WinDef$LRESULT.<init>:(J)V
        //   458: areturn        
        //   459: astore          5
        //   461: aconst_null    
        //   462: areturn        
        //    StackMapTable: 00 21 FF 00 62 00 0E 07 00 02 07 00 0F 01 07 00 20 07 00 14 01 01 07 00 1A 07 00 1D 01 01 01 01 01 00 01 07 00 40 00 52 07 00 40 00 43 07 00 40 00 40 01 59 07 00 40 00 52 07 00 40 00 52 07 00 40 00 43 07 00 40 00 40 01 01 05 5F 07 00 40 00 02 5F 07 00 40 00 05 5F 07 00 40 00 02 FF 00 42 00 19 07 00 02 07 00 0F 01 07 00 20 07 00 14 01 01 07 00 1A 07 00 1D 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 00 01 07 00 40 FF 00 00 00 19 07 00 02 07 00 0F 01 07 00 20 07 00 14 01 01 07 00 1A 07 00 1D 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 00 06 07 01 7E 07 01 7E 01 07 01 7C 07 01 7C 01 48 07 00 40 FF 00 00 00 19 07 00 02 07 00 0F 01 07 00 20 07 00 14 01 01 07 00 1A 07 00 1D 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 00 06 07 01 7E 07 01 7E 01 07 01 7C 07 01 7C 01 FF 00 00 00 19 07 00 02 07 00 0F 01 07 00 20 07 00 14 01 01 07 00 1A 07 00 1D 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 00 07 07 01 7E 07 01 7E 01 07 01 7C 07 01 7C 01 01 FF 00 3E 00 05 07 00 02 07 00 0F 01 07 00 20 07 00 14 00 01 07 00 40
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  385    394    394    395    Ljava/lang/Throwable;
        //  358    384    384    385    Ljava/lang/Throwable;
        //  281    310    313    314    Ljava/lang/Throwable;
        //  242    271    274    275    Ljava/lang/Throwable;
        //  206    235    238    239    Ljava/lang/Throwable;
        //  172    196    196    197    Ljava/lang/Throwable;
        //  152    188    191    192    Ljava/lang/Throwable;
        //  132    168    171    172    Ljava/lang/Throwable;
        //  127    148    151    152    Ljava/lang/Throwable;
        //  99     123    123    124    Ljava/lang/Throwable;
        //  76     115    118    119    Ljava/lang/Throwable;
        //  63     95     98     99     Ljava/lang/Throwable;
        //  0      458    459    463    Ljava/lang/Throwable;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0099:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
