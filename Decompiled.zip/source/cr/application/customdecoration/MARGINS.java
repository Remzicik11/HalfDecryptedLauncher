// 
// Decompiled by Procyon v0.5.36
// 

package cr.application.customdecoration;

import java.util.Arrays;
import java.util.List;
import com.sun.jna.Structure;

public class MARGINS extends Structure implements ByReference
{
    public int cxLeftWidth;
    public int cxRightWidth;
    public int cyTopHeight;
    public int cyBottomHeight;
    
    public MARGINS(final int cxLeftWidth, final int cxRightWidth, final int cyTopHeight, final int cyBottomHeight) {
        this.cxLeftWidth = cxLeftWidth;
        this.cxRightWidth = cxRightWidth;
        this.cyTopHeight = cyTopHeight;
        this.cyBottomHeight = cyBottomHeight;
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList("cxLeftWidth", "cxRightWidth", "cyTopHeight", "cyBottomHeight");
    }
}
