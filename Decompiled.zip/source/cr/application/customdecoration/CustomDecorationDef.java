// 
// Decompiled by Procyon v0.5.36
// 

package cr.application.customdecoration;

import javafx.stage.Stage;

public class CustomDecorationDef implements CustomDecoration
{
    @Override
    public void onShow(final Stage stage, final boolean b) {
    }
    
    @Override
    public void onPreShow(final Stage stage, final boolean b) {
    }
}
