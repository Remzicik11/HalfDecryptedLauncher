// 
// Decompiled by Procyon v0.5.36
// 

package cr.application.customdecoration;

import com.sun.jna.platform.win32.BaseTSD;
import com.sun.jna.platform.win32.WinUser;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.User32;

interface User32Ex extends User32
{
    BaseTSD.LONG_PTR SetWindowLong(final WinDef.HWND p0, final int p1, final WinUser.WindowProc p2);
    
    BaseTSD.LONG_PTR SetWindowLong(final WinDef.HWND p0, final int p1, final BaseTSD.LONG_PTR p2);
    
    BaseTSD.LONG_PTR SetWindowLongPtr(final WinDef.HWND p0, final int p1, final WinUser.WindowProc p2);
    
    BaseTSD.LONG_PTR SetWindowLongPtr(final WinDef.HWND p0, final int p1, final BaseTSD.LONG_PTR p2);
    
    WinDef.LRESULT CallWindowProc(final BaseTSD.LONG_PTR p0, final WinDef.HWND p1, final int p2, final WinDef.WPARAM p3, final WinDef.LPARAM p4);
}
