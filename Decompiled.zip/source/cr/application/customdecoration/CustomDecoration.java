// 
// Decompiled by Procyon v0.5.36
// 

package cr.application.customdecoration;

import javafx.stage.Stage;

public interface CustomDecoration
{
    void onPreShow(final Stage p0, final boolean p1);
    
    void onShow(final Stage p0, final boolean p1);
}
