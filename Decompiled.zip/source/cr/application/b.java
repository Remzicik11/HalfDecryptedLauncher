// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

public class b
{
    public static void a(final Object[] array) {
        final boolean booleanValue = (boolean)array[0];
        final String s = (String)array[1];
        try {
            if (!booleanValue) {
                throw new IllegalStateException(s);
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
    }
}
