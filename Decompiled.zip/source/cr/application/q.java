// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import java.util.Map;
import java.lang.reflect.Field;

public class q
{
    private static final String a;
    
    public static void a(final Object[] array) {
        final Field obj = (Field)array[0];
        (long)array[1];
        obj.setAccessible(true);
        final Field declaredField = Field.class.getDeclaredField(q.a);
        declaredField.setAccessible(true);
        declaredField.setInt(obj, obj.getModifiers() & 0xFFFFFFEF);
    }
    
    public static Field a(final Class<?> p0, final String p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: dup            
        //    12: iconst_1       
        //    13: aaload         
        //    14: checkcast       Ljava/lang/Class;
        //    17: astore          4
        //    19: dup            
        //    20: iconst_2       
        //    21: aaload         
        //    22: checkcast       Ljava/lang/String;
        //    25: astore_1       
        //    26: pop            
        //    27: lload_2        
        //    28: dup2           
        //    29: ldc2_w          76175970186424
        //    32: lxor           
        //    33: lstore          5
        //    35: pop2           
        //    36: aconst_null    
        //    37: astore          7
        //    39: aload           4
        //    41: aload_1        
        //    42: invokevirtual   java/lang/Class.getDeclaredField:(Ljava/lang/String;)Ljava/lang/reflect/Field;
        //    45: astore          7
        //    47: goto            60
        //    50: astore          8
        //    52: aload           4
        //    54: aload_1        
        //    55: invokevirtual   java/lang/Class.getField:(Ljava/lang/String;)Ljava/lang/reflect/Field;
        //    58: astore          7
        //    60: aload           7
        //    62: lload           5
        //    64: iconst_2       
        //    65: anewarray       Ljava/lang/Object;
        //    68: dup_x2         
        //    69: dup_x2         
        //    70: pop            
        //    71: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    74: iconst_1       
        //    75: swap           
        //    76: aastore        
        //    77: dup_x1         
        //    78: swap           
        //    79: iconst_0       
        //    80: swap           
        //    81: aastore        
        //    82: invokestatic    cr/application/q.a:([Ljava/lang/Object;)V
        //    85: aload           7
        //    87: areturn        
        //    Signature:
        //  (Ljava/lang/Class<*>;Ljava/lang/String;)Ljava/lang/reflect/Field;
        //    StackMapTable: 00 02 FF 00 32 00 06 07 00 2D 07 00 29 04 07 00 17 04 07 00 09 00 01 07 00 27 09
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  39     47     50     60     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.assembler.ir.StackMappingVisitor.push(StackMappingVisitor.java:290)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:833)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static <V> Map<String, V> a(final Object p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Object;
        //     7: astore_1       
        //     8: pop            
        //     9: getstatic       cr/application/f.b:I
        //    12: new             Ljava/util/HashMap;
        //    15: dup            
        //    16: invokespecial   java/util/HashMap.<init>:()V
        //    19: astore_3       
        //    20: aload_1        
        //    21: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    24: astore          4
        //    26: istore_2       
        //    27: iload_2        
        //    28: ifeq            106
        //    31: aload           4
        //    33: invokevirtual   java/lang/Class.getDeclaredFields:()[Ljava/lang/reflect/Field;
        //    36: dup            
        //    37: astore          8
        //    39: arraylength    
        //    40: istore          7
        //    42: iconst_0       
        //    43: istore          6
        //    45: iload_2        
        //    46: ifeq            92
        //    49: aload           8
        //    51: iload           6
        //    53: aaload         
        //    54: astore          5
        //    56: aload           5
        //    58: iconst_1       
        //    59: invokevirtual   java/lang/reflect/Field.setAccessible:(Z)V
        //    62: aload           5
        //    64: aload_1        
        //    65: invokevirtual   java/lang/reflect/Field.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    68: astore          9
        //    70: aload_3        
        //    71: aload           5
        //    73: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //    76: aload           9
        //    78: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    83: pop            
        //    84: goto            89
        //    87: astore          9
        //    89: iinc            6, 1
        //    92: iload           6
        //    94: iload           7
        //    96: if_icmplt       49
        //    99: aload           4
        //   101: invokevirtual   java/lang/Class.getSuperclass:()Ljava/lang/Class;
        //   104: astore          4
        //   106: aload           4
        //   108: ifnonnull       31
        //   111: aload_3        
        //   112: areturn        
        //    Signature:
        //  <V:Ljava/lang/Object;>(Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;TV;>;
        //    StackMapTable: 00 06 FF 00 1F 00 05 07 00 2D 07 00 04 01 07 00 42 07 00 17 00 00 FF 00 11 00 09 07 00 2D 07 00 04 01 07 00 42 07 00 17 00 01 01 07 00 50 00 00 FF 00 25 00 09 07 00 2D 07 00 04 01 07 00 42 07 00 17 07 00 09 01 01 07 00 50 00 01 07 00 3A FC 00 01 07 00 04 FF 00 02 00 09 07 00 2D 07 00 04 01 07 00 42 07 00 17 00 01 01 07 00 50 00 00 FF 00 0D 00 05 07 00 2D 07 00 04 01 07 00 42 07 00 17 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                              
        //  -----  -----  -----  -----  ----------------------------------
        //  62     84     87     89     Ljava/lang/IllegalAccessException;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.assembler.ir.StackMappingVisitor.push(StackMappingVisitor.java:290)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:833)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final char[] charArray = "dph(qBl{l".toCharArray();
        int length;
        int n2;
        final int n = n2 = (length = charArray.length);
        int n3 = 0;
        while (true) {
            Label_0120: {
                if (n > 1) {
                    break Label_0120;
                }
                length = (n2 = n3);
                do {
                    final char c = charArray[n2];
                    char c2 = '\0';
                    switch (n3 % 7) {
                        case 0: {
                            c2 = '\t';
                            break;
                        }
                        case 1: {
                            c2 = '\u001f';
                            break;
                        }
                        case 2: {
                            c2 = '\f';
                            break;
                        }
                        case 3: {
                            c2 = 'A';
                            break;
                        }
                        case 4: {
                            c2 = '\u0017';
                            break;
                        }
                        case 5: {
                            c2 = '+';
                            break;
                        }
                        default: {
                            c2 = '\t';
                            break;
                        }
                    }
                    charArray[length] = (char)(c ^ c2);
                    ++n3;
                } while (n == 0);
            }
            if (n <= n3) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
