// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.stage.Stage;
import javafx.scene.input.MouseButton;
import java.util.Iterator;
import javafx.scene.AccessibleRole;
import javafx.event.EventType;
import javafx.scene.input.KeyEvent;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import java.util.ArrayList;
import javafx.scene.Node;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;

public class j implements EventHandler<Event>, e
{
    public RiseApplication c;
    public List<Node> d;
    public static boolean b;
    
    protected j(final RiseApplication c) {
        final boolean b = j.b;
        this.d = new ArrayList<Node>();
        final boolean b2 = b;
        boolean b4 = false;
        Label_0044: {
            Label_0038: {
                try {
                    this.c = c;
                    if (RiseApplication.b == 0) {
                        return;
                    }
                    final boolean b3 = b2;
                    if (b3) {
                        break Label_0038;
                    }
                    break Label_0038;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    final boolean b3 = b2;
                    if (b3) {
                        b4 = false;
                        break Label_0044;
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            b4 = true;
        }
        j.b = b4;
    }
    
    public RiseApplication a(final Object[] array) {
        return this.c;
    }
    
    public void i(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
        (long)array[2];
    }
    
    public void e(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final Parent parent = (Parent)array[1];
    }
    
    public void handle(final Event event) {
        final long n = 72178073095738L;
        final long l = n ^ 0x137BBD91BE3CL;
        final long i = n ^ 0x635336EED304L;
        final boolean b = j.b;
        Label_0077: {
            Label_0041: {
                boolean b2;
                try {
                    final boolean b3;
                    b2 = (b3 = (event instanceof MouseEvent));
                    if (b) {
                        break Label_0077;
                    }
                    if (b2) {
                        break Label_0041;
                    }
                    break Label_0041;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    if (b2) {
                        this.l(new Object[] { i, (MouseEvent)event });
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            boolean b3 = event instanceof KeyEvent;
            try {
                if (b3) {
                    this.k(new Object[] { (KeyEvent)event, l });
                }
            }
            catch (IllegalStateException ex3) {
                throw ex3;
            }
        }
    }
    
    public void k(final Object[] array) {
        final KeyEvent keyEvent = (KeyEvent)array[0];
        final long l = (long)array[1] ^ 0x52ACD92705C3L;
        final EventType eventType = keyEvent.getEventType();
        try {
            if (eventType.equals(KeyEvent.KEY_PRESSED)) {
                this.c.a().b(new Object[0]).d(new Object[] { l, keyEvent.getCode() });
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
    }
    
    public void l(final Object[] array) {
        final long longValue = (long)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
        final long n = longValue;
        final long l = n ^ 0x14B630DABBBL;
        final long i = n ^ 0x616789B8CBD2L;
        final long j = n ^ 0xCF27C77F3CEL;
        final long k = n ^ 0x16FE29125BE4L;
        final EventType eventType = mouseEvent.getEventType();
        final boolean b = cr.application.j.b;
        final boolean equals = eventType.equals(MouseEvent.MOUSE_MOVED);
        final boolean equals2 = eventType.equals(MouseEvent.MOUSE_EXITED);
        final boolean b2 = b;
        final boolean equals3 = eventType.equals(MouseEvent.MOUSE_EXITED_TARGET);
        final boolean equals4 = eventType.equals(MouseEvent.MOUSE_PRESSED);
        final boolean equals5 = eventType.equals(MouseEvent.MOUSE_DRAGGED);
        final boolean equals6 = eventType.equals(MouseEvent.MOUSE_RELEASED);
        final boolean equals7 = eventType.equals(MouseEvent.MOUSE_CLICKED);
        final boolean equals8 = eventType.equals(MouseEvent.MOUSE_ENTERED);
        final Object source = mouseEvent.getSource();
        Object o2 = null;
        Label_0167: {
            Label_0165: {
                Object o;
                try {
                    o = (o2 = source);
                    if (b2) {
                        break Label_0167;
                    }
                    final boolean b3 = o instanceof Node;
                    if (!b3) {
                        return;
                    }
                    break Label_0165;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    final boolean b3 = o instanceof Node;
                    if (!b3) {
                        return;
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            o2 = source;
        }
        final Node node = (Node)o2;
        Label_0693: {
            Label_0634: {
                boolean b10 = false;
                Label_0622: {
                    Label_0563: {
                        boolean b9 = false;
                        Label_0551: {
                            Label_0492: {
                                boolean b8 = false;
                                Label_0480: {
                                    Label_0421: {
                                        boolean b7 = false;
                                        Label_0409: {
                                            Label_0339: {
                                                boolean b6 = false;
                                                Label_0327: {
                                                    Label_0268: {
                                                        boolean b5 = false;
                                                        Label_0256: {
                                                            Label_0186: {
                                                                boolean b4;
                                                                try {
                                                                    final boolean b11;
                                                                    b4 = (b5 = (b6 = (b7 = (b8 = (b9 = (b10 = (b11 = equals8)))))));
                                                                    if (b2) {
                                                                        break Label_0256;
                                                                    }
                                                                    if (b4) {
                                                                        break Label_0186;
                                                                    }
                                                                    break Label_0186;
                                                                }
                                                                catch (IllegalStateException ex3) {
                                                                    throw ex3;
                                                                }
                                                                try {
                                                                    if (b4) {
                                                                        this.c.a().a(new Object[0]).i(new Object[] { j, node });
                                                                        this.g(new Object[] { this.c, mouseEvent });
                                                                    }
                                                                }
                                                                catch (IllegalStateException ex4) {
                                                                    throw ex4;
                                                                }
                                                            }
                                                            boolean b11;
                                                            b6 = (b5 = (b7 = (b8 = (b9 = (b10 = (b11 = equals))))));
                                                            try {
                                                                if (b2) {
                                                                    break Label_0327;
                                                                }
                                                                if (b5) {
                                                                    break Label_0268;
                                                                }
                                                                break Label_0268;
                                                            }
                                                            catch (IllegalStateException ex5) {
                                                                throw ex5;
                                                            }
                                                        }
                                                        try {
                                                            if (b5) {
                                                                this.c.a().a(new Object[0]).g(new Object[] { node });
                                                                this.a(new Object[] { this.c, mouseEvent });
                                                            }
                                                        }
                                                        catch (IllegalStateException ex6) {
                                                            throw ex6;
                                                        }
                                                    }
                                                    boolean b11;
                                                    b7 = (b6 = (b8 = (b9 = (b10 = (b11 = equals2)))));
                                                    try {
                                                        if (b2) {
                                                            break Label_0409;
                                                        }
                                                        if (b6) {
                                                            break Label_0339;
                                                        }
                                                        break Label_0339;
                                                    }
                                                    catch (IllegalStateException ex7) {
                                                        throw ex7;
                                                    }
                                                }
                                                try {
                                                    if (b6) {
                                                        this.c.a().a(new Object[0]).l(new Object[] { l, node });
                                                        this.d(new Object[] { this.c, mouseEvent });
                                                    }
                                                }
                                                catch (IllegalStateException ex8) {
                                                    throw ex8;
                                                }
                                            }
                                            boolean b11;
                                            b8 = (b7 = (b9 = (b10 = (b11 = equals3))));
                                            try {
                                                if (b2) {
                                                    break Label_0480;
                                                }
                                                if (b7) {
                                                    break Label_0421;
                                                }
                                                break Label_0421;
                                            }
                                            catch (IllegalStateException ex9) {
                                                throw ex9;
                                            }
                                        }
                                        try {
                                            if (b7) {
                                                this.c.a().a(new Object[0]).k(new Object[] { node });
                                                this.b(new Object[] { this.c, mouseEvent });
                                            }
                                        }
                                        catch (IllegalStateException ex10) {
                                            throw ex10;
                                        }
                                    }
                                    boolean b11;
                                    b9 = (b8 = (b10 = (b11 = equals4)));
                                    try {
                                        if (b2) {
                                            break Label_0551;
                                        }
                                        if (b8) {
                                            break Label_0492;
                                        }
                                        break Label_0492;
                                    }
                                    catch (IllegalStateException ex11) {
                                        throw ex11;
                                    }
                                }
                                try {
                                    if (b8) {
                                        this.c.a().a(new Object[0]).k(new Object[] { node });
                                        this.c(new Object[] { this.c, mouseEvent });
                                    }
                                }
                                catch (IllegalStateException ex12) {
                                    throw ex12;
                                }
                            }
                            boolean b11;
                            b10 = (b9 = (b11 = equals5));
                            try {
                                if (b2) {
                                    break Label_0622;
                                }
                                if (b9) {
                                    break Label_0563;
                                }
                                break Label_0563;
                            }
                            catch (IllegalStateException ex13) {
                                throw ex13;
                            }
                        }
                        try {
                            if (b9) {
                                this.c.a().a(new Object[0]).h(new Object[] { node });
                                this.f(new Object[] { this.c, mouseEvent });
                            }
                        }
                        catch (IllegalStateException ex14) {
                            throw ex14;
                        }
                    }
                    boolean b11 = b10 = equals6;
                    try {
                        if (b2) {
                            break Label_0693;
                        }
                        if (b10) {
                            break Label_0634;
                        }
                        break Label_0634;
                    }
                    catch (IllegalStateException ex15) {
                        throw ex15;
                    }
                }
                try {
                    if (b10) {
                        this.c.a().a(new Object[0]).e(new Object[] { node });
                        this.j(new Object[] { this.c, mouseEvent });
                    }
                }
                catch (IllegalStateException ex16) {
                    throw ex16;
                }
            }
            boolean b11 = equals7;
            try {
                if (b11) {
                    this.c.a().a(new Object[0]).a(new Object[] { node, i, mouseEvent });
                    this.i(new Object[] { this.c, mouseEvent, k });
                }
            }
            catch (IllegalStateException ex17) {
                throw ex17;
            }
        }
        if (b2) {
            int b12 = RiseApplication.b;
            RiseApplication.b = ++b12;
        }
    }
    
    public void g(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
    }
    
    public void a(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
    }
    
    public void d(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
    }
    
    public boolean a(final Object[] array) {
        final boolean b = j.b;
        Label_0030: {
            boolean empty;
            try {
                empty = this.d.isEmpty();
                if (!b && empty) {
                    return false;
                }
                break Label_0030;
            }
            catch (IllegalStateException ex) {
                throw ex;
            }
            try {
                if (empty) {
                    return false;
                }
            }
            catch (IllegalStateException ex2) {
                throw ex2;
            }
        }
        final Iterator<Node> iterator = this.d.iterator();
        boolean b2 = false;
        Label_0082: {
            if (!b) {
                break Label_0082;
            }
            while (true) {
                if (iterator.next().getAccessibleRole().equals((Object)AccessibleRole.PARENT)) {
                    break Label_0082;
                }
                b2 = false;
                if (b) {
                    return b2;
                }
                try {
                    if (b) {
                        if (iterator.hasNext()) {
                            continue;
                        }
                    }
                }
                catch (IllegalStateException ex3) {
                    throw ex3;
                }
                break;
            }
        }
        return b2;
    }
    
    public void c(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
        final boolean b = j.b;
        try {
            if (!riseApplication.c()) {
                return;
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        final MouseButton button = mouseEvent.getButton();
        Object source = null;
        Label_0062: {
            Label_0058: {
                MouseButton mouseButton;
                try {
                    mouseButton = (MouseButton)(source = button);
                    if (b) {
                        break Label_0062;
                    }
                    final MouseButton mouseButton2 = MouseButton.PRIMARY;
                    final boolean b2 = mouseButton.equals((Object)mouseButton2);
                    if (!b2) {
                        return;
                    }
                    break Label_0058;
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
                try {
                    final MouseButton mouseButton2 = MouseButton.PRIMARY;
                    final boolean b2 = mouseButton.equals((Object)mouseButton2);
                    if (!b2) {
                        return;
                    }
                }
                catch (IllegalStateException ex3) {
                    throw ex3;
                }
            }
            source = mouseEvent.getSource();
        }
        final Node node = (Node)source;
        Node node3 = null;
        Label_0085: {
            Label_0083: {
                Node node2;
                try {
                    node2 = (node3 = node);
                    if (b) {
                        break Label_0085;
                    }
                    final boolean b3 = node2 instanceof Node;
                    if (!b3) {
                        return;
                    }
                    break Label_0083;
                }
                catch (IllegalStateException ex4) {
                    throw ex4;
                }
                try {
                    final boolean b3 = node2 instanceof Node;
                    if (!b3) {
                        return;
                    }
                }
                catch (IllegalStateException ex5) {
                    throw ex5;
                }
            }
            node3 = node;
        }
        final Node node4 = node3;
        Label_0160: {
            Label_0149: {
                Label_0136: {
                    boolean equals = false;
                    Label_0125: {
                        try {
                            equals = node4.getScene().getWindow().equals(riseApplication.a().a(new Object[0]));
                            if (b) {
                                break Label_0136;
                            }
                            if (equals) {
                                break Label_0125;
                            }
                        }
                        catch (IllegalStateException ex6) {
                            throw ex6;
                        }
                        return;
                    }
                    this.d.contains(node4);
                    try {
                        if (b) {
                            break Label_0160;
                        }
                        if (!equals) {
                            break Label_0149;
                        }
                    }
                    catch (IllegalStateException ex7) {
                        throw ex7;
                    }
                }
                return;
            }
            this.d.add(node4);
        }
        final g a = riseApplication.a();
        a.f = mouseEvent.getSceneX();
        a.e = mouseEvent.getSceneY();
    }
    
    public void f(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
        final boolean b = j.b;
        try {
            if (!riseApplication.c()) {
                return;
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        final MouseButton button = mouseEvent.getButton();
        Object source = null;
        Label_0062: {
            Label_0058: {
                MouseButton mouseButton;
                try {
                    mouseButton = (MouseButton)(source = button);
                    if (b) {
                        break Label_0062;
                    }
                    final MouseButton mouseButton2 = MouseButton.PRIMARY;
                    final boolean b2 = mouseButton.equals((Object)mouseButton2);
                    if (!b2) {
                        return;
                    }
                    break Label_0058;
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
                try {
                    final MouseButton mouseButton2 = MouseButton.PRIMARY;
                    final boolean b2 = mouseButton.equals((Object)mouseButton2);
                    if (!b2) {
                        return;
                    }
                }
                catch (IllegalStateException ex3) {
                    throw ex3;
                }
            }
            source = mouseEvent.getSource();
        }
        final Object o = source;
        Object o3 = null;
        Label_0085: {
            Label_0083: {
                Object o2;
                try {
                    o2 = (o3 = o);
                    if (b) {
                        break Label_0085;
                    }
                    final boolean b3 = o2 instanceof Node;
                    if (!b3) {
                        return;
                    }
                    break Label_0083;
                }
                catch (IllegalStateException ex4) {
                    throw ex4;
                }
                try {
                    final boolean b3 = o2 instanceof Node;
                    if (!b3) {
                        return;
                    }
                }
                catch (IllegalStateException ex5) {
                    throw ex5;
                }
            }
            o3 = o;
        }
        final Node node = (Node)o3;
        final AccessibleRole accessibleRole = node.getAccessibleRole();
        boolean b5 = false;
        Label_0166: {
            Label_0144: {
                Label_0131: {
                    boolean b4 = false;
                    Label_0123: {
                        try {
                            b4 = (b5 = this.a(new Object[0]).a(accessibleRole));
                            if (b) {
                                break Label_0131;
                            }
                            if (b4) {
                                break Label_0123;
                            }
                        }
                        catch (IllegalStateException ex6) {
                            throw ex6;
                        }
                        return;
                    }
                    final boolean a;
                    b5 = (a = this.a(new Object[0]));
                    try {
                        if (b) {
                            break Label_0166;
                        }
                        if (b4) {
                            break Label_0144;
                        }
                    }
                    catch (IllegalStateException ex7) {
                        throw ex7;
                    }
                }
                return;
            }
            b5 = node.getScene().getWindow().equals(riseApplication.a().a(new Object[0]));
        }
        if (!b5) {
            return;
        }
        final g a2 = riseApplication.a();
        final int n = (int)((int)mouseEvent.getScreenX() - a2.f);
        final int n2 = (int)((int)mouseEvent.getScreenY() - a2.e);
        a2.a(new Object[0]).setX((double)n);
        a2.a(new Object[0]).setY((double)n2);
    }
    
    public void j(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
        this.d.clear();
    }
    
    public void b(final Object[] array) {
        final RiseApplication riseApplication = (RiseApplication)array[0];
        final MouseEvent mouseEvent = (MouseEvent)array[1];
    }
    
    public void h(final Object[] array) {
        this.c.a().onShow((Stage)array[0], (boolean)array[1]);
    }
}
