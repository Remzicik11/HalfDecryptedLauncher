// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.scene.Node;
import javafx.scene.layout.StackPane;

public class d extends StackPane
{
    public static boolean b;
    
    public d a(final Object[] array) {
        final Node node = (Node)array[0];
        final boolean b = d.b;
        this.getChildren().add((Object)node);
        if (b) {
            int b2 = RiseApplication.b;
            RiseApplication.b = ++b2;
        }
        return this;
    }
}
