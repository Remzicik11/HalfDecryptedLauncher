// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.stage.Stage;

public class g
{
    public RiseApplication b;
    private Stage a;
    private r c;
    public double f;
    public double e;
    public static boolean d;
    
    public g(final RiseApplication b, final Stage a, final r c) {
        final boolean d = g.d;
        this.f = 0.0;
        this.e = 0.0;
        final boolean b2 = d;
        this.b = b;
        this.c = c;
        this.a = a;
        if (b2) {
            int b3 = RiseApplication.b;
            RiseApplication.b = ++b3;
        }
    }
    
    public RiseApplication a(final Object[] array) {
        return this.b;
    }
    
    public Stage a(final Object[] array) {
        return this.a;
    }
    
    public r b(final Object[] array) {
        return this.c;
    }
    
    public r a(final Object[] array) {
        return this.c;
    }
    
    public void d(final Object[] array) {
        this.a(new Object[] { (String)array[1], (long)array[0] ^ 0x56A77B6EA883L, (o)array[2], Boolean.valueOf((boolean)array[3]), false });
    }
    
    public void a(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/String;
        //     7: astore_2       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljava/lang/Long;
        //    14: invokevirtual   java/lang/Long.longValue:()J
        //    17: lstore          4
        //    19: dup            
        //    20: iconst_2       
        //    21: aaload         
        //    22: checkcast       Lcr/application/o;
        //    25: astore          7
        //    27: dup            
        //    28: iconst_3       
        //    29: aaload         
        //    30: checkcast       Ljava/lang/Boolean;
        //    33: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //    36: istore_3       
        //    37: dup            
        //    38: iconst_4       
        //    39: aaload         
        //    40: checkcast       Ljava/lang/Boolean;
        //    43: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //    46: istore          6
        //    48: pop            
        //    49: lload           4
        //    51: dup2           
        //    52: ldc2_w          89057891723636
        //    55: lxor           
        //    56: lstore          8
        //    58: dup2           
        //    59: ldc2_w          66779416383109
        //    62: lxor           
        //    63: lstore          10
        //    65: pop2           
        //    66: getstatic       cr/application/g.d:Z
        //    69: istore          12
        //    71: aload_0        
        //    72: iload           12
        //    74: ifne            110
        //    77: aload_2        
        //    78: aload           7
        //    80: iload_3        
        //    81: iload           6
        //    83: invokedynamic   BootstrapMethod #0, run:(Lcr/application/g;Ljava/lang/String;Lcr/application/o;ZZ)Ljava/lang/Runnable;
        //    88: iconst_1       
        //    89: anewarray       Ljava/lang/Object;
        //    92: dup_x1         
        //    93: swap           
        //    94: iconst_0       
        //    95: swap           
        //    96: aastore        
        //    97: invokestatic    cr/application/n.a:([Ljava/lang/Object;)Z
        //   100: ifeq            109
        //   103: goto            107
        //   106: athrow         
        //   107: return         
        //   108: athrow         
        //   109: aload_0        
        //   110: iconst_0       
        //   111: anewarray       Ljava/lang/Object;
        //   114: invokevirtual   cr/application/g.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //   117: aload_2        
        //   118: invokevirtual   cr/application/RiseApplication.a:(Ljava/lang/String;)Lcr/application/r;
        //   121: astore          13
        //   123: aload           13
        //   125: iload           12
        //   127: ifne            146
        //   130: ifnonnull       138
        //   133: goto            137
        //   136: athrow         
        //   137: return         
        //   138: aload_0        
        //   139: iconst_0       
        //   140: anewarray       Ljava/lang/Object;
        //   143: invokevirtual   cr/application/g.b:([Ljava/lang/Object;)Lcr/application/r;
        //   146: astore          14
        //   148: aload           14
        //   150: iload           12
        //   152: ifne            227
        //   155: ifnull          203
        //   158: goto            162
        //   161: athrow         
        //   162: iload_3        
        //   163: iload           12
        //   165: ifne            199
        //   168: goto            172
        //   171: athrow         
        //   172: ifne            203
        //   175: goto            179
        //   178: athrow         
        //   179: aload           14
        //   181: iload           12
        //   183: ifne            227
        //   186: goto            190
        //   189: athrow         
        //   190: aload           13
        //   192: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   195: goto            199
        //   198: athrow         
        //   199: ifeq            203
        //   202: return         
        //   203: aload           13
        //   205: lload           10
        //   207: iconst_1       
        //   208: anewarray       Ljava/lang/Object;
        //   211: dup_x2         
        //   212: dup_x2         
        //   213: pop            
        //   214: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   217: iconst_0       
        //   218: swap           
        //   219: aastore        
        //   220: invokeinterface cr/application/r.j:([Ljava/lang/Object;)V
        //   225: aload           14
        //   227: iload           12
        //   229: ifne            241
        //   232: ifnull          261
        //   235: goto            239
        //   238: athrow         
        //   239: aload           14
        //   241: lload           8
        //   243: iconst_1       
        //   244: anewarray       Ljava/lang/Object;
        //   247: dup_x2         
        //   248: dup_x2         
        //   249: pop            
        //   250: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   253: iconst_0       
        //   254: swap           
        //   255: aastore        
        //   256: invokeinterface cr/application/r.c:([Ljava/lang/Object;)V
        //   261: aload           7
        //   263: getstatic       cr/application/o.HIDE_WAIT_SHOW:Lcr/application/o;
        //   266: invokevirtual   cr/application/o.equals:(Ljava/lang/Object;)Z
        //   269: istore          15
        //   271: iload           15
        //   273: iload           12
        //   275: ifne            362
        //   278: ifeq            310
        //   281: goto            285
        //   284: athrow         
        //   285: aload_0        
        //   286: iconst_0       
        //   287: anewarray       Ljava/lang/Object;
        //   290: invokevirtual   cr/application/g.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //   293: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //   296: invokevirtual   cr/application/RisePopup.b:()V
        //   299: aload_0        
        //   300: getfield        cr/application/g.a:Ljavafx/stage/Stage;
        //   303: invokevirtual   javafx/stage/Stage.hide:()V
        //   306: goto            310
        //   309: athrow         
        //   310: aload           13
        //   312: iconst_1       
        //   313: iconst_1       
        //   314: anewarray       Ljava/lang/Object;
        //   317: dup_x1         
        //   318: swap           
        //   319: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //   322: iconst_0       
        //   323: swap           
        //   324: aastore        
        //   325: invokeinterface cr/application/r.m:([Ljava/lang/Object;)V
        //   330: aload_0        
        //   331: getfield        cr/application/g.b:Lcr/application/RiseApplication;
        //   334: aload_0        
        //   335: getfield        cr/application/g.a:Ljavafx/stage/Stage;
        //   338: aload           13
        //   340: iload           6
        //   342: invokevirtual   cr/application/RiseApplication.a:(Ljavafx/stage/Stage;Lcr/application/r;Z)V
        //   345: aload_0        
        //   346: aload           13
        //   348: putfield        cr/application/g.c:Lcr/application/r;
        //   351: iload           12
        //   353: ifne            416
        //   356: iload           15
        //   358: goto            362
        //   361: athrow         
        //   362: ifeq            383
        //   365: aload_0        
        //   366: getfield        cr/application/g.a:Ljavafx/stage/Stage;
        //   369: invokevirtual   javafx/stage/Stage.toFront:()V
        //   372: aload_0        
        //   373: getfield        cr/application/g.a:Ljavafx/stage/Stage;
        //   376: invokevirtual   javafx/stage/Stage.show:()V
        //   379: goto            383
        //   382: athrow         
        //   383: aload           14
        //   385: iconst_0       
        //   386: iconst_1       
        //   387: anewarray       Ljava/lang/Object;
        //   390: dup_x1         
        //   391: swap           
        //   392: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //   395: iconst_0       
        //   396: swap           
        //   397: aastore        
        //   398: invokeinterface cr/application/r.m:([Ljava/lang/Object;)V
        //   403: aload_0        
        //   404: getfield        cr/application/g.c:Lcr/application/r;
        //   407: iconst_0       
        //   408: anewarray       Ljava/lang/Object;
        //   411: invokeinterface cr/application/r.n:([Ljava/lang/Object;)V
        //   416: getstatic       cr/application/RiseApplication.b:I
        //   419: ifeq            440
        //   422: iload           12
        //   424: ifeq            436
        //   427: goto            431
        //   430: athrow         
        //   431: iconst_0       
        //   432: goto            437
        //   435: athrow         
        //   436: iconst_1       
        //   437: putstatic       cr/application/g.d:Z
        //   440: return         
        //    StackMapTable: 00 28 FF 00 6A 00 0A 07 00 02 07 00 6B 07 00 3A 01 04 01 07 00 3C 04 04 01 00 01 07 00 4F 00 40 07 00 4F 00 40 07 00 02 FF 00 19 00 0B 07 00 02 07 00 6B 07 00 3A 01 04 01 07 00 3C 04 04 01 07 00 2E 00 01 07 00 4F 00 00 47 07 00 2E FF 00 0E 00 0C 07 00 02 07 00 6B 07 00 3A 01 04 01 07 00 3C 04 04 01 07 00 2E 07 00 2E 00 01 07 00 4F 00 48 07 00 4F 40 01 45 07 00 4F 00 49 07 00 4F 40 07 00 2E 47 07 00 4F 40 01 03 57 07 00 2E 4A 07 00 4F 00 41 07 00 2E 13 FF 00 16 00 0D 07 00 02 07 00 6B 07 00 3A 01 04 01 07 00 3C 04 04 01 07 00 2E 07 00 2E 01 00 01 07 00 4F 00 57 07 00 4F 00 72 07 00 4F 40 01 53 07 00 4F 00 20 4D 07 00 4F 00 43 07 00 4F 00 40 01 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  71     103    106    107    Ljava/lang/IllegalStateException;
        //  77     108    108    109    Ljava/lang/IllegalStateException;
        //  123    133    136    137    Ljava/lang/IllegalStateException;
        //  148    158    161    162    Ljava/lang/IllegalStateException;
        //  155    168    171    172    Ljava/lang/IllegalStateException;
        //  162    175    178    179    Ljava/lang/IllegalStateException;
        //  172    186    189    190    Ljava/lang/IllegalStateException;
        //  179    195    198    199    Ljava/lang/IllegalStateException;
        //  227    235    238    239    Ljava/lang/IllegalStateException;
        //  271    281    284    285    Ljava/lang/IllegalStateException;
        //  278    306    309    310    Ljava/lang/IllegalStateException;
        //  310    358    361    362    Ljava/lang/IllegalStateException;
        //  362    379    382    383    Ljava/lang/IllegalStateException;
        //  416    427    430    431    Ljava/lang/IllegalStateException;
        //  422    435    435    436    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0162:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final Object[] array) {
        this.d(new Object[] { (long)array[1] ^ 0x10EF28A480D7L, (String)array[0], o.CHANGE, false });
    }
    
    public void b(final Object[] array) {
        this.a(new Object[] { (String)array[0], ((long)(int)array[1] << 48 | (long)(int)array[2] << 32 >>> 16 | (long)(int)array[3] << 48 >>> 48) ^ 0x288D5C2110EAL, o.CHANGE, false, Boolean.valueOf((boolean)array[4]) });
    }
}
