// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.stage.Stage;

public interface i
{
    void b(final Stage p0);
    
    void a(final Stage p0);
}
