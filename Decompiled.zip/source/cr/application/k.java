// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyCode;
import java.util.Map;
import java.util.Iterator;
import javafx.scene.Node;
import javafx.scene.layout.Pane;

public abstract class k implements r
{
    public RiseApplication b;
    public Pane c;
    public boolean a;
    public static int d;
    private static final String w;
    
    public k(final RiseApplication b) {
        this.b = b;
    }
    
    @Override
    public void b(final Object[] array) {
        final int d = k.d;
        p.b(new Object[] { this.c, this.a(new Object[0]).a() });
        int n = d;
        final Iterator iterator = this.c.getChildrenUnmodifiable().iterator();
        while (true) {
            Label_0100: {
                if (n == 0) {
                    break Label_0100;
                }
                p.a(new Object[] { iterator.next(), this.a(new Object[0]).a() });
            }
            if (!iterator.hasNext()) {
                try {
                    if (RiseApplication.b != 0) {
                        k.d = ++n;
                    }
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                return;
            }
            continue;
        }
    }
    
    @Override
    public void f(final Object[] array) {
        (long)array[0];
    }
    
    @Override
    public void m(final Object[] array) {
        this.c.setVisible((boolean)array[0]);
    }
    
    public RiseApplication a(final Object[] array) {
        return this.b;
    }
    
    @Override
    public double b(final Object[] array) {
        return this.c.getPrefWidth();
    }
    
    @Override
    public double a(final Object[] array) {
        return this.c.getPrefHeight();
    }
    
    public Pane c(final Object[] array) {
        return this.c = this.a(new Object[0]).a().a(this.a(new Object[] { (long)array[0] ^ 0x3459FC9A13FEL }));
    }
    
    @Override
    public Pane b(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          47174325037782
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          101645412482657
        //    24: lxor           
        //    25: lstore          6
        //    27: dup2           
        //    28: ldc2_w          33802944051496
        //    31: lxor           
        //    32: lstore          8
        //    34: pop2           
        //    35: getstatic       cr/application/k.d:I
        //    38: istore          10
        //    40: aload_0        
        //    41: getfield        cr/application/k.c:Ljavafx/scene/layout/Pane;
        //    44: iload           10
        //    46: ifne            158
        //    49: ifnonnull       154
        //    52: goto            56
        //    55: athrow         
        //    56: aload_0        
        //    57: aload_0        
        //    58: lload           8
        //    60: iconst_1       
        //    61: anewarray       Ljava/lang/Object;
        //    64: dup_x2         
        //    65: dup_x2         
        //    66: pop            
        //    67: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    70: iconst_0       
        //    71: swap           
        //    72: aastore        
        //    73: invokevirtual   cr/application/k.c:([Ljava/lang/Object;)Ljavafx/scene/layout/Pane;
        //    76: putfield        cr/application/k.c:Ljavafx/scene/layout/Pane;
        //    79: aload_0        
        //    80: getfield        cr/application/k.c:Ljavafx/scene/layout/Pane;
        //    83: invokevirtual   javafx/scene/layout/Pane.getId:()Ljava/lang/String;
        //    86: ifnull          98
        //    89: goto            93
        //    92: athrow         
        //    93: iconst_1       
        //    94: goto            99
        //    97: athrow         
        //    98: iconst_0       
        //    99: new             Ljava/lang/StringBuilder;
        //   102: dup            
        //   103: getstatic       cr/application/k.w:Ljava/lang/String;
        //   106: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   109: aload_0        
        //   110: lload           4
        //   112: iconst_1       
        //   113: anewarray       Ljava/lang/Object;
        //   116: dup_x2         
        //   117: dup_x2         
        //   118: pop            
        //   119: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   122: iconst_0       
        //   123: swap           
        //   124: aastore        
        //   125: invokevirtual   cr/application/k.a:([Ljava/lang/Object;)Ljava/lang/String;
        //   128: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   131: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   134: iconst_2       
        //   135: anewarray       Ljava/lang/Object;
        //   138: dup_x1         
        //   139: swap           
        //   140: iconst_1       
        //   141: swap           
        //   142: aastore        
        //   143: dup_x1         
        //   144: swap           
        //   145: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //   148: iconst_0       
        //   149: swap           
        //   150: aastore        
        //   151: invokestatic    cr/application/b.a:([Ljava/lang/Object;)V
        //   154: aload_0        
        //   155: getfield        cr/application/k.c:Ljavafx/scene/layout/Pane;
        //   158: iload           10
        //   160: ifne            197
        //   163: ifnull          193
        //   166: goto            170
        //   169: athrow         
        //   170: aload_0        
        //   171: lload           6
        //   173: iconst_1       
        //   174: anewarray       Ljava/lang/Object;
        //   177: dup_x2         
        //   178: dup_x2         
        //   179: pop            
        //   180: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   183: iconst_0       
        //   184: swap           
        //   185: aastore        
        //   186: invokevirtual   cr/application/k.o:([Ljava/lang/Object;)V
        //   189: goto            193
        //   192: athrow         
        //   193: aload_0        
        //   194: getfield        cr/application/k.c:Ljavafx/scene/layout/Pane;
        //   197: areturn        
        //    StackMapTable: 00 0E FF 00 37 00 07 07 00 02 07 00 3D 04 04 04 04 01 00 01 07 00 1F 00 63 07 00 1F 00 43 07 00 1F 00 40 01 36 43 07 00 31 4A 07 00 1F 00 55 07 00 1F 00 43 07 00 31
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  40     52     55     56     Ljava/lang/IllegalStateException;
        //  49     89     92     93     Ljava/lang/IllegalStateException;
        //  56     97     97     98     Ljava/lang/IllegalStateException;
        //  158    166    169    170    Ljava/lang/IllegalStateException;
        //  163    189    192    193    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0056:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean a(final Object[] array) {
        return this.a;
    }
    
    public void r(final Object[] array) {
        this.a = (boolean)array[0];
    }
    
    public void o(final Object[] array) {
        final long longValue = (long)array[0];
        final long l = longValue ^ 0x6AD04746DF2CL;
        final long i = longValue ^ 0x1CE3A275AFDCL;
        final int d = k.d;
        k k = null;
        Label_0101: {
            Label_0055: {
                try {
                    k = this;
                    if (d != 0) {
                        break Label_0101;
                    }
                    final int n = 0;
                    final Object[] array2 = new Object[n];
                    final boolean b = this.a(array2);
                    if (b) {
                        return;
                    }
                    break Label_0055;
                }
                catch (Exception ex) {
                    throw ex;
                }
                try {
                    final int n = 0;
                    final Object[] array2 = new Object[n];
                    final boolean b = this.a(array2);
                    if (b) {
                        return;
                    }
                }
                catch (Exception ex2) {
                    throw ex2;
                }
            }
            this.r(new Object[] { true });
            this.c.getStylesheets().clear();
            this.c.setVisible(true);
            this.q(new Object[0]);
            k = this;
        }
        final Iterator<Map.Entry<String, V>> iterator = q.a(new Object[] { k }).entrySet().iterator();
        while (true) {
            Label_0130: {
                if (d != 0) {
                    break Label_0130;
                }
                while (!iterator.hasNext()) {
                    this.p(new Object[] { l });
                    this.b(new Object[0]);
                    if (d == 0) {
                        return;
                    }
                }
            }
            final Map.Entry<String, V> entry = iterator.next();
            try {
                final String str = entry.getKey();
                if (entry.getValue() == null || d != 0) {
                    final Node lookup = this.c.lookup("#" + str);
                    if (lookup != null || d != 0) {
                        q.a(new Object[] { i, this.getClass(), str }).set(this, lookup);
                    }
                }
            }
            catch (Exception ex3) {
                ex3.printStackTrace();
            }
            continue;
        }
    }
    
    public void q(final Object[] array) {
    }
    
    @Override
    public void j(final Object[] array) {
        (long)array[0];
    }
    
    @Override
    public void n(final Object[] array) {
    }
    
    @Override
    public void c(final Object[] array) {
        this.p(new Object[] { (long)array[0] ^ 0x4A1449D1B6EAL });
    }
    
    public void p(final Object[] array) {
        (long)array[0];
    }
    
    @Override
    public Pane a(final Object[] array) {
        return this.b(new Object[] { (long)array[0] ^ 0xCA48A58029L });
    }
    
    @Override
    public abstract String a(final Object[] p0);
    
    @Override
    public void d(final Object[] array) {
        (long)array[0];
        final KeyCode keyCode = (KeyCode)array[1];
    }
    
    @Override
    public void e(final Object[] array) {
        final Node node = (Node)array[0];
    }
    
    @Override
    public void g(final Object[] array) {
        final Node node = (Node)array[0];
    }
    
    @Override
    public void i(final Object[] array) {
        (long)array[0];
        final Node node = (Node)array[1];
    }
    
    @Override
    public void l(final Object[] array) {
        (long)array[0];
        final Node node = (Node)array[1];
    }
    
    @Override
    public void a(final Object[] array) {
        final Node node = (Node)array[0];
        (long)array[1];
        final MouseEvent mouseEvent = (MouseEvent)array[2];
    }
    
    @Override
    public void h(final Object[] array) {
        final Node node = (Node)array[0];
    }
    
    @Override
    public void k(final Object[] array) {
        final Node node = (Node)array[0];
    }
    
    static {
        final char[] charArray = "kgn\u000eEs(Rb<\u0005Ds(Yc<\u0005^kd\u0001&".toCharArray();
        int length;
        int n2;
        final int n = n2 = (length = charArray.length);
        int n3 = 0;
        while (true) {
            Label_0120: {
                if (n > 1) {
                    break Label_0120;
                }
                length = (n2 = n3);
                do {
                    final char c = charArray[n2];
                    char c2 = '\0';
                    switch (n3 % 7) {
                        case 0: {
                            c2 = ';';
                            break;
                        }
                        case 1: {
                            c2 = '\u0006';
                            break;
                        }
                        case 2: {
                            c2 = '\u001c';
                            break;
                        }
                        case 3: {
                            c2 = 'k';
                            break;
                        }
                        case 4: {
                            c2 = '+';
                            break;
                        }
                        case 5: {
                            c2 = '\u0007';
                            break;
                        }
                        default: {
                            c2 = '\b';
                            break;
                        }
                    }
                    charArray[length] = (char)(c ^ c2);
                    ++n3;
                } while (n == 0);
            }
            if (n <= n3) {
                w = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
