// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.application.Platform;

public class n
{
    public static int b;
    
    public static boolean a(final Object[] array) {
        final Runnable runnable = (Runnable)array[0];
        final int b = n.b;
        try {
            if (runnable == null) {
                return false;
            }
        }
        catch (IllegalStateException ex) {
            throw ex;
        }
        Label_0037: {
            boolean b2;
            try {
                final boolean fxApplicationThread;
                b2 = (fxApplicationThread = Platform.isFxApplicationThread());
                if (b != 0) {
                    return fxApplicationThread;
                }
                if (b2) {
                    return false;
                }
                break Label_0037;
            }
            catch (IllegalStateException ex2) {
                throw ex2;
            }
            try {
                if (b2) {
                    return false;
                }
            }
            catch (IllegalStateException ex3) {
                throw ex3;
            }
        }
        Platform.runLater(runnable);
        return true;
    }
}
