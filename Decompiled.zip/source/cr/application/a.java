// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

public enum a
{
    CONFIRM(array2[0], 0), 
    YES_NO(array2[1], 1);
    
    static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "VV\u0004\u0014d;D\u0006L\\\u0019\rc&").length();
        int char1 = 7;
        int index = -1;
        Label_0028: {
            break Label_0028;
            do {
                char1 = s.charAt(index);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                int length2;
                int n3;
                final int n2 = n3 = (length2 = charArray.length);
                int n4 = 0;
                while (true) {
                    Label_0192: {
                        if (n2 > 1) {
                            break Label_0192;
                        }
                        length2 = (n3 = n4);
                        do {
                            final char c = charArray[n3];
                            char c2 = '\0';
                            switch (n4 % 7) {
                                case 0: {
                                    c2 = '\u0015';
                                    break;
                                }
                                case 1: {
                                    c2 = '\u0019';
                                    break;
                                }
                                case 2: {
                                    c2 = 'J';
                                    break;
                                }
                                case 3: {
                                    c2 = 'R';
                                    break;
                                }
                                case 4: {
                                    c2 = '-';
                                    break;
                                }
                                case 5: {
                                    c2 = 'i';
                                    break;
                                }
                                default: {
                                    c2 = '\t';
                                    break;
                                }
                            }
                            charArray[length2] = (char)(c ^ c2);
                            ++n4;
                        } while (n2 == 0);
                    }
                    if (n2 > n4) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        a = new a[] { cr.application.a.CONFIRM, cr.application.a.YES_NO };
    }
    
    private a(final String name, final int ordinal) {
    }
}
