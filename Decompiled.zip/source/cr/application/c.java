// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

import javafx.scene.image.PixelWriter;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.image.Image;

public class c
{
    public static boolean b;
    private static final String a;
    
    public static Image a(final Object[] array) {
        (long)array[0];
        final Image image = (Image)array[1];
        final Color color = (Color)array[2];
        final boolean b = c.b;
        final PixelReader pixelReader = image.getPixelReader();
        final WritableImage writableImage = new WritableImage((int)image.getWidth(), (int)image.getHeight());
        final PixelWriter pixelWriter = writableImage.getPixelWriter();
        final boolean b2 = b;
        int n = 0;
        while (true) {
            Label_0178: {
                if (!b2) {
                    break Label_0178;
                }
                int b3 = RiseApplication.b;
                RiseApplication.b = ++b3;
                int n2 = 0;
                while (true) {
                    Label_0164: {
                        if (!b2) {
                            break Label_0164;
                        }
                        final Color color2 = pixelReader.getColor(n2, n);
                        if (!c.a.equals(color2.toString())) {
                            pixelWriter.setColor(n2, n, new Color(color.getRed(), color.getGreen(), color.getBlue(), color2.getOpacity()));
                        }
                        ++n2;
                    }
                    if (n2 < image.getWidth()) {
                        continue;
                    }
                    break;
                }
                ++n;
            }
            if (n >= image.getHeight()) {
                return (Image)writableImage;
            }
            continue;
        }
    }
    
    static {
        final char[] charArray = "ATzyn\u001aRA\u001cz".toCharArray();
        int length;
        int n2;
        final int n = n2 = (length = charArray.length);
        int n3 = 0;
        while (true) {
            Label_0120: {
                if (n > 1) {
                    break Label_0120;
                }
                length = (n2 = n3);
                do {
                    final char c = charArray[n2];
                    char c2 = '\0';
                    switch (n3 % 7) {
                        case 0: {
                            c2 = 'q';
                            break;
                        }
                        case 1: {
                            c2 = ',';
                            break;
                        }
                        case 2: {
                            c2 = 'J';
                            break;
                        }
                        case 3: {
                            c2 = 'I';
                            break;
                        }
                        case 4: {
                            c2 = '^';
                            break;
                        }
                        case 5: {
                            c2 = '*';
                            break;
                        }
                        default: {
                            c2 = 'b';
                            break;
                        }
                    }
                    charArray[length] = (char)(c ^ c2);
                    ++n3;
                } while (n == 0);
            }
            if (n <= n3) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
