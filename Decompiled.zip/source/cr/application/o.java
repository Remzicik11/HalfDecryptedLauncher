// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

public enum o
{
    CHANGE(array2[0], 0), 
    HIDE_WAIT_SHOW(array2[1], 1);
    
    static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "<\f^X\u0012{\u000e7\r[S\nig6\u0010@E\u001dqq").length();
        int char1 = 6;
        int index = -1;
        Label_0028: {
            break Label_0028;
            do {
                char1 = s.charAt(index);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                int length2;
                int n3;
                final int n2 = n3 = (length2 = charArray.length);
                int n4 = 0;
                while (true) {
                    Label_0192: {
                        if (n2 > 1) {
                            break Label_0192;
                        }
                        length2 = (n3 = n4);
                        do {
                            final char c = charArray[n3];
                            char c2 = '\0';
                            switch (n4 % 7) {
                                case 0: {
                                    c2 = '\u007f';
                                    break;
                                }
                                case 1: {
                                    c2 = 'D';
                                    break;
                                }
                                case 2: {
                                    c2 = '\u001f';
                                    break;
                                }
                                case 3: {
                                    c2 = '\u0016';
                                    break;
                                }
                                case 4: {
                                    c2 = 'U';
                                    break;
                                }
                                case 5: {
                                    c2 = '>';
                                    break;
                                }
                                default: {
                                    c2 = '&';
                                    break;
                                }
                            }
                            charArray[length2] = (char)(c ^ c2);
                            ++n4;
                        } while (n2 == 0);
                    }
                    if (n2 > n4) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        a = new o[] { o.CHANGE, o.HIDE_WAIT_SHOW };
    }
    
    private o(final String name, final int ordinal) {
    }
}
