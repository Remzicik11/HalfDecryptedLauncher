// 
// Decompiled by Procyon v0.5.36
// 

package cr.application;

public class h
{
    public String c;
    public String d;
    public static boolean b;
    
    public h(final String c, final String d) {
        final boolean b = h.b;
        final boolean b2 = b;
        boolean b4 = false;
        Label_0038: {
            Label_0032: {
                try {
                    this.c = c;
                    this.d = d;
                    if (RiseApplication.b == 0) {
                        return;
                    }
                    final boolean b3 = b2;
                    if (b3) {
                        break Label_0032;
                    }
                    break Label_0032;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    final boolean b3 = b2;
                    if (b3) {
                        b4 = false;
                        break Label_0038;
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            b4 = true;
        }
        h.b = b4;
    }
    
    public void a(final Object[] array) {
        this.c = (String)array[0];
    }
    
    public String a(final Object[] array) {
        final boolean b = h.b;
        final String string = String.valueOf(this.c) + "/" + this.d;
        final boolean b2 = b;
        final String s = string;
        if (b2) {
            int b3 = RiseApplication.b;
            RiseApplication.b = ++b3;
        }
        return s;
    }
}
