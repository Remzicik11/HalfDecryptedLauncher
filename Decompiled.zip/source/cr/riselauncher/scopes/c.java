// 
// Decompiled by Procyon v0.5.36
// 

package cr.riselauncher.scopes;

import cr.application.n;
import javafx.scene.layout.Pane;
import cr.application.RiseApplication;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;
import cr.application.k;

public class c extends k
{
    public ImageView a;
    public Text d;
    public ProgressBar h;
    public double f;
    public Button i;
    public Button g;
    public StackPane e;
    public static boolean j;
    private static final String[] k;
    private static final String[] l;
    
    public c(final RiseApplication riseApplication) {
        super(riseApplication);
        this.f = 0.0;
    }
    
    @Override
    public Pane c(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: iconst_0       
        //    13: anewarray       Ljava/lang/Object;
        //    16: invokestatic    invokestatic   !!! ERROR
        //    19: astore          4
        //    21: aload_0        
        //    22: new             Ljavafx/scene/layout/AnchorPane;
        //    25: dup            
        //    26: invokespecial   javafx/scene/layout/AnchorPane.<init>:()V
        //    29: putfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    32: aload_0        
        //    33: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    36: ldc2_w          -1.0
        //    39: invokevirtual   javafx/scene/layout/Pane.setMinHeight:(D)V
        //    42: aload_0        
        //    43: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    46: ldc2_w          400.0
        //    49: invokevirtual   javafx/scene/layout/Pane.setPrefHeight:(D)V
        //    52: aload_0        
        //    53: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    56: ldc2_w          -1.0
        //    59: invokevirtual   javafx/scene/layout/Pane.setMaxHeight:(D)V
        //    62: aload_0        
        //    63: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    66: ldc2_w          400.0
        //    69: invokevirtual   javafx/scene/layout/Pane.setPrefWidth:(D)V
        //    72: aload_0        
        //    73: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    76: ldc2_w          -1.0
        //    79: invokevirtual   javafx/scene/layout/Pane.setMinWidth:(D)V
        //    82: aload_0        
        //    83: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //    86: ldc             2023458660
        //    88: sipush          -25508
        //    91: i2c            
        //    92: iadd           
        //    93: ldc             -2023458660
        //    95: sipush          -13054
        //    98: i2c            
        //    99: ineg           
        //   100: iadd           
        //   101: lload_2        
        //   102: l2i            
        //   103: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   106: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   109: invokevirtual   javafx/scene/layout/Pane.setStyle:(Ljava/lang/String;)V
        //   112: aload_0        
        //   113: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //   116: ldc             2023458660
        //   118: sipush          -25472
        //   121: i2c            
        //   122: iadd           
        //   123: ldc             2023458660
        //   125: sipush          -26061
        //   128: i2c            
        //   129: iadd           
        //   130: lload_2        
        //   131: l2i            
        //   132: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   135: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   138: invokevirtual   javafx/scene/layout/Pane.setId:(Ljava/lang/String;)V
        //   141: aload_0        
        //   142: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //   145: ldc2_w          -1.0
        //   148: invokevirtual   javafx/scene/layout/Pane.setMaxWidth:(D)V
        //   151: aload_0        
        //   152: new             Ljavafx/scene/text/Text;
        //   155: dup            
        //   156: invokespecial   javafx/scene/text/Text.<init>:()V
        //   159: putfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   162: aload_0        
        //   163: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   166: dconst_0       
        //   167: invokevirtual   javafx/scene/text/Text.setStrokeWidth:(D)V
        //   170: aload_0        
        //   171: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   174: ldc             2023458660
        //   176: sipush          -25496
        //   179: i2c            
        //   180: iadd           
        //   181: ldc             -2023458660
        //   183: sipush          -14781
        //   186: i2c            
        //   187: ineg           
        //   188: iadd           
        //   189: lload_2        
        //   190: l2i            
        //   191: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   194: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //   197: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //   200: aload_0        
        //   201: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   204: ldc             2023458660
        //   206: sipush          -25471
        //   209: i2c            
        //   210: iadd           
        //   211: ldc             -2023458660
        //   213: sipush          -15707
        //   216: i2c            
        //   217: ineg           
        //   218: iadd           
        //   219: lload_2        
        //   220: l2i            
        //   221: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   224: invokestatic    javafx/scene/text/TextAlignment.valueOf:(Ljava/lang/String;)Ljavafx/scene/text/TextAlignment;
        //   227: invokevirtual   javafx/scene/text/Text.setTextAlignment:(Ljavafx/scene/text/TextAlignment;)V
        //   230: aload_0        
        //   231: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   234: ldc2_w          92.0
        //   237: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //   240: aload_0        
        //   241: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   244: ldc             2023458660
        //   246: sipush          -25494
        //   249: i2c            
        //   250: iadd           
        //   251: ldc             2023458660
        //   253: sipush          -16028
        //   256: i2c            
        //   257: iadd           
        //   258: lload_2        
        //   259: l2i            
        //   260: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   263: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   266: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //   269: aload_0        
        //   270: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   273: ldc             2023458660
        //   275: sipush          -25507
        //   278: i2c            
        //   279: iadd           
        //   280: ldc             -2023458660
        //   282: sipush          -29666
        //   285: i2c            
        //   286: ineg           
        //   287: iadd           
        //   288: lload_2        
        //   289: l2i            
        //   290: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   293: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   296: invokevirtual   javafx/scene/text/Text.setId:(Ljava/lang/String;)V
        //   299: aload_0        
        //   300: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   303: ldc2_w          270.0
        //   306: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //   309: aload_0        
        //   310: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   313: aload           4
        //   315: ldc             2023458660
        //   317: sipush          -25495
        //   320: i2c            
        //   321: iadd           
        //   322: ldc             -2023458660
        //   324: sipush          -20421
        //   327: i2c            
        //   328: ineg           
        //   329: iadd           
        //   330: lload_2        
        //   331: l2i            
        //   332: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   335: iconst_1       
        //   336: anewarray       Ljava/lang/Object;
        //   339: dup_x1         
        //   340: swap           
        //   341: iconst_0       
        //   342: swap           
        //   343: aastore        
        //   344: invokevirtual   invokevirtual  !!! ERROR
        //   347: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   350: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //   353: aload_0        
        //   354: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   357: ldc             2023458660
        //   359: sipush          -25458
        //   362: i2c            
        //   363: iadd           
        //   364: ldc             2023458660
        //   366: sipush          -9156
        //   369: i2c            
        //   370: iadd           
        //   371: lload_2        
        //   372: l2i            
        //   373: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   376: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //   379: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //   382: aload_0        
        //   383: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   386: dconst_0       
        //   387: invokevirtual   javafx/scene/text/Text.setStrokeMiterLimit:(D)V
        //   390: aload_0        
        //   391: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   394: ldc2_w          215.66015625
        //   397: invokevirtual   javafx/scene/text/Text.setWrappingWidth:(D)V
        //   400: aload_0        
        //   401: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   404: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //   407: ldc             2023458660
        //   409: sipush          -25462
        //   412: i2c            
        //   413: iadd           
        //   414: ldc             2023458660
        //   416: sipush          -27359
        //   419: i2c            
        //   420: iadd           
        //   421: lload_2        
        //   422: l2i            
        //   423: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   426: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   431: pop            
        //   432: aload_0        
        //   433: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //   436: invokevirtual   javafx/scene/layout/Pane.getChildren:()Ljavafx/collections/ObservableList;
        //   439: aload_0        
        //   440: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   443: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   448: pop            
        //   449: aload_0        
        //   450: new             Ljavafx/scene/control/ProgressBar;
        //   453: dup            
        //   454: invokespecial   javafx/scene/control/ProgressBar.<init>:()V
        //   457: putfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   460: aload_0        
        //   461: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   464: ldc2_w          7.0
        //   467: invokevirtual   javafx/scene/control/ProgressBar.setPrefHeight:(D)V
        //   470: aload_0        
        //   471: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   474: ldc2_w          400.0
        //   477: invokevirtual   javafx/scene/control/ProgressBar.setPrefWidth:(D)V
        //   480: aload_0        
        //   481: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   484: dconst_1       
        //   485: invokevirtual   javafx/scene/control/ProgressBar.setProgress:(D)V
        //   488: aload_0        
        //   489: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   492: ldc             2023458660
        //   494: sipush          -25474
        //   497: i2c            
        //   498: iadd           
        //   499: ldc             2023458660
        //   501: sipush          -20691
        //   504: i2c            
        //   505: iadd           
        //   506: lload_2        
        //   507: l2i            
        //   508: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   511: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   514: invokevirtual   javafx/scene/control/ProgressBar.setId:(Ljava/lang/String;)V
        //   517: aload_0        
        //   518: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   521: ldc2_w          395.0
        //   524: invokevirtual   javafx/scene/control/ProgressBar.setLayoutY:(D)V
        //   527: aload_0        
        //   528: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //   531: invokevirtual   javafx/scene/layout/Pane.getChildren:()Ljavafx/collections/ObservableList;
        //   534: aload_0        
        //   535: getfield        cr/riselauncher/scopes/c.h:Ljavafx/scene/control/ProgressBar;
        //   538: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   543: pop            
        //   544: aload_0        
        //   545: new             Ljavafx/scene/image/ImageView;
        //   548: dup            
        //   549: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //   552: putfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   555: aload_0        
        //   556: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   559: new             Ljavafx/scene/image/Image;
        //   562: dup            
        //   563: ldc             2023458660
        //   565: sipush          -25467
        //   568: i2c            
        //   569: iadd           
        //   570: ldc             -2023458660
        //   572: sipush          -8271
        //   575: i2c            
        //   576: ineg           
        //   577: iadd           
        //   578: lload_2        
        //   579: l2i            
        //   580: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   583: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //   586: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //   589: aload_0        
        //   590: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   593: iconst_1       
        //   594: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //   597: aload_0        
        //   598: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   601: ldc2_w          135.0
        //   604: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //   607: aload_0        
        //   608: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   611: iconst_1       
        //   612: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //   615: aload_0        
        //   616: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   619: ldc2_w          121.0
        //   622: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //   625: aload_0        
        //   626: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   629: ldc2_w          80.0
        //   632: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //   635: aload_0        
        //   636: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //   639: invokevirtual   javafx/scene/layout/Pane.getChildren:()Ljavafx/collections/ObservableList;
        //   642: aload_0        
        //   643: getfield        cr/riselauncher/scopes/c.a:Ljavafx/scene/image/ImageView;
        //   646: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   651: pop            
        //   652: new             Ljavafx/scene/layout/HBox;
        //   655: dup            
        //   656: invokespecial   javafx/scene/layout/HBox.<init>:()V
        //   659: astore          5
        //   661: aload           5
        //   663: getstatic       javafx/geometry/Pos.CENTER:Ljavafx/geometry/Pos;
        //   666: invokevirtual   javafx/scene/layout/HBox.setAlignment:(Ljavafx/geometry/Pos;)V
        //   669: aload           5
        //   671: ldc2_w          20.0
        //   674: invokevirtual   javafx/scene/layout/HBox.setSpacing:(D)V
        //   677: aload_0        
        //   678: new             Ljavafx/scene/control/Button;
        //   681: dup            
        //   682: invokespecial   javafx/scene/control/Button.<init>:()V
        //   685: putfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   688: aload_0        
        //   689: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   692: ldc             2023458660
        //   694: sipush          -25464
        //   697: i2c            
        //   698: iadd           
        //   699: ldc             -2023458660
        //   701: sipush          -7335
        //   704: i2c            
        //   705: ineg           
        //   706: iadd           
        //   707: lload_2        
        //   708: l2i            
        //   709: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   712: invokevirtual   javafx/scene/control/Button.setId:(Ljava/lang/String;)V
        //   715: aload_0        
        //   716: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   719: ldc             2023458660
        //   721: sipush          -25465
        //   724: i2c            
        //   725: iadd           
        //   726: ldc             -2023458660
        //   728: sipush          -11022
        //   731: i2c            
        //   732: ineg           
        //   733: iadd           
        //   734: lload_2        
        //   735: l2i            
        //   736: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   739: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   742: invokevirtual   javafx/scene/control/Button.setStyle:(Ljava/lang/String;)V
        //   745: aload_0        
        //   746: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   749: ldc             2023458660
        //   751: sipush          -25502
        //   754: i2c            
        //   755: iadd           
        //   756: ldc             -2023458660
        //   758: sipush          -31772
        //   761: iadd           
        //   762: lload_2        
        //   763: l2i            
        //   764: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   767: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   770: invokevirtual   javafx/scene/control/Button.setId:(Ljava/lang/String;)V
        //   773: aload_0        
        //   774: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   777: aload           4
        //   779: ldc             2023458660
        //   781: sipush          -25476
        //   784: i2c            
        //   785: iadd           
        //   786: ldc             -2023458660
        //   788: sipush          -11577
        //   791: i2c            
        //   792: ineg           
        //   793: iadd           
        //   794: lload_2        
        //   795: l2i            
        //   796: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   799: iconst_1       
        //   800: anewarray       Ljava/lang/Object;
        //   803: dup_x1         
        //   804: swap           
        //   805: iconst_0       
        //   806: swap           
        //   807: aastore        
        //   808: invokevirtual   invokevirtual  !!! ERROR
        //   811: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   814: invokevirtual   javafx/scene/control/Button.setText:(Ljava/lang/String;)V
        //   817: aload_0        
        //   818: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   821: iconst_0       
        //   822: invokevirtual   javafx/scene/control/Button.setMnemonicParsing:(Z)V
        //   825: aload_0        
        //   826: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   829: invokevirtual   javafx/scene/control/Button.getStyleClass:()Ljavafx/collections/ObservableList;
        //   832: ldc             2023458660
        //   834: sipush          -25475
        //   837: i2c            
        //   838: iadd           
        //   839: ldc             2023458660
        //   841: sipush          -7199
        //   844: i2c            
        //   845: iadd           
        //   846: lload_2        
        //   847: l2i            
        //   848: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   851: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   856: pop            
        //   857: aload_0        
        //   858: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   861: invokevirtual   javafx/scene/control/Button.getStyleClass:()Ljavafx/collections/ObservableList;
        //   864: ldc             2023458660
        //   866: sipush          -25447
        //   869: i2c            
        //   870: iadd           
        //   871: ldc             2023458660
        //   873: sipush          -7768
        //   876: i2c            
        //   877: iadd           
        //   878: lload_2        
        //   879: l2i            
        //   880: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   883: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   888: pop            
        //   889: aload           5
        //   891: invokevirtual   javafx/scene/layout/HBox.getChildren:()Ljavafx/collections/ObservableList;
        //   894: aload_0        
        //   895: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   898: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   903: pop            
        //   904: aload_0        
        //   905: new             Ljavafx/scene/control/Button;
        //   908: dup            
        //   909: invokespecial   javafx/scene/control/Button.<init>:()V
        //   912: putfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //   915: aload_0        
        //   916: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //   919: ldc             2023458660
        //   921: sipush          -25456
        //   924: i2c            
        //   925: iadd           
        //   926: ldc             -2023458660
        //   928: sipush          -24494
        //   931: i2c            
        //   932: ineg           
        //   933: iadd           
        //   934: lload_2        
        //   935: l2i            
        //   936: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   939: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   942: invokevirtual   javafx/scene/control/Button.setStyle:(Ljava/lang/String;)V
        //   945: aload_0        
        //   946: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //   949: ldc             2023458660
        //   951: sipush          -25461
        //   954: i2c            
        //   955: iadd           
        //   956: ldc             -2023458660
        //   958: sipush          -29598
        //   961: i2c            
        //   962: ineg           
        //   963: iadd           
        //   964: lload_2        
        //   965: l2i            
        //   966: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   969: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   972: invokevirtual   javafx/scene/control/Button.setId:(Ljava/lang/String;)V
        //   975: aload_0        
        //   976: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //   979: aload           4
        //   981: ldc             2023458660
        //   983: sipush          -25468
        //   986: i2c            
        //   987: iadd           
        //   988: ldc             2023458660
        //   990: sipush          -11464
        //   993: i2c            
        //   994: iadd           
        //   995: lload_2        
        //   996: l2i            
        //   997: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //  1000: iconst_1       
        //  1001: anewarray       Ljava/lang/Object;
        //  1004: dup_x1         
        //  1005: swap           
        //  1006: iconst_0       
        //  1007: swap           
        //  1008: aastore        
        //  1009: invokevirtual   invokevirtual  !!! ERROR
        //  1012: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1015: invokevirtual   javafx/scene/control/Button.setText:(Ljava/lang/String;)V
        //  1018: aload_0        
        //  1019: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //  1022: iconst_0       
        //  1023: invokevirtual   javafx/scene/control/Button.setMnemonicParsing:(Z)V
        //  1026: aload_0        
        //  1027: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //  1030: invokevirtual   javafx/scene/control/Button.getStyleClass:()Ljavafx/collections/ObservableList;
        //  1033: ldc             2023458660
        //  1035: sipush          -25473
        //  1038: i2c            
        //  1039: iadd           
        //  1040: ldc             2023458660
        //  1042: sipush          -12883
        //  1045: i2c            
        //  1046: iadd           
        //  1047: lload_2        
        //  1048: l2i            
        //  1049: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //  1052: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1057: pop            
        //  1058: aload_0        
        //  1059: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //  1062: invokevirtual   javafx/scene/control/Button.getStyleClass:()Ljavafx/collections/ObservableList;
        //  1065: ldc             2023458660
        //  1067: sipush          -25451
        //  1070: i2c            
        //  1071: iadd           
        //  1072: ldc             2023458660
        //  1074: sipush          -30273
        //  1077: i2c            
        //  1078: iadd           
        //  1079: lload_2        
        //  1080: l2i            
        //  1081: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //  1084: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1089: pop            
        //  1090: aload           5
        //  1092: invokevirtual   javafx/scene/layout/HBox.getChildren:()Ljavafx/collections/ObservableList;
        //  1095: aload_0        
        //  1096: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //  1099: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1104: pop            
        //  1105: aload           5
        //  1107: getstatic       javafx/geometry/Pos.CENTER:Ljavafx/geometry/Pos;
        //  1110: invokestatic    javafx/scene/layout/StackPane.setAlignment:(Ljavafx/scene/Node;Ljavafx/geometry/Pos;)V
        //  1113: aload_0        
        //  1114: new             Lcr/application/d;
        //  1117: dup            
        //  1118: invokespecial   cr/application/d.<init>:()V
        //  1121: putfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1124: aload_0        
        //  1125: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1128: iconst_0       
        //  1129: invokevirtual   javafx/scene/layout/StackPane.setVisible:(Z)V
        //  1132: aload_0        
        //  1133: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1136: ldc2_w          320.0
        //  1139: invokevirtual   javafx/scene/layout/StackPane.setLayoutY:(D)V
        //  1142: aload_0        
        //  1143: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1146: ldc2_w          400.0
        //  1149: invokevirtual   javafx/scene/layout/StackPane.setPrefWidth:(D)V
        //  1152: aload_0        
        //  1153: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1156: invokevirtual   javafx/scene/layout/StackPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1159: aload           5
        //  1161: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1166: pop            
        //  1167: aload_0        
        //  1168: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //  1171: invokevirtual   javafx/scene/layout/Pane.getChildren:()Ljavafx/collections/ObservableList;
        //  1174: aload_0        
        //  1175: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //  1178: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1183: pop            
        //  1184: aload_0        
        //  1185: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //  1188: new             Lcr/riselauncher/scopes/c$b;
        //  1191: dup            
        //  1192: aload_0        
        //  1193: aload           4
        //  1195: invokespecial   cr/riselauncher/scopes/c$b.<init>:(Lcr/riselauncher/scopes/c;invokespecial  !!! ERROR
        //  1198: invokevirtual   javafx/scene/control/Button.setOnMouseClicked:(Ljavafx/event/EventHandler;)V
        //  1201: aload_0        
        //  1202: getfield        cr/riselauncher/scopes/c.c:Ljavafx/scene/layout/Pane;
        //  1205: areturn        
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void n(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: pop            
        //     2: iconst_0       
        //     3: anewarray       Ljava/lang/Object;
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: astore_2       
        //    10: new             Ljava/lang/Thread;
        //    13: dup            
        //    14: new             Lcr/riselauncher/scopes/c$a;
        //    17: dup            
        //    18: aload_0        
        //    19: aload_2        
        //    20: invokespecial   cr/riselauncher/scopes/c$a.<init>:(Lcr/riselauncher/scopes/c;invokespecial  !!! ERROR
        //    23: invokespecial   java/lang/Thread.<init>:(Ljava/lang/Runnable;)V
        //    26: astore_3       
        //    27: aload_3        
        //    28: iconst_1       
        //    29: invokevirtual   java/lang/Thread.setDaemon:(Z)V
        //    32: aload_3        
        //    33: invokevirtual   java/lang/Thread.start:()V
        //    36: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void x(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          95780286791988
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          107957284803786
        //    24: lxor           
        //    25: lstore          6
        //    27: dup2           
        //    28: ldc2_w          17074359557100
        //    31: lxor           
        //    32: lstore          8
        //    34: pop2           
        //    35: new             Ljava/util/HashMap;
        //    38: dup            
        //    39: invokespecial   java/util/HashMap.<init>:()V
        //    42: astore          10
        //    44: aload           10
        //    46: ldc_w           -248115510
        //    49: sipush          -948
        //    52: iadd           
        //    53: ldc_w           248115510
        //    56: sipush          3860
        //    59: isub           
        //    60: lload_2        
        //    61: l2i            
        //    62: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //    65: iconst_0       
        //    66: anewarray       Ljava/lang/Object;
        //    69: invokestatic    invokestatic   !!! ERROR
        //    72: invokevirtual   invokevirtual  !!! ERROR
        //    75: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    80: pop            
        //    81: aload           10
        //    83: ldc_w           -248115510
        //    86: sipush          -944
        //    89: iadd           
        //    90: ldc_w           -248115510
        //    93: sipush          -15367
        //    96: isub           
        //    97: lload_2        
        //    98: l2i            
        //    99: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   102: iconst_0       
        //   103: anewarray       Ljava/lang/Object;
        //   106: invokestatic    invokestatic   !!! ERROR
        //   109: invokevirtual   invokevirtual  !!! ERROR
        //   112: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   117: pop            
        //   118: aload           10
        //   120: ldc_w           -248115510
        //   123: sipush          -964
        //   126: iadd           
        //   127: ldc_w           -248115510
        //   130: sipush          -9833
        //   133: isub           
        //   134: lload_2        
        //   135: l2i            
        //   136: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   139: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   144: invokevirtual   java/lang/Object.toString:()Ljava/lang/String;
        //   147: putstatic       putstatic      !!! ERROR
        //   150: aload           10
        //   152: ldc_w           -248115510
        //   155: sipush          -933
        //   158: iadd           
        //   159: ldc_w           248115510
        //   162: sipush          21776
        //   165: isub           
        //   166: lload_2        
        //   167: l2i            
        //   168: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   171: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   176: invokevirtual   java/lang/Object.toString:()Ljava/lang/String;
        //   179: putstatic       putstatic      !!! ERROR
        //   182: aconst_null    
        //   183: putstatic       putstatic      !!! ERROR
        //   186: aload           10
        //   188: ldc_w           -248115510
        //   191: sipush          -950
        //   194: iadd           
        //   195: ldc_w           -248115510
        //   198: sipush          -3638
        //   201: iadd           
        //   202: lload_2        
        //   203: l2i            
        //   204: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   207: iconst_0       
        //   208: anewarray       Ljava/lang/Object;
        //   211: invokestatic    invokestatic   !!! ERROR
        //   214: iconst_0       
        //   215: anewarray       Ljava/lang/Object;
        //   218: invokestatic    invokestatic   !!! ERROR
        //   221: invokevirtual   invokevirtual  !!! ERROR
        //   224: invokevirtual   invokevirtual  !!! ERROR
        //   227: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   232: pop            
        //   233: iconst_0       
        //   234: anewarray       Ljava/lang/Object;
        //   237: invokestatic    invokestatic   !!! ERROR
        //   240: iconst_0       
        //   241: anewarray       Ljava/lang/Object;
        //   244: invokestatic    invokestatic   !!! ERROR
        //   247: new             Ljava/lang/StringBuilder;
        //   250: dup            
        //   251: iconst_0       
        //   252: anewarray       Ljava/lang/Object;
        //   255: invokestatic    invokestatic   !!! ERROR
        //   258: invokevirtual   invokevirtual  !!! ERROR
        //   261: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   264: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   267: ldc_w           -248115510
        //   270: sipush          -939
        //   273: iadd           
        //   274: ldc_w           248115510
        //   277: sipush          24991
        //   280: isub           
        //   281: lload_2        
        //   282: l2i            
        //   283: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   286: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   289: iconst_0       
        //   290: anewarray       Ljava/lang/Object;
        //   293: invokestatic    invokestatic   !!! ERROR
        //   296: invokevirtual   invokevirtual  !!! ERROR
        //   299: lload           4
        //   301: iconst_2       
        //   302: anewarray       Ljava/lang/Object;
        //   305: dup_x2         
        //   306: dup_x2         
        //   307: pop            
        //   308: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   311: iconst_1       
        //   312: swap           
        //   313: aastore        
        //   314: dup_x1         
        //   315: swap           
        //   316: iconst_0       
        //   317: swap           
        //   318: aastore        
        //   319: invokestatic    invokestatic   !!! ERROR
        //   322: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   325: ldc_w           -248115510
        //   328: sipush          -947
        //   331: iadd           
        //   332: ldc_w           248115510
        //   335: sipush          16010
        //   338: isub           
        //   339: lload_2        
        //   340: l2i            
        //   341: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   344: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   347: invokestatic    java/lang/System.currentTimeMillis:()J
        //   350: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //   353: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   356: lload           6
        //   358: iconst_2       
        //   359: anewarray       Ljava/lang/Object;
        //   362: dup_x2         
        //   363: dup_x2         
        //   364: pop            
        //   365: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   368: iconst_1       
        //   369: swap           
        //   370: aastore        
        //   371: dup_x1         
        //   372: swap           
        //   373: iconst_0       
        //   374: swap           
        //   375: aastore        
        //   376: invokevirtual   invokevirtual  !!! ERROR
        //   379: lload           8
        //   381: iconst_2       
        //   382: anewarray       Ljava/lang/Object;
        //   385: dup_x2         
        //   386: dup_x2         
        //   387: pop            
        //   388: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   391: iconst_1       
        //   392: swap           
        //   393: aastore        
        //   394: dup_x1         
        //   395: swap           
        //   396: iconst_0       
        //   397: swap           
        //   398: aastore        
        //   399: invokevirtual   invokevirtual  !!! ERROR
        //   402: astore          11
        //   404: iconst_0       
        //   405: anewarray       Ljava/lang/Object;
        //   408: invokestatic    invokestatic   !!! ERROR
        //   411: iconst_0       
        //   412: anewarray       Ljava/lang/Object;
        //   415: invokestatic    invokestatic   !!! ERROR
        //   418: aload           11
        //   420: lload           8
        //   422: iconst_2       
        //   423: anewarray       Ljava/lang/Object;
        //   426: dup_x2         
        //   427: dup_x2         
        //   428: pop            
        //   429: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   432: iconst_1       
        //   433: swap           
        //   434: aastore        
        //   435: dup_x1         
        //   436: swap           
        //   437: iconst_0       
        //   438: swap           
        //   439: aastore        
        //   440: invokevirtual   invokevirtual  !!! ERROR
        //   443: lload           6
        //   445: iconst_2       
        //   446: anewarray       Ljava/lang/Object;
        //   449: dup_x2         
        //   450: dup_x2         
        //   451: pop            
        //   452: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   455: iconst_1       
        //   456: swap           
        //   457: aastore        
        //   458: dup_x1         
        //   459: swap           
        //   460: iconst_0       
        //   461: swap           
        //   462: aastore        
        //   463: invokevirtual   invokevirtual  !!! ERROR
        //   466: astore          11
        //   468: aload           10
        //   470: ldc_w           -248115510
        //   473: sipush          -945
        //   476: iadd           
        //   477: ldc_w           248115510
        //   480: sipush          25545
        //   483: isub           
        //   484: lload_2        
        //   485: l2i            
        //   486: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   489: aload           11
        //   491: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   496: pop            
        //   497: aload           10
        //   499: ldc_w           -248115510
        //   502: sipush          -930
        //   505: iadd           
        //   506: ldc_w           -248115510
        //   509: sipush          -2780
        //   512: iadd           
        //   513: lload_2        
        //   514: l2i            
        //   515: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   518: aload           11
        //   520: lload           4
        //   522: iconst_2       
        //   523: anewarray       Ljava/lang/Object;
        //   526: dup_x2         
        //   527: dup_x2         
        //   528: pop            
        //   529: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   532: iconst_1       
        //   533: swap           
        //   534: aastore        
        //   535: dup_x1         
        //   536: swap           
        //   537: iconst_0       
        //   538: swap           
        //   539: aastore        
        //   540: invokestatic    invokestatic   !!! ERROR
        //   543: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   548: pop            
        //   549: new             Ljava/lang/StringBuilder;
        //   552: dup            
        //   553: aload           11
        //   555: lload           4
        //   557: iconst_2       
        //   558: anewarray       Ljava/lang/Object;
        //   561: dup_x2         
        //   562: dup_x2         
        //   563: pop            
        //   564: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   567: iconst_1       
        //   568: swap           
        //   569: aastore        
        //   570: dup_x1         
        //   571: swap           
        //   572: iconst_0       
        //   573: swap           
        //   574: aastore        
        //   575: invokestatic    invokestatic   !!! ERROR
        //   578: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   581: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   584: iconst_0       
        //   585: anewarray       Ljava/lang/Object;
        //   588: invokestatic    invokestatic   !!! ERROR
        //   591: invokevirtual   invokevirtual  !!! ERROR
        //   594: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   597: ldc_w           -248115510
        //   600: sipush          -954
        //   603: iadd           
        //   604: ldc_w           -248115510
        //   607: sipush          -16578
        //   610: isub           
        //   611: lload_2        
        //   612: l2i            
        //   613: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   616: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   619: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   622: lload           4
        //   624: iconst_2       
        //   625: anewarray       Ljava/lang/Object;
        //   628: dup_x2         
        //   629: dup_x2         
        //   630: pop            
        //   631: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   634: iconst_1       
        //   635: swap           
        //   636: aastore        
        //   637: dup_x1         
        //   638: swap           
        //   639: iconst_0       
        //   640: swap           
        //   641: aastore        
        //   642: invokestatic    invokestatic   !!! ERROR
        //   645: astore          12
        //   647: aload           10
        //   649: ldc_w           -248115510
        //   652: sipush          -932
        //   655: iadd           
        //   656: ldc_w           248115510
        //   659: sipush          2613
        //   662: isub           
        //   663: lload_2        
        //   664: l2i            
        //   665: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   668: aload           12
        //   670: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   675: pop            
        //   676: aload           10
        //   678: ldc_w           -248115510
        //   681: sipush          -929
        //   684: iadd           
        //   685: ldc_w           -248115510
        //   688: sipush          -3376
        //   691: isub           
        //   692: lload_2        
        //   693: l2i            
        //   694: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   697: new             Ljava/lang/StringBuilder;
        //   700: dup            
        //   701: ldc_w           -248115510
        //   704: sipush          -969
        //   707: iadd           
        //   708: ldc_w           -248115510
        //   711: sipush          -20058
        //   714: isub           
        //   715: lload_2        
        //   716: l2i            
        //   717: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   720: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   723: aload           12
        //   725: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   728: ldc_w           -248115510
        //   731: sipush          -943
        //   734: iadd           
        //   735: ldc_w           -248115510
        //   738: sipush          -6339
        //   741: isub           
        //   742: lload_2        
        //   743: l2i            
        //   744: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   747: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   750: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   753: lload           4
        //   755: iconst_2       
        //   756: anewarray       Ljava/lang/Object;
        //   759: dup_x2         
        //   760: dup_x2         
        //   761: pop            
        //   762: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   765: iconst_1       
        //   766: swap           
        //   767: aastore        
        //   768: dup_x1         
        //   769: swap           
        //   770: iconst_0       
        //   771: swap           
        //   772: aastore        
        //   773: invokestatic    invokestatic   !!! ERROR
        //   776: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   781: pop            
        //   782: aload           10
        //   784: ldc_w           -248115510
        //   787: sipush          -923
        //   790: iadd           
        //   791: ldc_w           -248115510
        //   794: sipush          -21283
        //   797: isub           
        //   798: lload_2        
        //   799: l2i            
        //   800: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   803: new             Ljava/lang/StringBuilder;
        //   806: dup            
        //   807: ldc_w           -248115510
        //   810: sipush          -959
        //   813: iadd           
        //   814: ldc_w           248115510
        //   817: sipush          6572
        //   820: isub           
        //   821: lload_2        
        //   822: l2i            
        //   823: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   826: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   829: iconst_0       
        //   830: anewarray       Ljava/lang/Object;
        //   833: invokestatic    invokestatic   !!! ERROR
        //   836: invokevirtual   invokevirtual  !!! ERROR
        //   839: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   842: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   845: lload           4
        //   847: iconst_2       
        //   848: anewarray       Ljava/lang/Object;
        //   851: dup_x2         
        //   852: dup_x2         
        //   853: pop            
        //   854: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   857: iconst_1       
        //   858: swap           
        //   859: aastore        
        //   860: dup_x1         
        //   861: swap           
        //   862: iconst_0       
        //   863: swap           
        //   864: aastore        
        //   865: invokestatic    invokestatic   !!! ERROR
        //   868: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   873: pop            
        //   874: new             new            !!! ERROR
        //   877: dup            
        //   878: invokespecial   invokespecial  !!! ERROR
        //   881: astore          13
        //   883: aload           13
        //   885: ldc_w           -248115510
        //   888: sipush          -935
        //   891: iadd           
        //   892: ldc_w           -248115510
        //   895: sipush          -15679
        //   898: isub           
        //   899: lload_2        
        //   900: l2i            
        //   901: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   904: ldc_w           -248115510
        //   907: sipush          -960
        //   910: iadd           
        //   911: ldc_w           248115510
        //   914: sipush          21832
        //   917: isub           
        //   918: lload_2        
        //   919: l2i            
        //   920: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   923: invokevirtual   invokevirtual  !!! ERROR
        //   926: pop            
        //   927: aload           13
        //   929: ldc_w           -248115510
        //   932: sipush          -951
        //   935: iadd           
        //   936: ldc_w           -248115510
        //   939: sipush          -22006
        //   942: isub           
        //   943: lload_2        
        //   944: l2i            
        //   945: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   948: new             new            !!! ERROR
        //   951: dup            
        //   952: aload           10
        //   954: invokespecial   invokespecial  !!! ERROR
        //   957: invokevirtual   invokevirtual  !!! ERROR
        //   960: pop            
        //   961: aload           13
        //   963: iconst_1       
        //   964: anewarray       Ljava/lang/Object;
        //   967: dup_x1         
        //   968: swap           
        //   969: iconst_0       
        //   970: swap           
        //   971: aastore        
        //   972: invokestatic    invokestatic   !!! ERROR
        //   975: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:91)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.ClassFileReader.populateNamedInnerTypes(ClassFileReader.java:698)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:442)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:766)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2515)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void s(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          54156484132312
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          83767036004762
        //    24: lxor           
        //    25: lstore          6
        //    27: pop2           
        //    28: iconst_0       
        //    29: anewarray       Ljava/lang/Object;
        //    32: invokestatic    invokestatic   !!! ERROR
        //    35: astore          8
        //    37: aload_0        
        //    38: iconst_0       
        //    39: anewarray       Ljava/lang/Object;
        //    42: invokevirtual   cr/riselauncher/scopes/c.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //    45: ldc_w           -1052361030
        //    48: sipush          -21568
        //    51: i2c            
        //    52: ineg           
        //    53: iadd           
        //    54: ldc_w           -1052361030
        //    57: sipush          -17560
        //    60: iadd           
        //    61: lload_2        
        //    62: l2i            
        //    63: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //    66: invokevirtual   cr/application/RiseApplication.a:(Ljava/lang/String;)Lcr/application/r;
        //    69: checkcast       Lcr/riselauncher/scopes/a;
        //    72: astore          9
        //    74: iconst_0       
        //    75: anewarray       Ljava/lang/Object;
        //    78: invokestatic    invokestatic   !!! ERROR
        //    81: astore          10
        //    83: aload           9
        //    85: aload           8
        //    87: ldc_w           -1052361030
        //    90: sipush          -21512
        //    93: i2c            
        //    94: ineg           
        //    95: iadd           
        //    96: ldc_w           -1052361030
        //    99: sipush          -30365
        //   102: i2c            
        //   103: ineg           
        //   104: iadd           
        //   105: lload_2        
        //   106: l2i            
        //   107: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   110: iconst_1       
        //   111: anewarray       Ljava/lang/Object;
        //   114: dup_x1         
        //   115: swap           
        //   116: iconst_0       
        //   117: swap           
        //   118: aastore        
        //   119: invokevirtual   invokevirtual  !!! ERROR
        //   122: lload           4
        //   124: dup2_x1        
        //   125: pop2           
        //   126: iconst_2       
        //   127: anewarray       Ljava/lang/Object;
        //   130: dup_x1         
        //   131: swap           
        //   132: iconst_1       
        //   133: swap           
        //   134: aastore        
        //   135: dup_x2         
        //   136: dup_x2         
        //   137: pop            
        //   138: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   141: iconst_0       
        //   142: swap           
        //   143: aastore        
        //   144: invokevirtual   cr/riselauncher/scopes/a.v:([Ljava/lang/Object;)V
        //   147: aload           9
        //   149: getfield        cr/riselauncher/scopes/a.m:Ljavafx/scene/control/TextField;
        //   152: aload           10
        //   154: invokevirtual   invokevirtual  !!! ERROR
        //   157: invokevirtual   javafx/scene/control/TextField.setText:(Ljava/lang/String;)V
        //   160: aload           9
        //   162: getfield        cr/riselauncher/scopes/a.f:Ljavafx/scene/control/PasswordField;
        //   165: aload           10
        //   167: invokevirtual   invokevirtual  !!! ERROR
        //   170: invokevirtual   javafx/scene/control/PasswordField.setText:(Ljava/lang/String;)V
        //   173: aload_0        
        //   174: lload           6
        //   176: iconst_1       
        //   177: anewarray       Ljava/lang/Object;
        //   180: dup_x2         
        //   181: dup_x2         
        //   182: pop            
        //   183: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   186: iconst_0       
        //   187: swap           
        //   188: aastore        
        //   189: invokevirtual   cr/riselauncher/scopes/c.v:([Ljava/lang/Object;)V
        //   192: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void u(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          134905879591604
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          8645644685046
        //    24: lxor           
        //    25: lstore          6
        //    27: pop2           
        //    28: iconst_0       
        //    29: anewarray       Ljava/lang/Object;
        //    32: invokestatic    invokestatic   !!! ERROR
        //    35: astore          8
        //    37: aload_0        
        //    38: iconst_0       
        //    39: anewarray       Ljava/lang/Object;
        //    42: invokevirtual   cr/riselauncher/scopes/c.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //    45: ldc_w           -1312928190
        //    48: sipush          -30890
        //    51: iadd           
        //    52: ldc_w           1312928190
        //    55: sipush          -20248
        //    58: i2c            
        //    59: iadd           
        //    60: lload_2        
        //    61: l2i            
        //    62: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //    65: invokevirtual   cr/application/RiseApplication.a:(Ljava/lang/String;)Lcr/application/r;
        //    68: checkcast       Lcr/riselauncher/scopes/a;
        //    71: astore          9
        //    73: iconst_0       
        //    74: anewarray       Ljava/lang/Object;
        //    77: invokestatic    invokestatic   !!! ERROR
        //    80: astore          10
        //    82: aload           9
        //    84: aload           8
        //    86: ldc_w           -1312928190
        //    89: sipush          -30881
        //    92: iadd           
        //    93: ldc_w           1312928190
        //    96: sipush          -29165
        //    99: i2c            
        //   100: iadd           
        //   101: lload_2        
        //   102: l2i            
        //   103: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   106: iconst_1       
        //   107: anewarray       Ljava/lang/Object;
        //   110: dup_x1         
        //   111: swap           
        //   112: iconst_0       
        //   113: swap           
        //   114: aastore        
        //   115: invokevirtual   invokevirtual  !!! ERROR
        //   118: lload           4
        //   120: dup2_x1        
        //   121: pop2           
        //   122: iconst_2       
        //   123: anewarray       Ljava/lang/Object;
        //   126: dup_x1         
        //   127: swap           
        //   128: iconst_1       
        //   129: swap           
        //   130: aastore        
        //   131: dup_x2         
        //   132: dup_x2         
        //   133: pop            
        //   134: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   137: iconst_0       
        //   138: swap           
        //   139: aastore        
        //   140: invokevirtual   cr/riselauncher/scopes/a.v:([Ljava/lang/Object;)V
        //   143: aload           9
        //   145: getfield        cr/riselauncher/scopes/a.m:Ljavafx/scene/control/TextField;
        //   148: aload           10
        //   150: invokevirtual   invokevirtual  !!! ERROR
        //   153: invokevirtual   javafx/scene/control/TextField.setText:(Ljava/lang/String;)V
        //   156: aload           9
        //   158: getfield        cr/riselauncher/scopes/a.f:Ljavafx/scene/control/PasswordField;
        //   161: aload           10
        //   163: invokevirtual   invokevirtual  !!! ERROR
        //   166: invokevirtual   javafx/scene/control/PasswordField.setText:(Ljava/lang/String;)V
        //   169: aload_0        
        //   170: lload           6
        //   172: iconst_1       
        //   173: anewarray       Ljava/lang/Object;
        //   176: dup_x2         
        //   177: dup_x2         
        //   178: pop            
        //   179: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   182: iconst_0       
        //   183: swap           
        //   184: aastore        
        //   185: invokevirtual   cr/riselauncher/scopes/c.v:([Ljava/lang/Object;)V
        //   188: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void y() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: lstore_1       
        //     4: lload_1        
        //     5: dup2           
        //     6: ldc2_w          34102992439914
        //     9: lxor           
        //    10: lstore_3       
        //    11: dup2           
        //    12: ldc2_w          122774006244346
        //    15: lxor           
        //    16: lstore          5
        //    18: pop2           
        //    19: getstatic       cr/riselauncher/scopes/c.j:Z
        //    22: istore          7
        //    24: aload_0        
        //    25: iload           7
        //    27: ifne            86
        //    30: invokedynamic   BootstrapMethod #0, run:(Lcr/riselauncher/scopes/c;)Ljava/lang/Runnable;
        //    35: iconst_1       
        //    36: anewarray       Ljava/lang/Object;
        //    39: dup_x1         
        //    40: swap           
        //    41: iconst_0       
        //    42: swap           
        //    43: aastore        
        //    44: invokestatic    cr/application/n.a:([Ljava/lang/Object;)Z
        //    47: ifeq            56
        //    50: goto            54
        //    53: athrow         
        //    54: return         
        //    55: athrow         
        //    56: aload_0        
        //    57: iconst_0       
        //    58: anewarray       Ljava/lang/Object;
        //    61: invokevirtual   cr/riselauncher/scopes/c.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //    64: ldc_w           1911131670
        //    67: sipush          15628
        //    70: isub           
        //    71: ldc_w           1911131670
        //    74: sipush          21572
        //    77: isub           
        //    78: lload_1        
        //    79: l2i            
        //    80: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //    83: invokevirtual   cr/application/RiseApplication.a:(Ljava/lang/String;)Lcr/application/r;
        //    86: checkcast       Lcr/riselauncher/scopes/a;
        //    89: astore          9
        //    91: iconst_0       
        //    92: anewarray       Ljava/lang/Object;
        //    95: invokestatic    invokestatic   !!! ERROR
        //    98: astore          10
        //   100: aload           9
        //   102: iconst_1       
        //   103: lload           5
        //   105: iconst_2       
        //   106: anewarray       Ljava/lang/Object;
        //   109: dup_x2         
        //   110: dup_x2         
        //   111: pop            
        //   112: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   115: iconst_1       
        //   116: swap           
        //   117: aastore        
        //   118: dup_x1         
        //   119: swap           
        //   120: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //   123: iconst_0       
        //   124: swap           
        //   125: aastore        
        //   126: invokevirtual   cr/riselauncher/scopes/a.w:([Ljava/lang/Object;)V
        //   129: iconst_0       
        //   130: anewarray       Ljava/lang/Object;
        //   133: invokestatic    invokestatic   !!! ERROR
        //   136: aload           9
        //   138: getfield        cr/riselauncher/scopes/a.m:Ljavafx/scene/control/TextField;
        //   141: aload           10
        //   143: invokevirtual   invokevirtual  !!! ERROR
        //   146: invokevirtual   javafx/scene/control/TextField.setText:(Ljava/lang/String;)V
        //   149: aload           9
        //   151: getfield        cr/riselauncher/scopes/a.f:Ljavafx/scene/control/PasswordField;
        //   154: aload           10
        //   156: invokevirtual   invokevirtual  !!! ERROR
        //   159: invokevirtual   javafx/scene/control/PasswordField.setText:(Ljava/lang/String;)V
        //   162: aload_0        
        //   163: lload_3        
        //   164: iconst_1       
        //   165: anewarray       Ljava/lang/Object;
        //   168: dup_x2         
        //   169: dup_x2         
        //   170: pop            
        //   171: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   174: iconst_0       
        //   175: swap           
        //   176: aastore        
        //   177: invokevirtual   cr/riselauncher/scopes/c.v:([Ljava/lang/Object;)V
        //   180: return         
        //    StackMapTable: 00 05 FF 00 35 00 05 07 00 02 04 04 04 01 00 01 07 01 BA 00 40 07 01 BA 00 5D 07 01 D9
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  24     50     53     54     Ljava/lang/IllegalStateException;
        //  30     55     55     56     Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void v(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          41562967834475
        //    17: lxor           
        //    18: lstore          4
        //    20: pop2           
        //    21: iconst_0       
        //    22: anewarray       Ljava/lang/Object;
        //    25: invokestatic    invokestatic   !!! ERROR
        //    28: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/g;
        //    31: ldc_w           1227470550
        //    34: sipush          23414
        //    37: isub           
        //    38: ldc_w           1227470550
        //    41: sipush          -31970
        //    44: i2c            
        //    45: isub           
        //    46: lload_2        
        //    47: l2i            
        //    48: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //    51: lload           4
        //    53: getstatic       cr/application/o.HIDE_WAIT_SHOW:Lcr/application/o;
        //    56: iconst_0       
        //    57: iconst_1       
        //    58: iconst_5       
        //    59: anewarray       Ljava/lang/Object;
        //    62: dup_x1         
        //    63: swap           
        //    64: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //    67: iconst_4       
        //    68: swap           
        //    69: aastore        
        //    70: dup_x1         
        //    71: swap           
        //    72: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //    75: iconst_3       
        //    76: swap           
        //    77: aastore        
        //    78: dup_x1         
        //    79: swap           
        //    80: iconst_2       
        //    81: swap           
        //    82: aastore        
        //    83: dup_x2         
        //    84: dup_x2         
        //    85: pop            
        //    86: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    89: iconst_1       
        //    90: swap           
        //    91: aastore        
        //    92: dup_x1         
        //    93: swap           
        //    94: iconst_0       
        //    95: swap           
        //    96: aastore        
        //    97: invokevirtual   cr/application/g.a:([Ljava/lang/Object;)V
        //   100: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:766)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2463)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void t(final Object[] array) {
        final double doubleValue = (double)array[0];
        final boolean j = c.j;
        c c = null;
        Label_0051: {
            Label_0050: {
                final double n;
                try {
                    c = this;
                    if (j) {
                        break Label_0051;
                    }
                    final Runnable runnable = () -> this.t(new Object[] { n });
                    final int n2 = 1;
                    final Object[] array2 = new Object[n2];
                    final int n3 = 0;
                    array2[n3] = runnable;
                    final boolean b = cr.application.n.a(array2);
                    if (b) {
                        return;
                    }
                    break Label_0050;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    final Runnable runnable = () -> this.t(new Object[] { n });
                    final int n2 = 1;
                    final Object[] array2 = new Object[n2];
                    final int n3 = 0;
                    array2[n3] = runnable;
                    final boolean b = cr.application.n.a(array2);
                    if (b) {
                        return;
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            c = this;
        }
        c.h.setProgress(doubleValue);
    }
    
    public void w(final Object[] array) {
        final String text = (String)array[0];
        final boolean j = c.j;
        c c = null;
        Label_0046: {
            Label_0045: {
                final Object o;
                try {
                    c = this;
                    if (j) {
                        break Label_0046;
                    }
                    final Runnable runnable = () -> this.w(new Object[] { o });
                    final int n = 1;
                    final Object[] array2 = new Object[n];
                    final int n2 = 0;
                    array2[n2] = runnable;
                    final boolean b = cr.application.n.a(array2);
                    if (b) {
                        return;
                    }
                    break Label_0045;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    final Runnable runnable = () -> this.w(new Object[] { o });
                    final int n = 1;
                    final Object[] array2 = new Object[n];
                    final int n2 = 0;
                    array2[n2] = runnable;
                    final boolean b = cr.application.n.a(array2);
                    if (b) {
                        return;
                    }
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            c = this;
        }
        c.d.setText(text);
    }
    
    @Override
    public String a(final Object[] array) {
        return a(-2079949830 - 19390, 2079949830 + 4331, (int)(long)array[0]);
    }
    
    @Override
    public void a(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljavafx/scene/Node;
        //     7: astore_2       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljava/lang/Long;
        //    14: invokevirtual   java/lang/Long.longValue:()J
        //    17: lstore          4
        //    19: dup            
        //    20: iconst_2       
        //    21: aaload         
        //    22: checkcast       Ljavafx/scene/input/MouseEvent;
        //    25: astore_3       
        //    26: pop            
        //    27: lload           4
        //    29: dup2           
        //    30: ldc2_w          30082119246024
        //    33: lxor           
        //    34: lstore          6
        //    36: dup2           
        //    37: ldc2_w          121834529398581
        //    40: lxor           
        //    41: dup2           
        //    42: bipush          48
        //    44: lushr          
        //    45: l2i            
        //    46: istore          8
        //    48: dup2           
        //    49: bipush          16
        //    51: lshl           
        //    52: bipush          32
        //    54: lushr          
        //    55: l2i            
        //    56: istore          9
        //    58: dup2           
        //    59: bipush          48
        //    61: lshl           
        //    62: bipush          48
        //    64: lushr          
        //    65: l2i            
        //    66: istore          10
        //    68: pop2           
        //    69: pop2           
        //    70: getstatic       cr/riselauncher/scopes/c.j:Z
        //    73: iconst_0       
        //    74: anewarray       Ljava/lang/Object;
        //    77: invokestatic    invokestatic   !!! ERROR
        //    80: astore          12
        //    82: istore          11
        //    84: aload_2        
        //    85: iload           11
        //    87: ifne            99
        //    90: ifnonnull       98
        //    93: goto            97
        //    96: athrow         
        //    97: return         
        //    98: aload_2        
        //    99: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //   102: iload           11
        //   104: ifne            220
        //   107: ifnull          216
        //   110: goto            114
        //   113: athrow         
        //   114: aload_2        
        //   115: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //   118: iload           11
        //   120: ifne            220
        //   123: goto            127
        //   126: athrow         
        //   127: aload_0        
        //   128: getfield        cr/riselauncher/scopes/c.i:Ljavafx/scene/control/Button;
        //   131: invokevirtual   javafx/scene/control/Button.getId:()Ljava/lang/String;
        //   134: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   137: ifeq            216
        //   140: goto            144
        //   143: athrow         
        //   144: aload_0        
        //   145: getfield        cr/riselauncher/scopes/c.e:Ljavafx/scene/layout/StackPane;
        //   148: iconst_0       
        //   149: invokevirtual   javafx/scene/layout/StackPane.setVisible:(Z)V
        //   152: aload_0        
        //   153: getfield        cr/riselauncher/scopes/c.d:Ljavafx/scene/text/Text;
        //   156: aload           12
        //   158: ldc_w           -79821630
        //   161: sipush          -10003
        //   164: isub           
        //   165: ldc_w           -79821630
        //   168: sipush          -8623
        //   171: isub           
        //   172: lload           4
        //   174: l2i            
        //   175: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   178: iconst_1       
        //   179: anewarray       Ljava/lang/Object;
        //   182: dup_x1         
        //   183: swap           
        //   184: iconst_0       
        //   185: swap           
        //   186: aastore        
        //   187: invokevirtual   invokevirtual  !!! ERROR
        //   190: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //   193: aload_0        
        //   194: lload           6
        //   196: iconst_1       
        //   197: anewarray       Ljava/lang/Object;
        //   200: dup_x2         
        //   201: dup_x2         
        //   202: pop            
        //   203: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   206: iconst_0       
        //   207: swap           
        //   208: aastore        
        //   209: invokevirtual   cr/riselauncher/scopes/c.x:([Ljava/lang/Object;)V
        //   212: goto            216
        //   215: athrow         
        //   216: aload_2        
        //   217: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //   220: iload           11
        //   222: ifne            240
        //   225: ifnull          393
        //   228: goto            232
        //   231: athrow         
        //   232: aload_2        
        //   233: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //   236: goto            240
        //   239: athrow         
        //   240: aload_0        
        //   241: getfield        cr/riselauncher/scopes/c.g:Ljavafx/scene/control/Button;
        //   244: invokevirtual   javafx/scene/control/Button.getId:()Ljava/lang/String;
        //   247: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   250: ifeq            393
        //   253: iconst_0       
        //   254: anewarray       Ljava/lang/Object;
        //   257: invokestatic    invokestatic   !!! ERROR
        //   260: invokevirtual   invokevirtual  !!! ERROR
        //   263: iload           11
        //   265: ifne            313
        //   268: goto            272
        //   271: athrow         
        //   272: iconst_0       
        //   273: anewarray       Ljava/lang/Object;
        //   276: invokestatic    invokestatic   !!! ERROR
        //   279: ifnull          303
        //   282: goto            286
        //   285: athrow         
        //   286: aconst_null    
        //   287: iconst_1       
        //   288: anewarray       Ljava/lang/Object;
        //   291: dup_x1         
        //   292: swap           
        //   293: iconst_0       
        //   294: swap           
        //   295: aastore        
        //   296: invokestatic    invokestatic   !!! ERROR
        //   299: goto            303
        //   302: athrow         
        //   303: aload_0        
        //   304: getfield        cr/riselauncher/scopes/c.b:Lcr/application/RiseApplication;
        //   307: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //   310: invokevirtual   cr/application/RisePopup.b:()V
        //   313: aload_0        
        //   314: getfield        cr/riselauncher/scopes/c.b:Lcr/application/RiseApplication;
        //   317: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/g;
        //   320: ldc_w           -79821630
        //   323: sipush          -10002
        //   326: isub           
        //   327: ldc_w           -79821630
        //   330: sipush          -15946
        //   333: isub           
        //   334: lload           4
        //   336: l2i            
        //   337: invokestatic    cr/riselauncher/scopes/c.a:(III)Ljava/lang/String;
        //   340: iload           8
        //   342: i2s            
        //   343: iload           9
        //   345: iload           10
        //   347: i2s            
        //   348: iconst_1       
        //   349: iconst_5       
        //   350: anewarray       Ljava/lang/Object;
        //   353: dup_x1         
        //   354: swap           
        //   355: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //   358: iconst_4       
        //   359: swap           
        //   360: aastore        
        //   361: dup_x1         
        //   362: swap           
        //   363: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   366: iconst_3       
        //   367: swap           
        //   368: aastore        
        //   369: dup_x1         
        //   370: swap           
        //   371: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   374: iconst_2       
        //   375: swap           
        //   376: aastore        
        //   377: dup_x1         
        //   378: swap           
        //   379: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   382: iconst_1       
        //   383: swap           
        //   384: aastore        
        //   385: dup_x1         
        //   386: swap           
        //   387: iconst_0       
        //   388: swap           
        //   389: aastore        
        //   390: invokevirtual   cr/application/g.b:([Ljava/lang/Object;)V
        //   393: return         
        //    StackMapTable: 00 19 FF 00 60 00 0B 07 00 02 07 02 06 07 02 11 07 02 13 04 04 01 01 01 01 07 00 90 00 01 07 01 BA 00 00 40 07 02 11 4D 07 01 BA 00 4B 07 01 BA 40 07 00 5A 4F 07 01 BA 00 F7 00 46 07 01 BA 00 43 07 00 5A 4A 07 01 BA 00 46 07 01 BA 40 07 00 5A 5E 07 01 BA 00 4C 07 01 BA 00 4F 07 01 BA 00 09 FB 00 4F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  84     93     96     97     Ljava/lang/IllegalStateException;
        //  99     110    113    114    Ljava/lang/IllegalStateException;
        //  107    123    126    127    Ljava/lang/IllegalStateException;
        //  114    140    143    144    Ljava/lang/IllegalStateException;
        //  127    212    215    216    Ljava/lang/IllegalStateException;
        //  220    228    231    232    Ljava/lang/IllegalStateException;
        //  225    236    239    240    Ljava/lang/IllegalStateException;
        //  240    268    271    272    Ljava/lang/IllegalStateException;
        //  253    282    285    286    Ljava/lang/IllegalStateException;
        //  272    299    302    303    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:91)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.ClassFileReader.populateNamedInnerTypes(ClassFileReader.java:698)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:442)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataHelper.isRawType(MetadataHelper.java:1581)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visitClassType(MetadataHelper.java:2369)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visitClassType(MetadataHelper.java:2322)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.accept(CoreMetadataFactory.java:577)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visit(MetadataHelper.java:2336)
        //     at com.strobel.assembler.metadata.MetadataHelper.isSameType(MetadataHelper.java:1411)
        //     at com.strobel.assembler.metadata.TypeReference.equals(TypeReference.java:118)
        //     at com.strobel.core.Comparer.equals(Comparer.java:31)
        //     at com.strobel.assembler.ir.FrameValue.equals(FrameValue.java:72)
        //     at com.strobel.core.Comparer.equals(Comparer.java:31)
        //     at com.strobel.assembler.ir.Frame.merge(Frame.java:338)
        //     at com.strobel.assembler.ir.Frame.merge(Frame.java:273)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2206)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] i = new String[47];
        int n = 0;
        String s;
        int n2 = (s = "\u00d5H6\u0004\u00cf\u0012\u00f5-\u00f5'K\u0006\u00973j\u00cd\u0014\u0082\u000e6s¸\u0013ª\u0080\b\u00eb9\u00d1?\u0003»\u00c7\n@\u001c\u009b\u00cb\u00d1\u0016\u00eb\u00e4A_\u0006±\u00fc^23»\u000bs®\u00dc\u00e60\u00c0¹+\u0085\r6\u000b\u00e4©p|e\u00d6¡\tv ¤\u000b\u00007²\u00d5\u00fd¦\u0000\u00e7²\u0094\u00d0\u000b¢\u009a\u0085£\b\u00c5\u0095¯\u0000\u009d\u0086\u0006\u00fd\u00d8\u0087\u00cc®\u00eb\u000e\f\u0006±3J\u00e7\u0085\u00d0\u0002\u00dd³¦\u00edi\u0002\u00f8\u00c7\u0005F\u0006A\u00fb\u01cf\u001c\"\u00ed\u0087\u00d7\u0002\u00f7\u00d7\u00e3@¤½'\u00f8@\u0002¼\u0096\u00e4\u00e6\u00ff~f\u00c3\u0010¾ \u00e5_\b\u00daN\u0018´?|k\u00ce\u0013 \n\u0019\u00d4¿\u00d7®\u00c9,\u0019vEIj\u0080\u0015©¤\u008b\u0013£\u0092y\u00c7³µ/\u0085\u001c\u0090pt\u0089L\u0098\u00d1¤<\u00e5\u0003\u001f¹a\b\u0098¾\u00e3\u00fb\u008dº\u0018\u00d8\u0006]\u00fb\u0093¨,g\u0005\u00c6D£q\n\u0019rh\u0006¤<m¨\u009fE\u00f7\u0097\u0106!O\b\u00d2\u0180Z\u01add\u008f\u00c1@\u00d7\u00df\u0005f*\u00c5B\u0006\u0003NzP\u0005\u00d7X\u00c2\u00dc\u0006\t\u0099k\u00ec,\u00fc\u00d1\u008fy*\u0005>\u0081¼\u00c9\u00e9\u0005µ\u009c\u00d7\u00ad\u00e8\u0010\u00fb\u00c8\u00fe\u0085`\u009eY\u00d0|]\u00e9B \u00c3»>\u0006=6x\u009ay¼\bz\u008c\f\u00ec½w;¯\u0003\u00875i\u0003v±C\u0007\u0084\u0003\u001d\u00eb\u0091§l\u0003\u0006\u00de\u0018\u0019\u000f{\u00c3\u0094¾h\u00fcE\u000b\u00f5\u0000\u00044l¢i\u0084\u015co\u00f1\u00eaq\u013c\u00c3¬\u001eª<X\u0012\u0085\u001c¿\u00cc\u0082\u0010¦\u00d0\u008f\u00e7\u0016j\u00d8<m£W\u0001©\u00cbV¤»\u0090\u00d8@\u0004\u0083\u00e0\u000f³\u00066]J¦@F\u0007\u00e5c1\u00e7\u0014&\u00dd\u0007\u008d\u008c¾/\u00db/\u001c\u0016\u00ca\u00e6\u0014\u00ed¡\u00c1\u001cFwp$¨<4a;\u000b^\u00de\u00d0\u008b¶\u0014\u009fD\u00fe\u001dU\u00f3,\u00e1\u0016H1\u00f5°\u00f3\u0096/?\u0090º\u00e0\u000b;r)\u00e6\u00c2\u00112\u0094\u00eb\u00c1\\ \u009f\u0013$\u00c0N\u00c5<Q\u0015\u01abp\u01c8\u00966\u00fe\u009a\n\u00d53\u00c9i©\u001d\u01ab\u00d5#H\u0000@\u0152\u016aa").length();
        int n3 = 11;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n5 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    int length;
                    int n7;
                    final int n6 = n7 = (length = charArray.length);
                    int n8 = 0;
                    while (true) {
                        Label_0252: {
                            if (n6 > 1) {
                                break Label_0252;
                            }
                            length = (n7 = n8);
                            do {
                                final char c = charArray[n7];
                                char c2 = '\0';
                                switch (n8 % 7) {
                                    case 0: {
                                        c2 = 'O';
                                        break;
                                    }
                                    case 1: {
                                        c2 = '1';
                                        break;
                                    }
                                    case 2: {
                                        c2 = '\u0014';
                                        break;
                                    }
                                    case 3: {
                                        c2 = '4';
                                        break;
                                    }
                                    case 4: {
                                        c2 = '\u0019';
                                        break;
                                    }
                                    case 5: {
                                        c2 = '1';
                                        break;
                                    }
                                    default: {
                                        c2 = 'a';
                                        break;
                                    }
                                }
                                charArray[length] = (char)(c ^ c2);
                                ++n8;
                            } while (n6 == 0);
                        }
                        if (n6 > n8) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n5) {
                        default: {
                            i[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u001a]³\u0087\u00875Y)\u0006\u00fdi2¦t\u000e").length();
                            n3 = 8;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            i[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n5 = 0;
                }
            }
            break;
        }
        k = i;
        l = new String[47];
    }
    
    private static String a(final int n, int n2, final int n3) {
        final int n4 = (n ^ n3 ^ 0x7D2C) & 0xFFFF;
        if (c.l[n4] == null) {
            final char[] charArray = c.k[n4].toCharArray();
            int n5 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n5 = 45;
                    break;
                }
                case 1: {
                    n5 = 145;
                    break;
                }
                case 2: {
                    n5 = 142;
                    break;
                }
                case 3: {
                    n5 = 59;
                    break;
                }
                case 4: {
                    n5 = 197;
                    break;
                }
                case 5: {
                    n5 = 124;
                    break;
                }
                case 6: {
                    n5 = 184;
                    break;
                }
                case 7: {
                    n5 = 121;
                    break;
                }
                case 8: {
                    n5 = 209;
                    break;
                }
                case 9: {
                    n5 = 134;
                    break;
                }
                case 10: {
                    n5 = 28;
                    break;
                }
                case 11: {
                    n5 = 217;
                    break;
                }
                case 12: {
                    n5 = 57;
                    break;
                }
                case 13: {
                    n5 = 119;
                    break;
                }
                case 14: {
                    n5 = 39;
                    break;
                }
                case 15: {
                    n5 = 66;
                    break;
                }
                case 16: {
                    n5 = 102;
                    break;
                }
                case 17: {
                    n5 = 228;
                    break;
                }
                case 18: {
                    n5 = 109;
                    break;
                }
                case 19: {
                    n5 = 54;
                    break;
                }
                case 20: {
                    n5 = 8;
                    break;
                }
                case 21: {
                    n5 = 89;
                    break;
                }
                case 22: {
                    n5 = 101;
                    break;
                }
                case 23: {
                    n5 = 93;
                    break;
                }
                case 24: {
                    n5 = 154;
                    break;
                }
                case 25: {
                    n5 = 226;
                    break;
                }
                case 26: {
                    n5 = 122;
                    break;
                }
                case 27: {
                    n5 = 148;
                    break;
                }
                case 28: {
                    n5 = 9;
                    break;
                }
                case 29: {
                    n5 = 216;
                    break;
                }
                case 30: {
                    n5 = 0;
                    break;
                }
                case 31: {
                    n5 = 192;
                    break;
                }
                case 32: {
                    n5 = 203;
                    break;
                }
                case 33: {
                    n5 = 212;
                    break;
                }
                case 34: {
                    n5 = 199;
                    break;
                }
                case 35: {
                    n5 = 35;
                    break;
                }
                case 36: {
                    n5 = 117;
                    break;
                }
                case 37: {
                    n5 = 112;
                    break;
                }
                case 38: {
                    n5 = 155;
                    break;
                }
                case 39: {
                    n5 = 223;
                    break;
                }
                case 40: {
                    n5 = 229;
                    break;
                }
                case 41: {
                    n5 = 234;
                    break;
                }
                case 42: {
                    n5 = 53;
                    break;
                }
                case 43: {
                    n5 = 158;
                    break;
                }
                case 44: {
                    n5 = 6;
                    break;
                }
                case 45: {
                    n5 = 94;
                    break;
                }
                case 46: {
                    n5 = 36;
                    break;
                }
                case 47: {
                    n5 = 161;
                    break;
                }
                case 48: {
                    n5 = 131;
                    break;
                }
                case 49: {
                    n5 = 11;
                    break;
                }
                case 50: {
                    n5 = 18;
                    break;
                }
                case 51: {
                    n5 = 108;
                    break;
                }
                case 52: {
                    n5 = 159;
                    break;
                }
                case 53: {
                    n5 = 198;
                    break;
                }
                case 54: {
                    n5 = 206;
                    break;
                }
                case 55: {
                    n5 = 246;
                    break;
                }
                case 56: {
                    n5 = 147;
                    break;
                }
                case 57: {
                    n5 = 128;
                    break;
                }
                case 58: {
                    n5 = 191;
                    break;
                }
                case 59: {
                    n5 = 175;
                    break;
                }
                case 60: {
                    n5 = 63;
                    break;
                }
                case 61: {
                    n5 = 52;
                    break;
                }
                case 62: {
                    n5 = 74;
                    break;
                }
                case 63: {
                    n5 = 130;
                    break;
                }
                case 64: {
                    n5 = 104;
                    break;
                }
                case 65: {
                    n5 = 171;
                    break;
                }
                case 66: {
                    n5 = 213;
                    break;
                }
                case 67: {
                    n5 = 40;
                    break;
                }
                case 68: {
                    n5 = 172;
                    break;
                }
                case 69: {
                    n5 = 111;
                    break;
                }
                case 70: {
                    n5 = 127;
                    break;
                }
                case 71: {
                    n5 = 72;
                    break;
                }
                case 72: {
                    n5 = 1;
                    break;
                }
                case 73: {
                    n5 = 24;
                    break;
                }
                case 74: {
                    n5 = 241;
                    break;
                }
                case 75: {
                    n5 = 178;
                    break;
                }
                case 76: {
                    n5 = 181;
                    break;
                }
                case 77: {
                    n5 = 29;
                    break;
                }
                case 78: {
                    n5 = 13;
                    break;
                }
                case 79: {
                    n5 = 156;
                    break;
                }
                case 80: {
                    n5 = 14;
                    break;
                }
                case 81: {
                    n5 = 201;
                    break;
                }
                case 82: {
                    n5 = 227;
                    break;
                }
                case 83: {
                    n5 = 239;
                    break;
                }
                case 84: {
                    n5 = 62;
                    break;
                }
                case 85: {
                    n5 = 221;
                    break;
                }
                case 86: {
                    n5 = 249;
                    break;
                }
                case 87: {
                    n5 = 41;
                    break;
                }
                case 88: {
                    n5 = 27;
                    break;
                }
                case 89: {
                    n5 = 129;
                    break;
                }
                case 90: {
                    n5 = 76;
                    break;
                }
                case 91: {
                    n5 = 169;
                    break;
                }
                case 92: {
                    n5 = 51;
                    break;
                }
                case 93: {
                    n5 = 210;
                    break;
                }
                case 94: {
                    n5 = 79;
                    break;
                }
                case 95: {
                    n5 = 95;
                    break;
                }
                case 96: {
                    n5 = 219;
                    break;
                }
                case 97: {
                    n5 = 248;
                    break;
                }
                case 98: {
                    n5 = 43;
                    break;
                }
                case 99: {
                    n5 = 183;
                    break;
                }
                case 100: {
                    n5 = 222;
                    break;
                }
                case 101: {
                    n5 = 153;
                    break;
                }
                case 102: {
                    n5 = 30;
                    break;
                }
                case 103: {
                    n5 = 7;
                    break;
                }
                case 104: {
                    n5 = 113;
                    break;
                }
                case 105: {
                    n5 = 114;
                    break;
                }
                case 106: {
                    n5 = 139;
                    break;
                }
                case 107: {
                    n5 = 10;
                    break;
                }
                case 108: {
                    n5 = 204;
                    break;
                }
                case 109: {
                    n5 = 23;
                    break;
                }
                case 110: {
                    n5 = 179;
                    break;
                }
                case 111: {
                    n5 = 238;
                    break;
                }
                case 112: {
                    n5 = 68;
                    break;
                }
                case 113: {
                    n5 = 235;
                    break;
                }
                case 114: {
                    n5 = 218;
                    break;
                }
                case 115: {
                    n5 = 16;
                    break;
                }
                case 116: {
                    n5 = 20;
                    break;
                }
                case 117: {
                    n5 = 196;
                    break;
                }
                case 118: {
                    n5 = 231;
                    break;
                }
                case 119: {
                    n5 = 133;
                    break;
                }
                case 120: {
                    n5 = 125;
                    break;
                }
                case 121: {
                    n5 = 189;
                    break;
                }
                case 122: {
                    n5 = 106;
                    break;
                }
                case 123: {
                    n5 = 245;
                    break;
                }
                case 124: {
                    n5 = 92;
                    break;
                }
                case 125: {
                    n5 = 77;
                    break;
                }
                case 126: {
                    n5 = 244;
                    break;
                }
                case 127: {
                    n5 = 194;
                    break;
                }
                case 128: {
                    n5 = 56;
                    break;
                }
                case 129: {
                    n5 = 69;
                    break;
                }
                case 130: {
                    n5 = 215;
                    break;
                }
                case 131: {
                    n5 = 85;
                    break;
                }
                case 132: {
                    n5 = 166;
                    break;
                }
                case 133: {
                    n5 = 224;
                    break;
                }
                case 134: {
                    n5 = 32;
                    break;
                }
                case 135: {
                    n5 = 21;
                    break;
                }
                case 136: {
                    n5 = 12;
                    break;
                }
                case 137: {
                    n5 = 251;
                    break;
                }
                case 138: {
                    n5 = 136;
                    break;
                }
                case 139: {
                    n5 = 132;
                    break;
                }
                case 140: {
                    n5 = 2;
                    break;
                }
                case 141: {
                    n5 = 67;
                    break;
                }
                case 142: {
                    n5 = 48;
                    break;
                }
                case 143: {
                    n5 = 88;
                    break;
                }
                case 144: {
                    n5 = 81;
                    break;
                }
                case 145: {
                    n5 = 211;
                    break;
                }
                case 146: {
                    n5 = 180;
                    break;
                }
                case 147: {
                    n5 = 90;
                    break;
                }
                case 148: {
                    n5 = 200;
                    break;
                }
                case 149: {
                    n5 = 55;
                    break;
                }
                case 150: {
                    n5 = 58;
                    break;
                }
                case 151: {
                    n5 = 65;
                    break;
                }
                case 152: {
                    n5 = 242;
                    break;
                }
                case 153: {
                    n5 = 225;
                    break;
                }
                case 154: {
                    n5 = 118;
                    break;
                }
                case 155: {
                    n5 = 120;
                    break;
                }
                case 156: {
                    n5 = 33;
                    break;
                }
                case 157: {
                    n5 = 168;
                    break;
                }
                case 158: {
                    n5 = 34;
                    break;
                }
                case 159: {
                    n5 = 237;
                    break;
                }
                case 160: {
                    n5 = 173;
                    break;
                }
                case 161: {
                    n5 = 123;
                    break;
                }
                case 162: {
                    n5 = 208;
                    break;
                }
                case 163: {
                    n5 = 110;
                    break;
                }
                case 164: {
                    n5 = 230;
                    break;
                }
                case 165: {
                    n5 = 247;
                    break;
                }
                case 166: {
                    n5 = 37;
                    break;
                }
                case 167: {
                    n5 = 137;
                    break;
                }
                case 168: {
                    n5 = 195;
                    break;
                }
                case 169: {
                    n5 = 149;
                    break;
                }
                case 170: {
                    n5 = 240;
                    break;
                }
                case 171: {
                    n5 = 126;
                    break;
                }
                case 172: {
                    n5 = 163;
                    break;
                }
                case 173: {
                    n5 = 98;
                    break;
                }
                case 174: {
                    n5 = 232;
                    break;
                }
                case 175: {
                    n5 = 135;
                    break;
                }
                case 176: {
                    n5 = 186;
                    break;
                }
                case 177: {
                    n5 = 141;
                    break;
                }
                case 178: {
                    n5 = 100;
                    break;
                }
                case 179: {
                    n5 = 73;
                    break;
                }
                case 180: {
                    n5 = 233;
                    break;
                }
                case 181: {
                    n5 = 17;
                    break;
                }
                case 182: {
                    n5 = 99;
                    break;
                }
                case 183: {
                    n5 = 25;
                    break;
                }
                case 184: {
                    n5 = 31;
                    break;
                }
                case 185: {
                    n5 = 83;
                    break;
                }
                case 186: {
                    n5 = 146;
                    break;
                }
                case 187: {
                    n5 = 140;
                    break;
                }
                case 188: {
                    n5 = 75;
                    break;
                }
                case 189: {
                    n5 = 202;
                    break;
                }
                case 190: {
                    n5 = 82;
                    break;
                }
                case 191: {
                    n5 = 144;
                    break;
                }
                case 192: {
                    n5 = 42;
                    break;
                }
                case 193: {
                    n5 = 182;
                    break;
                }
                case 194: {
                    n5 = 4;
                    break;
                }
                case 195: {
                    n5 = 116;
                    break;
                }
                case 196: {
                    n5 = 152;
                    break;
                }
                case 197: {
                    n5 = 71;
                    break;
                }
                case 198: {
                    n5 = 80;
                    break;
                }
                case 199: {
                    n5 = 46;
                    break;
                }
                case 200: {
                    n5 = 157;
                    break;
                }
                case 201: {
                    n5 = 167;
                    break;
                }
                case 202: {
                    n5 = 103;
                    break;
                }
                case 203: {
                    n5 = 38;
                    break;
                }
                case 204: {
                    n5 = 254;
                    break;
                }
                case 205: {
                    n5 = 60;
                    break;
                }
                case 206: {
                    n5 = 64;
                    break;
                }
                case 207: {
                    n5 = 162;
                    break;
                }
                case 208: {
                    n5 = 3;
                    break;
                }
                case 209: {
                    n5 = 87;
                    break;
                }
                case 210: {
                    n5 = 190;
                    break;
                }
                case 211: {
                    n5 = 165;
                    break;
                }
                case 212: {
                    n5 = 86;
                    break;
                }
                case 213: {
                    n5 = 176;
                    break;
                }
                case 214: {
                    n5 = 15;
                    break;
                }
                case 215: {
                    n5 = 78;
                    break;
                }
                case 216: {
                    n5 = 164;
                    break;
                }
                case 217: {
                    n5 = 150;
                    break;
                }
                case 218: {
                    n5 = 107;
                    break;
                }
                case 219: {
                    n5 = 22;
                    break;
                }
                case 220: {
                    n5 = 250;
                    break;
                }
                case 221: {
                    n5 = 214;
                    break;
                }
                case 222: {
                    n5 = 252;
                    break;
                }
                case 223: {
                    n5 = 143;
                    break;
                }
                case 224: {
                    n5 = 243;
                    break;
                }
                case 225: {
                    n5 = 205;
                    break;
                }
                case 226: {
                    n5 = 151;
                    break;
                }
                case 227: {
                    n5 = 170;
                    break;
                }
                case 228: {
                    n5 = 44;
                    break;
                }
                case 229: {
                    n5 = 138;
                    break;
                }
                case 230: {
                    n5 = 50;
                    break;
                }
                case 231: {
                    n5 = 177;
                    break;
                }
                case 232: {
                    n5 = 253;
                    break;
                }
                case 233: {
                    n5 = 47;
                    break;
                }
                case 234: {
                    n5 = 220;
                    break;
                }
                case 235: {
                    n5 = 84;
                    break;
                }
                case 236: {
                    n5 = 193;
                    break;
                }
                case 237: {
                    n5 = 255;
                    break;
                }
                case 238: {
                    n5 = 61;
                    break;
                }
                case 239: {
                    n5 = 160;
                    break;
                }
                case 240: {
                    n5 = 49;
                    break;
                }
                case 241: {
                    n5 = 91;
                    break;
                }
                case 242: {
                    n5 = 105;
                    break;
                }
                case 243: {
                    n5 = 26;
                    break;
                }
                case 244: {
                    n5 = 187;
                    break;
                }
                case 245: {
                    n5 = 5;
                    break;
                }
                case 246: {
                    n5 = 97;
                    break;
                }
                case 247: {
                    n5 = 174;
                    break;
                }
                case 248: {
                    n5 = 185;
                    break;
                }
                case 249: {
                    n5 = 236;
                    break;
                }
                case 250: {
                    n5 = 70;
                    break;
                }
                case 251: {
                    n5 = 19;
                    break;
                }
                case 252: {
                    n5 = 207;
                    break;
                }
                case 253: {
                    n5 = 188;
                    break;
                }
                case 254: {
                    n5 = 115;
                    break;
                }
                default: {
                    n5 = 96;
                    break;
                }
            }
            final int n6 = n5;
            int n7 = ((n2 ^= n3) & 0xFF) - n6;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            int n8 = ((n2 & 0xFFFF) >>> 8) - n6;
            if (n8 < '\0') {
                n8 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n9 = i % 2;
                final char[] array = charArray;
                final int n10 = i;
                final char c = array[n10];
                if (n9 == 0) {
                    array[n10] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n10] = (char)(c ^ n8);
                    n8 = (((n8 >>> 3 | n8 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            c.l[n4] = new String(charArray).intern();
        }
        return c.l[n4];
    }
}
