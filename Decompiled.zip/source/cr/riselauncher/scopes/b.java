// 
// Decompiled by Procyon v0.5.36
// 

package cr.riselauncher.scopes;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.Node;
import cr.application.RiseApplication;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.text.Text;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import cr.application.k;

public class b extends k
{
    public AnchorPane p;
    public AnchorPane j;
    public ImageView e;
    public Rectangle k;
    public ImageView m;
    public Circle o;
    public Circle s;
    public Rectangle r;
    public Text t;
    public Text a;
    public Text f;
    public ImageView n;
    public ImageView q;
    public ImageView i;
    public ImageView d;
    public ImageView c;
    public Rectangle l;
    public Text g;
    public Text v;
    public Rectangle u;
    public ProgressIndicator h;
    private static final String[] x;
    private static final String[] y;
    
    public b(final RiseApplication riseApplication) {
        super(riseApplication);
    }
    
    @Override
    public void f(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: iconst_0       
        //    13: anewarray       Ljava/lang/Object;
        //    16: invokestatic    invokestatic   !!! ERROR
        //    19: astore          4
        //    21: aload_0        
        //    22: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //    25: aload           4
        //    27: ldc             -452322570
        //    29: sipush          -18697
        //    32: iadd           
        //    33: ldc             -452322570
        //    35: sipush          -25523
        //    38: iadd           
        //    39: lload_2        
        //    40: l2i            
        //    41: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    44: iconst_1       
        //    45: anewarray       Ljava/lang/Object;
        //    48: dup_x1         
        //    49: swap           
        //    50: iconst_0       
        //    51: swap           
        //    52: aastore        
        //    53: invokevirtual   invokevirtual  !!! ERROR
        //    56: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    59: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //    62: aload_0        
        //    63: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //    66: iconst_0       
        //    67: anewarray       Ljava/lang/Object;
        //    70: invokestatic    invokestatic   !!! ERROR
        //    73: ldc             -452322570
        //    75: sipush          -18717
        //    78: iadd           
        //    79: ldc             -452322570
        //    81: sipush          -27584
        //    84: iadd           
        //    85: lload_2        
        //    86: l2i            
        //    87: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    90: iconst_1       
        //    91: anewarray       Ljava/lang/Object;
        //    94: dup_x1         
        //    95: swap           
        //    96: iconst_0       
        //    97: swap           
        //    98: aastore        
        //    99: invokevirtual   invokevirtual  !!! ERROR
        //   102: invokevirtual   java/lang/String.toUpperCase:()Ljava/lang/String;
        //   105: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //   108: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean c(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: getstatic       cr/riselauncher/scopes/c.j:Z
        //    15: iconst_0       
        //    16: anewarray       Ljava/lang/Object;
        //    19: invokestatic    invokestatic   !!! ERROR
        //    22: astore          5
        //    24: istore          4
        //    26: aload_0        
        //    27: iconst_0       
        //    28: anewarray       Ljava/lang/Object;
        //    31: invokevirtual   cr/riselauncher/scopes/b.b:([Ljava/lang/Object;)Z
        //    34: iload           4
        //    36: ifne            131
        //    39: ifeq            130
        //    42: goto            46
        //    45: athrow         
        //    46: aload_0        
        //    47: getfield        cr/riselauncher/scopes/b.b:Lcr/application/RiseApplication;
        //    50: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //    53: aload           5
        //    55: ldc             -1807979580
        //    57: sipush          -29452
        //    60: i2c            
        //    61: ineg           
        //    62: iadd           
        //    63: ldc             -1807979580
        //    65: sipush          -16540
        //    68: i2c            
        //    69: ineg           
        //    70: iadd           
        //    71: lload_2        
        //    72: l2i            
        //    73: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    76: iconst_1       
        //    77: anewarray       Ljava/lang/Object;
        //    80: dup_x1         
        //    81: swap           
        //    82: iconst_0       
        //    83: swap           
        //    84: aastore        
        //    85: invokevirtual   invokevirtual  !!! ERROR
        //    88: aload           5
        //    90: ldc             -1807979580
        //    92: sipush          -29444
        //    95: i2c            
        //    96: ineg           
        //    97: iadd           
        //    98: ldc             -1807979580
        //   100: sipush          -27616
        //   103: iadd           
        //   104: lload_2        
        //   105: l2i            
        //   106: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   109: iconst_1       
        //   110: anewarray       Ljava/lang/Object;
        //   113: dup_x1         
        //   114: swap           
        //   115: iconst_0       
        //   116: swap           
        //   117: aastore        
        //   118: invokevirtual   invokevirtual  !!! ERROR
        //   121: getstatic       cr/application/a.CONFIRM:Lcr/application/a;
        //   124: invokevirtual   cr/application/RisePopup.a:(Ljava/lang/String;Ljava/lang/String;Lcr/application/a;)V
        //   127: iconst_1       
        //   128: ireturn        
        //   129: athrow         
        //   130: iconst_0       
        //   131: ireturn        
        //    StackMapTable: 00 05 FF 00 2D 00 05 07 00 02 07 00 63 04 01 07 00 41 00 01 07 00 59 00 F7 00 52 07 00 59 00 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  26     42     45     46     Ljava/lang/IllegalStateException;
        //  39     129    129    130    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void p(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          0
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          33969504163294
        //    24: lxor           
        //    25: lstore          6
        //    27: pop2           
        //    28: aload_0        
        //    29: lload           4
        //    31: iconst_1       
        //    32: anewarray       Ljava/lang/Object;
        //    35: dup_x2         
        //    36: dup_x2         
        //    37: pop            
        //    38: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    41: iconst_0       
        //    42: swap           
        //    43: aastore        
        //    44: invokespecial   cr/application/k.p:([Ljava/lang/Object;)V
        //    47: aload_0        
        //    48: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //    51: aload_0        
        //    52: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //    55: invokevirtual   javafx/scene/image/ImageView.getImage:()Ljavafx/scene/image/Image;
        //    58: lload           6
        //    60: dup2_x1        
        //    61: pop2           
        //    62: getstatic       getstatic      !!! ERROR
        //    65: iconst_3       
        //    66: anewarray       Ljava/lang/Object;
        //    69: dup_x1         
        //    70: swap           
        //    71: iconst_2       
        //    72: swap           
        //    73: aastore        
        //    74: dup_x1         
        //    75: swap           
        //    76: iconst_1       
        //    77: swap           
        //    78: aastore        
        //    79: dup_x2         
        //    80: dup_x2         
        //    81: pop            
        //    82: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    85: iconst_0       
        //    86: swap           
        //    87: aastore        
        //    88: invokestatic    cr/application/c.a:([Ljava/lang/Object;)Ljavafx/scene/image/Image;
        //    91: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //    94: aload_0        
        //    95: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //    98: aload_0        
        //    99: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //   102: invokevirtual   javafx/scene/image/ImageView.getImage:()Ljavafx/scene/image/Image;
        //   105: lload           6
        //   107: dup2_x1        
        //   108: pop2           
        //   109: getstatic       getstatic      !!! ERROR
        //   112: iconst_3       
        //   113: anewarray       Ljava/lang/Object;
        //   116: dup_x1         
        //   117: swap           
        //   118: iconst_2       
        //   119: swap           
        //   120: aastore        
        //   121: dup_x1         
        //   122: swap           
        //   123: iconst_1       
        //   124: swap           
        //   125: aastore        
        //   126: dup_x2         
        //   127: dup_x2         
        //   128: pop            
        //   129: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   132: iconst_0       
        //   133: swap           
        //   134: aastore        
        //   135: invokestatic    cr/application/c.a:([Ljava/lang/Object;)Ljavafx/scene/image/Image;
        //   138: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //   141: aload_0        
        //   142: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //   145: aload_0        
        //   146: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //   149: invokevirtual   javafx/scene/image/ImageView.getImage:()Ljavafx/scene/image/Image;
        //   152: lload           6
        //   154: dup2_x1        
        //   155: pop2           
        //   156: getstatic       getstatic      !!! ERROR
        //   159: iconst_3       
        //   160: anewarray       Ljava/lang/Object;
        //   163: dup_x1         
        //   164: swap           
        //   165: iconst_2       
        //   166: swap           
        //   167: aastore        
        //   168: dup_x1         
        //   169: swap           
        //   170: iconst_1       
        //   171: swap           
        //   172: aastore        
        //   173: dup_x2         
        //   174: dup_x2         
        //   175: pop            
        //   176: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   179: iconst_0       
        //   180: swap           
        //   181: aastore        
        //   182: invokestatic    cr/application/c.a:([Ljava/lang/Object;)Ljavafx/scene/image/Image;
        //   185: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //   188: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:111)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:621)
        //     at com.strobel.assembler.metadata.FieldReference.resolve(FieldReference.java:61)
        //     at com.strobel.decompiler.ast.TypeAnalysis.getFieldType(TypeAnalysis.java:2920)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1051)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void a(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljavafx/scene/Node;
        //     7: astore_3       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljava/lang/Long;
        //    14: invokevirtual   java/lang/Long.longValue:()J
        //    17: lstore          4
        //    19: dup            
        //    20: iconst_2       
        //    21: aaload         
        //    22: checkcast       Ljavafx/scene/input/MouseEvent;
        //    25: astore_2       
        //    26: pop            
        //    27: lload           4
        //    29: dup2           
        //    30: ldc2_w          56631128108880
        //    33: lxor           
        //    34: lstore          6
        //    36: dup2           
        //    37: ldc2_w          50469250955
        //    40: lxor           
        //    41: lstore          8
        //    43: dup2           
        //    44: ldc2_w          100345753271679
        //    47: lxor           
        //    48: lstore          10
        //    50: dup2           
        //    51: ldc2_w          90516605143087
        //    54: lxor           
        //    55: lstore          12
        //    57: pop2           
        //    58: getstatic       cr/riselauncher/scopes/c.j:Z
        //    61: istore          14
        //    63: aload_3        
        //    64: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //    67: iload           14
        //    69: ifne            84
        //    72: ifnonnull       80
        //    75: goto            79
        //    78: athrow         
        //    79: return         
        //    80: aload_3        
        //    81: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //    84: aload_0        
        //    85: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //    88: invokevirtual   javafx/scene/image/ImageView.getId:()Ljava/lang/String;
        //    91: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    94: iload           14
        //    96: ifne            205
        //    99: ifeq            191
        //   102: goto            106
        //   105: athrow         
        //   106: aload_0        
        //   107: iload           14
        //   109: ifne            144
        //   112: goto            116
        //   115: athrow         
        //   116: lload           10
        //   118: iconst_1       
        //   119: anewarray       Ljava/lang/Object;
        //   122: dup_x2         
        //   123: dup_x2         
        //   124: pop            
        //   125: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   128: iconst_0       
        //   129: swap           
        //   130: aastore        
        //   131: invokevirtual   cr/riselauncher/scopes/b.c:([Ljava/lang/Object;)Z
        //   134: ifeq            143
        //   137: goto            141
        //   140: athrow         
        //   141: return         
        //   142: athrow         
        //   143: aload_0        
        //   144: getfield        cr/riselauncher/scopes/b.b:Lcr/application/RiseApplication;
        //   147: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/g;
        //   150: ldc             79821630
        //   152: sipush          22445
        //   155: isub           
        //   156: ldc             -79821630
        //   158: sipush          -30229
        //   161: isub           
        //   162: lload           4
        //   164: l2i            
        //   165: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   168: lload           8
        //   170: iconst_2       
        //   171: anewarray       Ljava/lang/Object;
        //   174: dup_x2         
        //   175: dup_x2         
        //   176: pop            
        //   177: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   180: iconst_1       
        //   181: swap           
        //   182: aastore        
        //   183: dup_x1         
        //   184: swap           
        //   185: iconst_0       
        //   186: swap           
        //   187: aastore        
        //   188: invokevirtual   cr/application/g.c:([Ljava/lang/Object;)V
        //   191: aload_3        
        //   192: invokevirtual   javafx/scene/Node.getId:()Ljava/lang/String;
        //   195: aload_0        
        //   196: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //   199: invokevirtual   javafx/scene/image/ImageView.getId:()Ljava/lang/String;
        //   202: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   205: iload           14
        //   207: ifne            272
        //   210: ifeq            264
        //   213: goto            217
        //   216: athrow         
        //   217: aload_0        
        //   218: lload           10
        //   220: iconst_1       
        //   221: anewarray       Ljava/lang/Object;
        //   224: dup_x2         
        //   225: dup_x2         
        //   226: pop            
        //   227: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   230: iconst_0       
        //   231: swap           
        //   232: aastore        
        //   233: invokevirtual   cr/riselauncher/scopes/b.c:([Ljava/lang/Object;)Z
        //   236: ifeq            245
        //   239: goto            243
        //   242: athrow         
        //   243: return         
        //   244: athrow         
        //   245: lload           12
        //   247: iconst_1       
        //   248: anewarray       Ljava/lang/Object;
        //   251: dup_x2         
        //   252: dup_x2         
        //   253: pop            
        //   254: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   257: iconst_0       
        //   258: swap           
        //   259: aastore        
        //   260: invokestatic    invokestatic   !!! ERROR
        //   263: return         
        //   264: aload_3        
        //   265: aload_0        
        //   266: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //   269: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   272: iload           14
        //   274: ifne            296
        //   277: ifne            323
        //   280: goto            284
        //   283: athrow         
        //   284: aload_3        
        //   285: aload_0        
        //   286: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //   289: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   292: goto            296
        //   295: athrow         
        //   296: iload           14
        //   298: ifne            320
        //   301: ifne            323
        //   304: goto            308
        //   307: athrow         
        //   308: aload_3        
        //   309: aload_0        
        //   310: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //   313: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   316: goto            320
        //   319: athrow         
        //   320: ifeq            344
        //   323: aload_0        
        //   324: lload           6
        //   326: iconst_1       
        //   327: anewarray       Ljava/lang/Object;
        //   330: dup_x2         
        //   331: dup_x2         
        //   332: pop            
        //   333: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   336: iconst_0       
        //   337: swap           
        //   338: aastore        
        //   339: invokevirtual   cr/riselauncher/scopes/b.s:([Ljava/lang/Object;)V
        //   342: return         
        //   343: athrow         
        //   344: return         
        //    StackMapTable: 00 22 FF 00 4E 00 0A 07 00 02 07 00 63 07 00 9F 07 00 9D 04 04 04 04 04 01 00 01 07 00 59 00 00 43 07 00 46 54 07 00 59 00 48 07 00 59 40 07 00 02 57 07 00 59 00 40 07 00 59 00 40 07 00 02 2E 4D 01 4A 07 00 59 00 58 07 00 59 00 40 07 00 59 00 12 47 01 4A 07 00 59 00 4A 07 00 59 40 01 4A 07 00 59 00 4A 07 00 59 40 01 02 53 07 00 59 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  63     75     78     79     Ljava/lang/IllegalStateException;
        //  84     102    105    106    Ljava/lang/IllegalStateException;
        //  99     112    115    116    Ljava/lang/IllegalStateException;
        //  106    137    140    141    Ljava/lang/IllegalStateException;
        //  116    142    142    143    Ljava/lang/IllegalStateException;
        //  205    213    216    217    Ljava/lang/IllegalStateException;
        //  210    239    242    243    Ljava/lang/IllegalStateException;
        //  217    244    244    245    Ljava/lang/IllegalStateException;
        //  272    280    283    284    Ljava/lang/IllegalStateException;
        //  277    292    295    296    Ljava/lang/IllegalStateException;
        //  296    304    307    308    Ljava/lang/IllegalStateException;
        //  301    316    319    320    Ljava/lang/IllegalStateException;
        //  320    343    343    344    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void v(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: pop            
        //     2: iconst_0       
        //     3: anewarray       Ljava/lang/Object;
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: astore_2       
        //    10: aload_0        
        //    11: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //    14: aload_2        
        //    15: iconst_0       
        //    16: anewarray       Ljava/lang/Object;
        //    19: invokevirtual   invokevirtual  !!! ERROR
        //    22: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //    25: aload_2        
        //    26: iconst_0       
        //    27: anewarray       Ljava/lang/Object;
        //    30: invokevirtual   invokevirtual  !!! ERROR
        //    33: astore_3       
        //    34: aload_0        
        //    35: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //    38: aload_3        
        //    39: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //    42: aload_0        
        //    43: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //    46: iconst_0       
        //    47: anewarray       Ljava/lang/Object;
        //    50: invokestatic    invokestatic   !!! ERROR
        //    53: invokevirtual   invokevirtual  !!! ERROR
        //    56: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //    59: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void j(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          62338473346245
        //    17: lxor           
        //    18: lstore          4
        //    20: dup2           
        //    21: ldc2_w          0
        //    24: lxor           
        //    25: lstore          6
        //    27: pop2           
        //    28: aload_0        
        //    29: lload           6
        //    31: iconst_1       
        //    32: anewarray       Ljava/lang/Object;
        //    35: dup_x2         
        //    36: dup_x2         
        //    37: pop            
        //    38: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    41: iconst_0       
        //    42: swap           
        //    43: aastore        
        //    44: invokespecial   cr/application/k.j:([Ljava/lang/Object;)V
        //    47: aload_0        
        //    48: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //    51: aload_0        
        //    52: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //    55: invokevirtual   javafx/scene/image/ImageView.getImage:()Ljavafx/scene/image/Image;
        //    58: lload           4
        //    60: dup2_x1        
        //    61: pop2           
        //    62: getstatic       getstatic      !!! ERROR
        //    65: iconst_3       
        //    66: anewarray       Ljava/lang/Object;
        //    69: dup_x1         
        //    70: swap           
        //    71: iconst_2       
        //    72: swap           
        //    73: aastore        
        //    74: dup_x1         
        //    75: swap           
        //    76: iconst_1       
        //    77: swap           
        //    78: aastore        
        //    79: dup_x2         
        //    80: dup_x2         
        //    81: pop            
        //    82: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    85: iconst_0       
        //    86: swap           
        //    87: aastore        
        //    88: invokestatic    cr/application/c.a:([Ljava/lang/Object;)Ljavafx/scene/image/Image;
        //    91: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //    94: aload_0        
        //    95: iconst_0       
        //    96: anewarray       Ljava/lang/Object;
        //    99: invokevirtual   cr/riselauncher/scopes/b.v:([Ljava/lang/Object;)V
        //   102: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:111)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:621)
        //     at com.strobel.assembler.metadata.FieldReference.resolve(FieldReference.java:61)
        //     at com.strobel.decompiler.ast.TypeAnalysis.getFieldType(TypeAnalysis.java:2920)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1051)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void n(final Object[] array) {
        super.n(new Object[0]);
    }
    
    public boolean b(final Object[] array) {
        final boolean j = cr.riselauncher.scopes.c.j;
        boolean b = false;
        Label_0029: {
            ProgressIndicator progressIndicator2 = null;
            Label_0021: {
                ProgressIndicator progressIndicator;
                try {
                    progressIndicator = (progressIndicator2 = this.h);
                    if (j) {
                        break Label_0029;
                    }
                    if (progressIndicator != null) {
                        break Label_0021;
                    }
                    return false;
                }
                catch (IllegalStateException ex) {
                    throw ex;
                }
                try {
                    if (progressIndicator == null) {
                        return false;
                    }
                    progressIndicator2 = this.h;
                }
                catch (IllegalStateException ex2) {
                    throw ex2;
                }
            }
            try {
                final boolean visible;
                b = (visible = progressIndicator2.isVisible());
                if (j) {
                    return visible;
                }
                if (b) {
                    return true;
                }
                return false;
            }
            catch (IllegalStateException ex3) {
                throw ex3;
            }
        }
        try {
            if (b) {
                return true;
            }
        }
        catch (IllegalStateException ex4) {
            throw ex4;
        }
        return false;
    }
    
    public void t(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: getstatic       cr/riselauncher/scopes/c.j:Z
        //    15: istore          4
        //    17: aload_0        
        //    18: iload           4
        //    20: ifne            98
        //    23: iconst_0       
        //    24: anewarray       Ljava/lang/Object;
        //    27: invokevirtual   cr/riselauncher/scopes/b.b:([Ljava/lang/Object;)Z
        //    30: ifne            39
        //    33: goto            37
        //    36: athrow         
        //    37: return         
        //    38: athrow         
        //    39: aload_0        
        //    40: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //    43: iconst_0       
        //    44: anewarray       Ljava/lang/Object;
        //    47: invokestatic    invokestatic   !!! ERROR
        //    50: ldc             -449701170
        //    52: sipush          -3624
        //    55: i2c            
        //    56: ineg           
        //    57: iadd           
        //    58: ldc             -449701170
        //    60: sipush          -15179
        //    63: i2c            
        //    64: ineg           
        //    65: iadd           
        //    66: lload_2        
        //    67: l2i            
        //    68: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    71: iconst_1       
        //    72: anewarray       Ljava/lang/Object;
        //    75: dup_x1         
        //    76: swap           
        //    77: iconst_0       
        //    78: swap           
        //    79: aastore        
        //    80: invokevirtual   invokevirtual  !!! ERROR
        //    83: invokevirtual   java/lang/String.toUpperCase:()Ljava/lang/String;
        //    86: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //    89: aload_0        
        //    90: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //    93: iconst_0       
        //    94: invokevirtual   javafx/scene/control/ProgressIndicator.setVisible:(Z)V
        //    97: aload_0        
        //    98: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //   101: iconst_1       
        //   102: invokevirtual   javafx/scene/image/ImageView.setVisible:(Z)V
        //   105: return         
        //    StackMapTable: 00 05 FF 00 24 00 04 07 00 02 07 00 63 04 01 00 01 07 00 59 00 40 07 00 59 00 7A 07 00 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  17     33     36     37     Ljava/lang/IllegalStateException;
        //  23     38     38     39     Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void w(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/String;
        //     7: astore_2       
        //     8: dup            
        //     9: iconst_1       
        //    10: aaload         
        //    11: checkcast       Ljava/lang/Long;
        //    14: invokevirtual   java/lang/Long.longValue:()J
        //    17: lstore_3       
        //    18: pop            
        //    19: lload_3        
        //    20: dup2           
        //    21: ldc2_w          7159513077457
        //    24: lxor           
        //    25: lstore          5
        //    27: pop2           
        //    28: getstatic       cr/riselauncher/scopes/c.j:Z
        //    31: istore          7
        //    33: aload_0        
        //    34: iload           7
        //    36: ifne            75
        //    39: iconst_0       
        //    40: anewarray       Ljava/lang/Object;
        //    43: invokevirtual   cr/riselauncher/scopes/b.b:([Ljava/lang/Object;)Z
        //    46: ifne            55
        //    49: goto            53
        //    52: athrow         
        //    53: return         
        //    54: athrow         
        //    55: aload_0        
        //    56: lload           5
        //    58: iconst_1       
        //    59: anewarray       Ljava/lang/Object;
        //    62: dup_x2         
        //    63: dup_x2         
        //    64: pop            
        //    65: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    68: iconst_0       
        //    69: swap           
        //    70: aastore        
        //    71: invokevirtual   cr/riselauncher/scopes/b.t:([Ljava/lang/Object;)V
        //    74: aload_0        
        //    75: getfield        cr/riselauncher/scopes/b.b:Lcr/application/RiseApplication;
        //    78: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //    81: iconst_0       
        //    82: anewarray       Ljava/lang/Object;
        //    85: invokestatic    invokestatic   !!! ERROR
        //    88: ldc             285994740
        //    90: sipush          -3913
        //    93: i2c            
        //    94: isub           
        //    95: ldc             285863670
        //    97: sipush          -21992
        //   100: i2c            
        //   101: iadd           
        //   102: lload_3        
        //   103: l2i            
        //   104: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   107: iconst_1       
        //   108: anewarray       Ljava/lang/Object;
        //   111: dup_x1         
        //   112: swap           
        //   113: iconst_0       
        //   114: swap           
        //   115: aastore        
        //   116: invokevirtual   invokevirtual  !!! ERROR
        //   119: invokevirtual   java/lang/String.toUpperCase:()Ljava/lang/String;
        //   122: aload_2        
        //   123: getstatic       cr/application/a.CONFIRM:Lcr/application/a;
        //   126: invokevirtual   cr/application/RisePopup.a:(Ljava/lang/String;Ljava/lang/String;Lcr/application/a;)V
        //   129: return         
        //    StackMapTable: 00 05 FF 00 34 00 06 07 00 02 07 00 63 07 00 46 04 04 01 00 01 07 00 59 00 40 07 00 59 00 53 07 00 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  33     49     52     53     Ljava/lang/IllegalStateException;
        //  39     54     54     55     Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void u(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: aload_0        
        //    13: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //    16: iconst_0       
        //    17: anewarray       Ljava/lang/Object;
        //    20: invokestatic    invokestatic   !!! ERROR
        //    23: ldc             1025884890
        //    25: sipush          -10603
        //    28: i2c            
        //    29: iadd           
        //    30: ldc             -1026015960
        //    32: sipush          -6421
        //    35: i2c            
        //    36: ineg           
        //    37: isub           
        //    38: lload_2        
        //    39: l2i            
        //    40: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    43: iconst_1       
        //    44: anewarray       Ljava/lang/Object;
        //    47: dup_x1         
        //    48: swap           
        //    49: iconst_0       
        //    50: swap           
        //    51: aastore        
        //    52: invokevirtual   invokevirtual  !!! ERROR
        //    55: invokevirtual   java/lang/String.toUpperCase:()Ljava/lang/String;
        //    58: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //    61: aload_0        
        //    62: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //    65: iconst_1       
        //    66: invokevirtual   javafx/scene/control/ProgressIndicator.setVisible:(Z)V
        //    69: aload_0        
        //    70: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //    73: iconst_0       
        //    74: invokevirtual   javafx/scene/image/ImageView.setVisible:(Z)V
        //    77: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void s(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: lload_2        
        //    13: dup2           
        //    14: ldc2_w          106555580785275
        //    17: lxor           
        //    18: dup2           
        //    19: bipush          48
        //    21: lushr          
        //    22: l2i            
        //    23: istore          4
        //    25: dup2           
        //    26: bipush          16
        //    28: lshl           
        //    29: bipush          32
        //    31: lushr          
        //    32: l2i            
        //    33: istore          5
        //    35: dup2           
        //    36: bipush          48
        //    38: lshl           
        //    39: bipush          48
        //    41: lushr          
        //    42: l2i            
        //    43: istore          6
        //    45: pop2           
        //    46: dup2           
        //    47: ldc2_w          96973771063061
        //    50: lxor           
        //    51: lstore          7
        //    53: dup2           
        //    54: ldc2_w          111925454247302
        //    57: lxor           
        //    58: lstore          9
        //    60: pop2           
        //    61: getstatic       cr/riselauncher/scopes/c.j:Z
        //    64: lload           7
        //    66: ldc_w           1921486200
        //    69: sipush          174
        //    72: isub           
        //    73: ldc_w           -1921486200
        //    76: sipush          -9864
        //    79: iadd           
        //    80: lload_2        
        //    81: l2i            
        //    82: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //    85: iconst_2       
        //    86: anewarray       Ljava/lang/Object;
        //    89: dup_x1         
        //    90: swap           
        //    91: iconst_1       
        //    92: swap           
        //    93: aastore        
        //    94: dup_x2         
        //    95: dup_x2         
        //    96: pop            
        //    97: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   100: iconst_0       
        //   101: swap           
        //   102: aastore        
        //   103: invokestatic    cr/application/f.a:([Ljava/lang/Object;)V
        //   106: istore          11
        //   108: iconst_0       
        //   109: anewarray       Ljava/lang/Object;
        //   112: invokestatic    invokestatic   !!! ERROR
        //   115: astore          12
        //   117: iload           11
        //   119: ifne            199
        //   122: aload_0        
        //   123: iconst_0       
        //   124: anewarray       Ljava/lang/Object;
        //   127: invokevirtual   cr/riselauncher/scopes/b.b:([Ljava/lang/Object;)Z
        //   130: ifeq            157
        //   133: goto            137
        //   136: athrow         
        //   137: lload           9
        //   139: iconst_1       
        //   140: anewarray       Ljava/lang/Object;
        //   143: dup_x2         
        //   144: dup_x2         
        //   145: pop            
        //   146: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   149: iconst_0       
        //   150: swap           
        //   151: aastore        
        //   152: invokestatic    invokestatic   !!! ERROR
        //   155: return         
        //   156: athrow         
        //   157: lload           7
        //   159: ldc_w           1921486200
        //   162: sipush          130
        //   165: isub           
        //   166: ldc_w           1921486200
        //   169: sipush          19443
        //   172: iadd           
        //   173: lload_2        
        //   174: l2i            
        //   175: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   178: iconst_2       
        //   179: anewarray       Ljava/lang/Object;
        //   182: dup_x1         
        //   183: swap           
        //   184: iconst_1       
        //   185: swap           
        //   186: aastore        
        //   187: dup_x2         
        //   188: dup_x2         
        //   189: pop            
        //   190: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   193: iconst_0       
        //   194: swap           
        //   195: aastore        
        //   196: invokestatic    cr/application/f.a:([Ljava/lang/Object;)V
        //   199: iconst_0       
        //   200: anewarray       Ljava/lang/Object;
        //   203: invokestatic    invokestatic   !!! ERROR
        //   206: astore          13
        //   208: aload           13
        //   210: invokevirtual   invokevirtual  !!! ERROR
        //   213: iload           11
        //   215: ifne            375
        //   218: ifeq            317
        //   221: goto            225
        //   224: athrow         
        //   225: aload_0        
        //   226: iconst_0       
        //   227: anewarray       Ljava/lang/Object;
        //   230: invokevirtual   cr/riselauncher/scopes/b.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //   233: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //   236: aload           12
        //   238: ldc_w           1921486200
        //   241: bipush          125
        //   243: isub           
        //   244: ldc_w           -1921486200
        //   247: sipush          -17747
        //   250: iadd           
        //   251: lload_2        
        //   252: l2i            
        //   253: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   256: iconst_1       
        //   257: anewarray       Ljava/lang/Object;
        //   260: dup_x1         
        //   261: swap           
        //   262: iconst_0       
        //   263: swap           
        //   264: aastore        
        //   265: invokevirtual   invokevirtual  !!! ERROR
        //   268: aload           12
        //   270: ldc_w           1921486200
        //   273: sipush          134
        //   276: isub           
        //   277: ldc_w           1921486200
        //   280: sipush          5703
        //   283: iadd           
        //   284: lload_2        
        //   285: l2i            
        //   286: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   289: iconst_1       
        //   290: anewarray       Ljava/lang/Object;
        //   293: dup_x1         
        //   294: swap           
        //   295: iconst_0       
        //   296: swap           
        //   297: aastore        
        //   298: invokevirtual   invokevirtual  !!! ERROR
        //   301: new             Lcr/riselauncher/scopes/b$a;
        //   304: dup            
        //   305: aload_0        
        //   306: invokespecial   cr/riselauncher/scopes/b$a.<init>:(Lcr/riselauncher/scopes/b;)V
        //   309: getstatic       cr/application/a.CONFIRM:Lcr/application/a;
        //   312: invokevirtual   cr/application/RisePopup.a:(Ljava/lang/String;Ljava/lang/String;Lcr/application/i;Lcr/application/a;)V
        //   315: return         
        //   316: athrow         
        //   317: lload           7
        //   319: ldc_w           1921486200
        //   322: sipush          136
        //   325: isub           
        //   326: ldc_w           1921486200
        //   329: sipush          25203
        //   332: iadd           
        //   333: lload_2        
        //   334: l2i            
        //   335: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   338: iconst_2       
        //   339: anewarray       Ljava/lang/Object;
        //   342: dup_x1         
        //   343: swap           
        //   344: iconst_1       
        //   345: swap           
        //   346: aastore        
        //   347: dup_x2         
        //   348: dup_x2         
        //   349: pop            
        //   350: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   353: iconst_0       
        //   354: swap           
        //   355: aastore        
        //   356: invokestatic    cr/application/f.a:([Ljava/lang/Object;)V
        //   359: iload           11
        //   361: ifne            552
        //   364: iconst_0       
        //   365: anewarray       Ljava/lang/Object;
        //   368: invokestatic    invokestatic   !!! ERROR
        //   371: goto            375
        //   374: athrow         
        //   375: ifeq            471
        //   378: aload_0        
        //   379: iconst_0       
        //   380: anewarray       Ljava/lang/Object;
        //   383: invokevirtual   cr/riselauncher/scopes/b.a:([Ljava/lang/Object;)Lcr/application/RiseApplication;
        //   386: invokevirtual   cr/application/RiseApplication.a:()Lcr/application/RisePopup;
        //   389: aload           12
        //   391: ldc_w           1921486200
        //   394: sipush          135
        //   397: isub           
        //   398: ldc_w           1921486200
        //   401: sipush          29129
        //   404: iadd           
        //   405: lload_2        
        //   406: l2i            
        //   407: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   410: iconst_1       
        //   411: anewarray       Ljava/lang/Object;
        //   414: dup_x1         
        //   415: swap           
        //   416: iconst_0       
        //   417: swap           
        //   418: aastore        
        //   419: invokevirtual   invokevirtual  !!! ERROR
        //   422: aload           12
        //   424: ldc_w           1921486200
        //   427: sipush          140
        //   430: isub           
        //   431: ldc_w           -1921486200
        //   434: sipush          -2230
        //   437: isub           
        //   438: lload_2        
        //   439: l2i            
        //   440: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   443: iconst_1       
        //   444: anewarray       Ljava/lang/Object;
        //   447: dup_x1         
        //   448: swap           
        //   449: iconst_0       
        //   450: swap           
        //   451: aastore        
        //   452: invokevirtual   invokevirtual  !!! ERROR
        //   455: new             Lcr/riselauncher/scopes/b$c;
        //   458: dup            
        //   459: aload_0        
        //   460: invokespecial   cr/riselauncher/scopes/b$c.<init>:(Lcr/riselauncher/scopes/b;)V
        //   463: getstatic       cr/application/a.YES_NO:Lcr/application/a;
        //   466: invokevirtual   cr/application/RisePopup.a:(Ljava/lang/String;Ljava/lang/String;Lcr/application/i;Lcr/application/a;)V
        //   469: return         
        //   470: athrow         
        //   471: lload           7
        //   473: ldc_w           1921486200
        //   476: sipush          138
        //   479: isub           
        //   480: ldc_w           -1921486200
        //   483: sipush          -11162
        //   486: iadd           
        //   487: lload_2        
        //   488: l2i            
        //   489: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   492: iconst_2       
        //   493: anewarray       Ljava/lang/Object;
        //   496: dup_x1         
        //   497: swap           
        //   498: iconst_1       
        //   499: swap           
        //   500: aastore        
        //   501: dup_x2         
        //   502: dup_x2         
        //   503: pop            
        //   504: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //   507: iconst_0       
        //   508: swap           
        //   509: aastore        
        //   510: invokestatic    cr/application/f.a:([Ljava/lang/Object;)V
        //   513: iload           4
        //   515: i2s            
        //   516: iload           5
        //   518: iload           6
        //   520: i2c            
        //   521: iconst_3       
        //   522: anewarray       Ljava/lang/Object;
        //   525: dup_x1         
        //   526: swap           
        //   527: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   530: iconst_2       
        //   531: swap           
        //   532: aastore        
        //   533: dup_x1         
        //   534: swap           
        //   535: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   538: iconst_1       
        //   539: swap           
        //   540: aastore        
        //   541: dup_x1         
        //   542: swap           
        //   543: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   546: iconst_0       
        //   547: swap           
        //   548: aastore        
        //   549: invokestatic    invokestatic   !!! ERROR
        //   552: return         
        //    StackMapTable: 00 0E FF 00 88 00 0A 07 00 02 07 00 63 04 01 01 01 04 04 01 07 00 41 00 01 07 00 59 00 52 07 00 59 00 29 FF 00 18 00 0B 07 00 02 07 00 63 04 01 01 01 04 04 01 07 00 41 07 00 D8 00 01 07 00 59 00 F7 00 5A 07 00 59 00 78 07 00 59 40 01 F7 00 5E 07 00 59 00 FB 00 50
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  117    133    136    137    Ljava/lang/IllegalStateException;
        //  122    156    156    157    Ljava/lang/IllegalStateException;
        //  208    221    224    225    Ljava/lang/IllegalStateException;
        //  218    316    316    317    Ljava/lang/IllegalStateException;
        //  317    371    374    375    Ljava/lang/IllegalStateException;
        //  375    470    470    471    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:91)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.ClassFileReader.populateNamedInnerTypes(ClassFileReader.java:698)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:442)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataHelper.isRawType(MetadataHelper.java:1581)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visitClassType(MetadataHelper.java:2369)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visitClassType(MetadataHelper.java:2322)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.accept(CoreMetadataFactory.java:577)
        //     at com.strobel.assembler.metadata.MetadataHelper$SameTypeVisitor.visit(MetadataHelper.java:2336)
        //     at com.strobel.assembler.metadata.MetadataHelper.isSameType(MetadataHelper.java:1411)
        //     at com.strobel.assembler.metadata.TypeReference.equals(TypeReference.java:118)
        //     at com.strobel.core.Comparer.equals(Comparer.java:31)
        //     at com.strobel.assembler.ir.FrameValue.equals(FrameValue.java:72)
        //     at com.strobel.core.Comparer.equals(Comparer.java:31)
        //     at com.strobel.assembler.ir.Frame.merge(Frame.java:338)
        //     at com.strobel.assembler.ir.Frame.merge(Frame.java:273)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2206)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public String a(final Object[] array) {
        return a(2079949830 + 13378, -2079949830 - 15488, (int)(long)array[0]);
    }
    
    @Override
    public void i(final Object[] array) {
        final long longValue = (long)array[0];
        final Node node = (Node)array[1];
        final long l = longValue ^ 0x2FD863DDBD83L;
        final boolean j = cr.riselauncher.scopes.c.j;
        Node node3 = null;
        Label_0070: {
            Object o = null;
            Label_0055: {
                Label_0053: {
                    Node node2;
                    try {
                        node2 = (Node)(o = (node3 = node));
                        if (j) {
                            break Label_0055;
                        }
                        final String s = node2.getId();
                        if (s == null) {
                            return;
                        }
                        break Label_0053;
                    }
                    catch (IllegalStateException ex) {
                        throw ex;
                    }
                    try {
                        final String s = node2.getId();
                        if (s == null) {
                            return;
                        }
                    }
                    catch (IllegalStateException ex2) {
                        throw ex2;
                    }
                }
                node3 = (Node)(o = node);
                try {
                    if (j) {
                        break Label_0070;
                    }
                    final boolean b = o instanceof ImageView;
                    if (b) {
                        break Label_0070;
                    }
                    return;
                }
                catch (IllegalStateException ex3) {
                    throw ex3;
                }
            }
            try {
                final boolean b = o instanceof ImageView;
                if (!b) {
                    return;
                }
                node3 = node;
            }
            catch (IllegalStateException ex4) {
                throw ex4;
            }
        }
        final ImageView imageView = (ImageView)node3;
        Label_0140: {
            boolean b3 = false;
            Label_0127: {
                boolean equals = false;
                Label_0115: {
                    Label_0102: {
                        boolean b2;
                        try {
                            b2 = (equals = (b3 = node.equals(this.d)));
                            if (j) {
                                break Label_0115;
                            }
                            if (!b2) {
                                break Label_0102;
                            }
                            break Label_0140;
                        }
                        catch (IllegalStateException ex5) {
                            throw ex5;
                        }
                        try {
                            if (b2) {
                                break Label_0140;
                            }
                            b3 = (equals = node.equals(this.q));
                        }
                        catch (IllegalStateException ex6) {
                            throw ex6;
                        }
                    }
                    try {
                        if (j) {
                            break Label_0140;
                        }
                        if (!equals) {
                            break Label_0127;
                        }
                        break Label_0140;
                    }
                    catch (IllegalStateException ex7) {
                        throw ex7;
                    }
                }
                try {
                    if (equals) {
                        break Label_0140;
                    }
                    b3 = node.equals(this.n);
                }
                catch (IllegalStateException ex8) {
                    throw ex8;
                }
            }
            try {
                if (b3) {
                    imageView.setImage(cr.application.c.a(new Object[] { l, imageView.getImage(), Color.WHITE }));
                }
            }
            catch (IllegalStateException ex9) {
                throw ex9;
            }
        }
    }
    
    @Override
    public void l(final Object[] array) {
        final long longValue = (long)array[0];
        final Node node = (Node)array[1];
        final long l = longValue ^ 0x22617CA7E5F6L;
        final boolean j = cr.riselauncher.scopes.c.j;
        Node node3 = null;
        Label_0070: {
            Object o = null;
            Label_0055: {
                Label_0053: {
                    Node node2;
                    try {
                        node2 = (Node)(o = (node3 = node));
                        if (j) {
                            break Label_0055;
                        }
                        final String s = node2.getId();
                        if (s == null) {
                            return;
                        }
                        break Label_0053;
                    }
                    catch (IllegalStateException ex) {
                        throw ex;
                    }
                    try {
                        final String s = node2.getId();
                        if (s == null) {
                            return;
                        }
                    }
                    catch (IllegalStateException ex2) {
                        throw ex2;
                    }
                }
                node3 = (Node)(o = node);
                try {
                    if (j) {
                        break Label_0070;
                    }
                    final boolean b = o instanceof ImageView;
                    if (b) {
                        break Label_0070;
                    }
                    return;
                }
                catch (IllegalStateException ex3) {
                    throw ex3;
                }
            }
            try {
                final boolean b = o instanceof ImageView;
                if (!b) {
                    return;
                }
                node3 = node;
            }
            catch (IllegalStateException ex4) {
                throw ex4;
            }
        }
        final ImageView imageView = (ImageView)node3;
        Label_0140: {
            boolean b3 = false;
            Label_0127: {
                boolean equals = false;
                Label_0115: {
                    Label_0102: {
                        boolean b2;
                        try {
                            b2 = (equals = (b3 = node.equals(this.d)));
                            if (j) {
                                break Label_0115;
                            }
                            if (!b2) {
                                break Label_0102;
                            }
                            break Label_0140;
                        }
                        catch (IllegalStateException ex5) {
                            throw ex5;
                        }
                        try {
                            if (b2) {
                                break Label_0140;
                            }
                            b3 = (equals = node.equals(this.q));
                        }
                        catch (IllegalStateException ex6) {
                            throw ex6;
                        }
                    }
                    try {
                        if (j) {
                            break Label_0140;
                        }
                        if (!equals) {
                            break Label_0127;
                        }
                        break Label_0140;
                    }
                    catch (IllegalStateException ex7) {
                        throw ex7;
                    }
                }
                try {
                    if (equals) {
                        break Label_0140;
                    }
                    b3 = node.equals(this.n);
                }
                catch (IllegalStateException ex8) {
                    throw ex8;
                }
            }
            try {
                if (b3) {
                    imageView.setImage(cr.application.c.a(new Object[] { l, imageView.getImage(), Color.GRAY }));
                }
            }
            catch (IllegalStateException ex9) {
                throw ex9;
            }
        }
    }
    
    @Override
    public Pane c(final Object[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: iconst_0       
        //     3: aaload         
        //     4: checkcast       Ljava/lang/Long;
        //     7: invokevirtual   java/lang/Long.longValue:()J
        //    10: lstore_2       
        //    11: pop            
        //    12: iconst_0       
        //    13: anewarray       Ljava/lang/Object;
        //    16: invokestatic    invokestatic   !!! ERROR
        //    19: astore          6
        //    21: aload_0        
        //    22: new             Ljavafx/scene/layout/AnchorPane;
        //    25: dup            
        //    26: invokespecial   javafx/scene/layout/AnchorPane.<init>:()V
        //    29: putfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    32: aload_0        
        //    33: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    36: ldc2_w          -1.0
        //    39: invokevirtual   javafx/scene/layout/AnchorPane.setMinHeight:(D)V
        //    42: aload_0        
        //    43: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    46: ldc2_w          600.0
        //    49: invokevirtual   javafx/scene/layout/AnchorPane.setPrefHeight:(D)V
        //    52: aload_0        
        //    53: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    56: ldc2_w          -1.0
        //    59: invokevirtual   javafx/scene/layout/AnchorPane.setMaxHeight:(D)V
        //    62: aload_0        
        //    63: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    66: ldc2_w          1000.0
        //    69: invokevirtual   javafx/scene/layout/AnchorPane.setPrefWidth:(D)V
        //    72: aload_0        
        //    73: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    76: ldc2_w          -1.0
        //    79: invokevirtual   javafx/scene/layout/AnchorPane.setMinWidth:(D)V
        //    82: aload_0        
        //    83: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //    86: ldc_w           -2023458660
        //    89: sipush          -13094
        //    92: i2c            
        //    93: ineg           
        //    94: iadd           
        //    95: ldc_w           2023458660
        //    98: sipush          -29156
        //   101: i2c            
        //   102: iadd           
        //   103: lload_2        
        //   104: l2i            
        //   105: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   108: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   111: invokevirtual   javafx/scene/layout/AnchorPane.setStyle:(Ljava/lang/String;)V
        //   114: aload_0        
        //   115: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //   118: ldc_w           -2023458660
        //   121: sipush          -13070
        //   124: i2c            
        //   125: ineg           
        //   126: iadd           
        //   127: ldc_w           -2023458660
        //   130: sipush          -32666
        //   133: i2c            
        //   134: ineg           
        //   135: iadd           
        //   136: lload_2        
        //   137: l2i            
        //   138: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   141: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   144: invokevirtual   javafx/scene/layout/AnchorPane.setId:(Ljava/lang/String;)V
        //   147: aload_0        
        //   148: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //   151: ldc2_w          -1.0
        //   154: invokevirtual   javafx/scene/layout/AnchorPane.setMaxWidth:(D)V
        //   157: aload_0        
        //   158: new             Ljavafx/scene/layout/AnchorPane;
        //   161: dup            
        //   162: invokespecial   javafx/scene/layout/AnchorPane.<init>:()V
        //   165: putfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   168: aload_0        
        //   169: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   172: ldc2_w          600.0
        //   175: invokevirtual   javafx/scene/layout/AnchorPane.setPrefHeight:(D)V
        //   178: aload_0        
        //   179: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   182: ldc2_w          400.0
        //   185: invokevirtual   javafx/scene/layout/AnchorPane.setPrefWidth:(D)V
        //   188: aload_0        
        //   189: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   192: ldc_w           -2023458660
        //   195: sipush          -13060
        //   198: i2c            
        //   199: ineg           
        //   200: iadd           
        //   201: ldc_w           2023458660
        //   204: sipush          -3708
        //   207: i2c            
        //   208: iadd           
        //   209: lload_2        
        //   210: l2i            
        //   211: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   214: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   217: invokevirtual   javafx/scene/layout/AnchorPane.setStyle:(Ljava/lang/String;)V
        //   220: aload_0        
        //   221: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //   224: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //   227: aload_0        
        //   228: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   231: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   236: pop            
        //   237: aload_0        
        //   238: new             Ljavafx/scene/image/ImageView;
        //   241: dup            
        //   242: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //   245: putfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   248: aload_0        
        //   249: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   252: ldc_w           -2023458660
        //   255: sipush          -13077
        //   258: i2c            
        //   259: ineg           
        //   260: iadd           
        //   261: ldc_w           -2023458660
        //   264: sipush          -31044
        //   267: i2c            
        //   268: ineg           
        //   269: iadd           
        //   270: lload_2        
        //   271: l2i            
        //   272: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   275: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //   278: invokevirtual   javafx/scene/image/ImageView.setCursor:(Ljavafx/scene/Cursor;)V
        //   281: aload_0        
        //   282: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   285: new             Ljavafx/scene/image/Image;
        //   288: dup            
        //   289: ldc_w           -2023458660
        //   292: sipush          -13079
        //   295: i2c            
        //   296: ineg           
        //   297: iadd           
        //   298: ldc_w           -2023458660
        //   301: sipush          -9624
        //   304: i2c            
        //   305: ineg           
        //   306: iadd           
        //   307: lload_2        
        //   308: l2i            
        //   309: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   312: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //   315: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //   318: aload_0        
        //   319: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   322: iconst_1       
        //   323: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //   326: aload_0        
        //   327: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   330: ldc2_w          75.0
        //   333: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //   336: aload_0        
        //   337: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   340: iconst_1       
        //   341: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //   344: aload_0        
        //   345: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   348: ldc2_w          40.0
        //   351: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //   354: aload_0        
        //   355: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   358: ldc_w           -2023458660
        //   361: sipush          -13050
        //   364: i2c            
        //   365: ineg           
        //   366: iadd           
        //   367: ldc_w           2023458660
        //   370: sipush          -27301
        //   373: i2c            
        //   374: iadd           
        //   375: lload_2        
        //   376: l2i            
        //   377: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   380: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   383: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //   386: aload_0        
        //   387: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   390: ldc2_w          55.0
        //   393: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //   396: aload_0        
        //   397: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   400: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //   403: aload_0        
        //   404: getfield        cr/riselauncher/scopes/b.e:Ljavafx/scene/image/ImageView;
        //   407: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   412: pop            
        //   413: aload_0        
        //   414: new             Ljavafx/scene/shape/Rectangle;
        //   417: dup            
        //   418: invokespecial   javafx/scene/shape/Rectangle.<init>:()V
        //   421: putfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   424: aload_0        
        //   425: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   428: dconst_0       
        //   429: invokevirtual   javafx/scene/shape/Rectangle.setStrokeWidth:(D)V
        //   432: aload_0        
        //   433: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   436: ldc_w           -2023458660
        //   439: sipush          -13031
        //   442: i2c            
        //   443: ineg           
        //   444: iadd           
        //   445: ldc_w           2023458660
        //   448: sipush          -11962
        //   451: i2c            
        //   452: iadd           
        //   453: lload_2        
        //   454: l2i            
        //   455: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   458: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //   461: invokevirtual   javafx/scene/shape/Rectangle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //   464: aload_0        
        //   465: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   468: ldc2_w          6.0
        //   471: invokevirtual   javafx/scene/shape/Rectangle.setWidth:(D)V
        //   474: aload_0        
        //   475: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   478: ldc2_w          496.0
        //   481: invokevirtual   javafx/scene/shape/Rectangle.setLayoutY:(D)V
        //   484: aload_0        
        //   485: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   488: ldc_w           -2023458660
        //   491: sipush          -13095
        //   494: i2c            
        //   495: ineg           
        //   496: iadd           
        //   497: ldc_w           2023458660
        //   500: sipush          -24431
        //   503: i2c            
        //   504: iadd           
        //   505: lload_2        
        //   506: l2i            
        //   507: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   510: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //   513: invokevirtual   javafx/scene/shape/Rectangle.setFill:(Ljavafx/scene/paint/Paint;)V
        //   516: aload_0        
        //   517: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   520: ldc_w           -2023458660
        //   523: sipush          -13051
        //   526: i2c            
        //   527: ineg           
        //   528: iadd           
        //   529: ldc_w           2023458660
        //   532: sipush          32096
        //   535: iadd           
        //   536: lload_2        
        //   537: l2i            
        //   538: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   541: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //   544: invokevirtual   javafx/scene/shape/Rectangle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //   547: aload_0        
        //   548: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   551: ldc2_w          75.0
        //   554: invokevirtual   javafx/scene/shape/Rectangle.setHeight:(D)V
        //   557: aload_0        
        //   558: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   561: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //   564: aload_0        
        //   565: getfield        cr/riselauncher/scopes/b.k:Ljavafx/scene/shape/Rectangle;
        //   568: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   573: pop            
        //   574: aload_0        
        //   575: new             Ljavafx/scene/image/ImageView;
        //   578: dup            
        //   579: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //   582: putfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   585: aload_0        
        //   586: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   589: iconst_1       
        //   590: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //   593: aload_0        
        //   594: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   597: new             Ljavafx/scene/image/Image;
        //   600: dup            
        //   601: ldc_w           -2023458660
        //   604: sipush          -13064
        //   607: i2c            
        //   608: ineg           
        //   609: iadd           
        //   610: ldc_w           -2023458660
        //   613: sipush          -7295
        //   616: i2c            
        //   617: ineg           
        //   618: iadd           
        //   619: lload_2        
        //   620: l2i            
        //   621: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   624: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //   627: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //   630: aload_0        
        //   631: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   634: iconst_1       
        //   635: invokevirtual   javafx/scene/image/ImageView.setVisible:(Z)V
        //   638: aload_0        
        //   639: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   642: ldc2_w          60.0
        //   645: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //   648: aload_0        
        //   649: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   652: ldc2_w          60.0
        //   655: invokevirtual   javafx/scene/image/ImageView.setFitHeight:(D)V
        //   658: aload_0        
        //   659: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   662: iconst_1       
        //   663: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //   666: aload_0        
        //   667: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   670: ldc2_w          40.0
        //   673: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //   676: aload_0        
        //   677: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   680: ldc_w           -2023458660
        //   683: sipush          -13084
        //   686: i2c            
        //   687: ineg           
        //   688: iadd           
        //   689: ldc_w           -2023458660
        //   692: sipush          -27009
        //   695: i2c            
        //   696: ineg           
        //   697: iadd           
        //   698: lload_2        
        //   699: l2i            
        //   700: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   703: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   706: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //   709: aload_0        
        //   710: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   713: ldc2_w          504.0
        //   716: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //   719: aload_0        
        //   720: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   723: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //   726: aload_0        
        //   727: getfield        cr/riselauncher/scopes/b.m:Ljavafx/scene/image/ImageView;
        //   730: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   735: pop            
        //   736: aload_0        
        //   737: new             Ljavafx/scene/shape/Circle;
        //   740: dup            
        //   741: invokespecial   javafx/scene/shape/Circle.<init>:()V
        //   744: putfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   747: aload_0        
        //   748: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   751: ldc2_w          8.0
        //   754: invokevirtual   javafx/scene/shape/Circle.setStrokeWidth:(D)V
        //   757: aload_0        
        //   758: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   761: ldc_w           -2023458660
        //   764: sipush          -13078
        //   767: i2c            
        //   768: ineg           
        //   769: iadd           
        //   770: ldc_w           -2023458660
        //   773: sipush          -15925
        //   776: i2c            
        //   777: ineg           
        //   778: iadd           
        //   779: lload_2        
        //   780: l2i            
        //   781: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   784: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //   787: invokevirtual   javafx/scene/shape/Circle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //   790: aload_0        
        //   791: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   794: ldc2_w          70.0
        //   797: invokevirtual   javafx/scene/shape/Circle.setLayoutX:(D)V
        //   800: aload_0        
        //   801: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   804: ldc2_w          534.0
        //   807: invokevirtual   javafx/scene/shape/Circle.setLayoutY:(D)V
        //   810: aload_0        
        //   811: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   814: ldc_w           -2023458660
        //   817: sipush          -13036
        //   820: i2c            
        //   821: ineg           
        //   822: iadd           
        //   823: ldc_w           2023458660
        //   826: sipush          -9051
        //   829: i2c            
        //   830: iadd           
        //   831: lload_2        
        //   832: l2i            
        //   833: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   836: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //   839: invokevirtual   javafx/scene/shape/Circle.setFill:(Ljavafx/scene/paint/Paint;)V
        //   842: aload_0        
        //   843: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   846: ldc2_w          30.0
        //   849: invokevirtual   javafx/scene/shape/Circle.setRadius:(D)V
        //   852: aload_0        
        //   853: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   856: ldc_w           -2023458660
        //   859: sipush          -13091
        //   862: i2c            
        //   863: ineg           
        //   864: iadd           
        //   865: ldc_w           2023458660
        //   868: sipush          -7906
        //   871: i2c            
        //   872: iadd           
        //   873: lload_2        
        //   874: l2i            
        //   875: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   878: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //   881: invokevirtual   javafx/scene/shape/Circle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //   884: aload_0        
        //   885: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //   888: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //   891: aload_0        
        //   892: getfield        cr/riselauncher/scopes/b.o:Ljavafx/scene/shape/Circle;
        //   895: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //   900: pop            
        //   901: aload_0        
        //   902: new             Ljavafx/scene/shape/Circle;
        //   905: dup            
        //   906: invokespecial   javafx/scene/shape/Circle.<init>:()V
        //   909: putfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   912: aload_0        
        //   913: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   916: ldc2_w          20.0
        //   919: invokevirtual   javafx/scene/shape/Circle.setStrokeWidth:(D)V
        //   922: aload_0        
        //   923: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   926: ldc_w           -2023458660
        //   929: sipush          -13044
        //   932: i2c            
        //   933: ineg           
        //   934: iadd           
        //   935: ldc_w           2023458660
        //   938: sipush          -25496
        //   941: i2c            
        //   942: iadd           
        //   943: lload_2        
        //   944: l2i            
        //   945: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //   948: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //   951: invokevirtual   javafx/scene/shape/Circle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //   954: aload_0        
        //   955: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   958: ldc2_w          70.0
        //   961: invokevirtual   javafx/scene/shape/Circle.setLayoutX:(D)V
        //   964: aload_0        
        //   965: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   968: ldc2_w          534.0
        //   971: invokevirtual   javafx/scene/shape/Circle.setLayoutY:(D)V
        //   974: aload_0        
        //   975: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //   978: ldc_w           -2023458660
        //   981: sipush          -13040
        //   984: i2c            
        //   985: ineg           
        //   986: iadd           
        //   987: ldc_w           2023458660
        //   990: sipush          -25977
        //   993: i2c            
        //   994: iadd           
        //   995: lload_2        
        //   996: l2i            
        //   997: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1000: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1003: invokevirtual   javafx/scene/shape/Circle.setFill:(Ljavafx/scene/paint/Paint;)V
        //  1006: aload_0        
        //  1007: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //  1010: ldc2_w          36.0
        //  1013: invokevirtual   javafx/scene/shape/Circle.setRadius:(D)V
        //  1016: aload_0        
        //  1017: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //  1020: ldc_w           -2023458660
        //  1023: sipush          -13053
        //  1026: i2c            
        //  1027: ineg           
        //  1028: iadd           
        //  1029: ldc_w           2023458660
        //  1032: sipush          -23580
        //  1035: i2c            
        //  1036: iadd           
        //  1037: lload_2        
        //  1038: l2i            
        //  1039: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1042: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1045: invokevirtual   javafx/scene/shape/Circle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //  1048: aload_0        
        //  1049: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  1052: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1055: aload_0        
        //  1056: getfield        cr/riselauncher/scopes/b.s:Ljavafx/scene/shape/Circle;
        //  1059: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1064: pop            
        //  1065: aload_0        
        //  1066: new             Ljavafx/scene/shape/Rectangle;
        //  1069: dup            
        //  1070: invokespecial   javafx/scene/shape/Rectangle.<init>:()V
        //  1073: putfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1076: aload_0        
        //  1077: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1080: dconst_0       
        //  1081: invokevirtual   javafx/scene/shape/Rectangle.setStrokeWidth:(D)V
        //  1084: aload_0        
        //  1085: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1088: ldc_w           -2023458660
        //  1091: sipush          -13037
        //  1094: i2c            
        //  1095: ineg           
        //  1096: iadd           
        //  1097: ldc_w           2023458660
        //  1100: sipush          -23862
        //  1103: i2c            
        //  1104: iadd           
        //  1105: lload_2        
        //  1106: l2i            
        //  1107: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1110: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  1113: invokevirtual   javafx/scene/shape/Rectangle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  1116: aload_0        
        //  1117: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1120: ldc2_w          340.0
        //  1123: invokevirtual   javafx/scene/shape/Rectangle.setWidth:(D)V
        //  1126: aload_0        
        //  1127: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1130: ldc2_w          32.0
        //  1133: invokevirtual   javafx/scene/shape/Rectangle.setLayoutX:(D)V
        //  1136: aload_0        
        //  1137: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1140: ldc2_w          594.0
        //  1143: invokevirtual   javafx/scene/shape/Rectangle.setLayoutY:(D)V
        //  1146: aload_0        
        //  1147: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1150: ldc_w           -2023458660
        //  1153: sipush          -13091
        //  1156: i2c            
        //  1157: ineg           
        //  1158: iadd           
        //  1159: ldc_w           2023458660
        //  1162: sipush          -7906
        //  1165: i2c            
        //  1166: iadd           
        //  1167: lload_2        
        //  1168: l2i            
        //  1169: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1172: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1175: invokevirtual   javafx/scene/shape/Rectangle.setFill:(Ljavafx/scene/paint/Paint;)V
        //  1178: aload_0        
        //  1179: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1182: ldc_w           -2023458660
        //  1185: sipush          -13083
        //  1188: i2c            
        //  1189: ineg           
        //  1190: iadd           
        //  1191: ldc_w           -2023458660
        //  1194: sipush          -29247
        //  1197: i2c            
        //  1198: ineg           
        //  1199: iadd           
        //  1200: lload_2        
        //  1201: l2i            
        //  1202: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1205: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1208: invokevirtual   javafx/scene/shape/Rectangle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //  1211: aload_0        
        //  1212: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1215: ldc2_w          6.0
        //  1218: invokevirtual   javafx/scene/shape/Rectangle.setHeight:(D)V
        //  1221: aload_0        
        //  1222: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  1225: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1228: aload_0        
        //  1229: getfield        cr/riselauncher/scopes/b.r:Ljavafx/scene/shape/Rectangle;
        //  1232: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1237: pop            
        //  1238: aload_0        
        //  1239: new             Ljavafx/scene/text/Text;
        //  1242: dup            
        //  1243: invokespecial   javafx/scene/text/Text.<init>:()V
        //  1246: putfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1249: aload_0        
        //  1250: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1253: dconst_0       
        //  1254: invokevirtual   javafx/scene/text/Text.setStrokeWidth:(D)V
        //  1257: aload_0        
        //  1258: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1261: ldc_w           -2023458660
        //  1264: sipush          -13044
        //  1267: i2c            
        //  1268: ineg           
        //  1269: iadd           
        //  1270: ldc_w           2023458660
        //  1273: sipush          -25496
        //  1276: i2c            
        //  1277: iadd           
        //  1278: lload_2        
        //  1279: l2i            
        //  1280: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1283: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  1286: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  1289: aload_0        
        //  1290: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1293: ldc2_w          140.0
        //  1296: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //  1299: aload_0        
        //  1300: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1303: ldc_w           -2023458660
        //  1306: sipush          -13065
        //  1309: i2c            
        //  1310: ineg           
        //  1311: iadd           
        //  1312: ldc_w           2023458660
        //  1315: sipush          -10771
        //  1318: i2c            
        //  1319: iadd           
        //  1320: lload_2        
        //  1321: l2i            
        //  1322: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1325: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1328: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //  1331: aload_0        
        //  1332: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1335: ldc2_w          85.0
        //  1338: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //  1341: aload_0        
        //  1342: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1345: ldc_w           -2023458660
        //  1348: sipush          -13056
        //  1351: i2c            
        //  1352: ineg           
        //  1353: iadd           
        //  1354: ldc_w           2023458660
        //  1357: sipush          -12491
        //  1360: i2c            
        //  1361: iadd           
        //  1362: lload_2        
        //  1363: l2i            
        //  1364: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1367: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1370: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //  1373: aload_0        
        //  1374: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1377: ldc_w           -2023458660
        //  1380: sipush          -13035
        //  1383: i2c            
        //  1384: ineg           
        //  1385: iadd           
        //  1386: ldc_w           2023458660
        //  1389: sipush          -9310
        //  1392: i2c            
        //  1393: iadd           
        //  1394: lload_2        
        //  1395: l2i            
        //  1396: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1399: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1402: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //  1405: aload_0        
        //  1406: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1409: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //  1412: ldc_w           -2023458660
        //  1415: sipush          -13062
        //  1418: i2c            
        //  1419: ineg           
        //  1420: iadd           
        //  1421: ldc_w           -2023458660
        //  1424: sipush          -17181
        //  1427: i2c            
        //  1428: ineg           
        //  1429: iadd           
        //  1430: lload_2        
        //  1431: l2i            
        //  1432: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1435: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1440: pop            
        //  1441: aload_0        
        //  1442: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  1445: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1448: aload_0        
        //  1449: getfield        cr/riselauncher/scopes/b.t:Ljavafx/scene/text/Text;
        //  1452: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1457: pop            
        //  1458: aload_0        
        //  1459: new             Ljavafx/scene/text/Text;
        //  1462: dup            
        //  1463: invokespecial   javafx/scene/text/Text.<init>:()V
        //  1466: putfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1469: aload_0        
        //  1470: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1473: ldc_w           -2023458660
        //  1476: sipush          -13037
        //  1479: i2c            
        //  1480: ineg           
        //  1481: iadd           
        //  1482: ldc_w           2023458660
        //  1485: sipush          -23862
        //  1488: i2c            
        //  1489: iadd           
        //  1490: lload_2        
        //  1491: l2i            
        //  1492: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1495: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  1498: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  1501: aload_0        
        //  1502: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1505: ldc2_w          140.0
        //  1508: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //  1511: aload_0        
        //  1512: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1515: ldc_w           -2023458660
        //  1518: sipush          -13073
        //  1521: i2c            
        //  1522: ineg           
        //  1523: iadd           
        //  1524: ldc_w           2023458660
        //  1527: sipush          31587
        //  1530: iadd           
        //  1531: lload_2        
        //  1532: l2i            
        //  1533: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1536: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1539: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //  1542: aload_0        
        //  1543: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1546: ldc2_w          125.0
        //  1549: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //  1552: aload_0        
        //  1553: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1556: aload           6
        //  1558: ldc_w           -2023458660
        //  1561: sipush          -13085
        //  1564: i2c            
        //  1565: ineg           
        //  1566: iadd           
        //  1567: ldc_w           -2023458660
        //  1570: sipush          -28988
        //  1573: i2c            
        //  1574: ineg           
        //  1575: iadd           
        //  1576: lload_2        
        //  1577: l2i            
        //  1578: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1581: iconst_1       
        //  1582: anewarray       Ljava/lang/Object;
        //  1585: dup_x1         
        //  1586: swap           
        //  1587: iconst_0       
        //  1588: swap           
        //  1589: aastore        
        //  1590: invokevirtual   invokevirtual  !!! ERROR
        //  1593: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1596: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //  1599: aload_0        
        //  1600: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1603: ldc_w           -2023458660
        //  1606: sipush          -13041
        //  1609: i2c            
        //  1610: ineg           
        //  1611: iadd           
        //  1612: ldc_w           2023458660
        //  1615: sipush          -32577
        //  1618: i2c            
        //  1619: iadd           
        //  1620: lload_2        
        //  1621: l2i            
        //  1622: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1625: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1628: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //  1631: aload_0        
        //  1632: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1635: ldc_w           -2023458660
        //  1638: sipush          -13041
        //  1641: i2c            
        //  1642: ineg           
        //  1643: iadd           
        //  1644: ldc_w           2023458660
        //  1647: sipush          -32577
        //  1650: i2c            
        //  1651: iadd           
        //  1652: lload_2        
        //  1653: l2i            
        //  1654: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1657: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1660: invokevirtual   javafx/scene/text/Text.setStroke:(Ljavafx/scene/paint/Paint;)V
        //  1663: aload_0        
        //  1664: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1667: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //  1670: ldc_w           -2023458660
        //  1673: sipush          -13092
        //  1676: i2c            
        //  1677: ineg           
        //  1678: iadd           
        //  1679: ldc_w           -2023458660
        //  1682: sipush          -12158
        //  1685: i2c            
        //  1686: ineg           
        //  1687: iadd           
        //  1688: lload_2        
        //  1689: l2i            
        //  1690: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1693: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1698: pop            
        //  1699: aload_0        
        //  1700: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  1703: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1706: aload_0        
        //  1707: getfield        cr/riselauncher/scopes/b.a:Ljavafx/scene/text/Text;
        //  1710: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1715: pop            
        //  1716: aload_0        
        //  1717: new             Ljavafx/scene/text/Text;
        //  1720: dup            
        //  1721: invokespecial   javafx/scene/text/Text.<init>:()V
        //  1724: putfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1727: aload_0        
        //  1728: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1731: ldc_w           -2023458660
        //  1734: sipush          -13029
        //  1737: i2c            
        //  1738: ineg           
        //  1739: iadd           
        //  1740: ldc_w           -2023458660
        //  1743: sipush          -30914
        //  1746: iadd           
        //  1747: lload_2        
        //  1748: l2i            
        //  1749: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1752: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  1755: invokevirtual   javafx/scene/text/Text.setCursor:(Ljavafx/scene/Cursor;)V
        //  1758: aload_0        
        //  1759: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1762: dconst_0       
        //  1763: invokevirtual   javafx/scene/text/Text.setStrokeWidth:(D)V
        //  1766: aload_0        
        //  1767: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1770: ldc_w           -2023458660
        //  1773: sipush          -13044
        //  1776: i2c            
        //  1777: ineg           
        //  1778: iadd           
        //  1779: ldc_w           2023458660
        //  1782: sipush          -25496
        //  1785: i2c            
        //  1786: iadd           
        //  1787: lload_2        
        //  1788: l2i            
        //  1789: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1792: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  1795: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  1798: aload_0        
        //  1799: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1802: ldc2_w          130.0
        //  1805: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //  1808: aload_0        
        //  1809: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1812: ldc_w           -2023458660
        //  1815: sipush          -13067
        //  1818: i2c            
        //  1819: ineg           
        //  1820: iadd           
        //  1821: ldc_w           2023458660
        //  1824: sipush          -15273
        //  1827: i2c            
        //  1828: iadd           
        //  1829: lload_2        
        //  1830: l2i            
        //  1831: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1834: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1837: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //  1840: aload_0        
        //  1841: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1844: ldc_w           -2023458660
        //  1847: sipush          -13048
        //  1850: i2c            
        //  1851: ineg           
        //  1852: iadd           
        //  1853: ldc_w           2023458660
        //  1856: sipush          -29893
        //  1859: i2c            
        //  1860: iadd           
        //  1861: lload_2        
        //  1862: l2i            
        //  1863: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1866: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1869: invokevirtual   javafx/scene/text/Text.setId:(Ljava/lang/String;)V
        //  1872: aload_0        
        //  1873: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1876: ldc2_w          539.0
        //  1879: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //  1882: aload_0        
        //  1883: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1886: ldc_w           -2023458660
        //  1889: sipush          -13046
        //  1892: i2c            
        //  1893: ineg           
        //  1894: iadd           
        //  1895: ldc_w           -2023458660
        //  1898: sipush          -14873
        //  1901: i2c            
        //  1902: ineg           
        //  1903: iadd           
        //  1904: lload_2        
        //  1905: l2i            
        //  1906: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1909: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  1912: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //  1915: aload_0        
        //  1916: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1919: ldc_w           -2023458660
        //  1922: sipush          -13041
        //  1925: i2c            
        //  1926: ineg           
        //  1927: iadd           
        //  1928: ldc_w           2023458660
        //  1931: sipush          -32577
        //  1934: i2c            
        //  1935: iadd           
        //  1936: lload_2        
        //  1937: l2i            
        //  1938: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1941: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  1944: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //  1947: aload_0        
        //  1948: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1951: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //  1954: ldc_w           -2023458660
        //  1957: sipush          -13088
        //  1960: i2c            
        //  1961: ineg           
        //  1962: iadd           
        //  1963: ldc_w           2023458660
        //  1966: sipush          -21313
        //  1969: i2c            
        //  1970: iadd           
        //  1971: lload_2        
        //  1972: l2i            
        //  1973: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  1976: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1981: pop            
        //  1982: aload_0        
        //  1983: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  1986: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  1989: aload_0        
        //  1990: getfield        cr/riselauncher/scopes/b.f:Ljavafx/scene/text/Text;
        //  1993: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  1998: pop            
        //  1999: aload_0        
        //  2000: new             Ljavafx/scene/image/ImageView;
        //  2003: dup            
        //  2004: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //  2007: putfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2010: aload_0        
        //  2011: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2014: ldc_w           -2023458660
        //  2017: sipush          -13029
        //  2020: i2c            
        //  2021: ineg           
        //  2022: iadd           
        //  2023: ldc_w           -2023458660
        //  2026: sipush          -30914
        //  2029: iadd           
        //  2030: lload_2        
        //  2031: l2i            
        //  2032: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2035: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  2038: invokevirtual   javafx/scene/image/ImageView.setCursor:(Ljavafx/scene/Cursor;)V
        //  2041: aload_0        
        //  2042: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2045: new             Ljavafx/scene/image/Image;
        //  2048: dup            
        //  2049: ldc_w           -2023458660
        //  2052: sipush          -13028
        //  2055: i2c            
        //  2056: ineg           
        //  2057: iadd           
        //  2058: ldc_w           2023458660
        //  2061: sipush          -13734
        //  2064: i2c            
        //  2065: iadd           
        //  2066: lload_2        
        //  2067: l2i            
        //  2068: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2071: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //  2074: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //  2077: aload_0        
        //  2078: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2081: iconst_1       
        //  2082: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //  2085: aload_0        
        //  2086: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2089: iconst_1       
        //  2090: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //  2093: aload_0        
        //  2094: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2097: ldc2_w          290.0
        //  2100: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //  2103: aload_0        
        //  2104: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2107: ldc_w           -2023458660
        //  2110: sipush          -13068
        //  2113: i2c            
        //  2114: ineg           
        //  2115: iadd           
        //  2116: ldc_w           2023458660
        //  2119: sipush          -19388
        //  2122: i2c            
        //  2123: iadd           
        //  2124: lload_2        
        //  2125: l2i            
        //  2126: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2129: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  2132: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //  2135: aload_0        
        //  2136: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2139: ldc2_w          520.0
        //  2142: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //  2145: aload_0        
        //  2146: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  2149: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2152: aload_0        
        //  2153: getfield        cr/riselauncher/scopes/b.n:Ljavafx/scene/image/ImageView;
        //  2156: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2161: pop            
        //  2162: aload_0        
        //  2163: new             Ljavafx/scene/image/ImageView;
        //  2166: dup            
        //  2167: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //  2170: putfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2173: aload_0        
        //  2174: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2177: ldc_w           -2023458660
        //  2180: sipush          -13029
        //  2183: i2c            
        //  2184: ineg           
        //  2185: iadd           
        //  2186: ldc_w           -2023458660
        //  2189: sipush          -30914
        //  2192: iadd           
        //  2193: lload_2        
        //  2194: l2i            
        //  2195: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2198: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  2201: invokevirtual   javafx/scene/image/ImageView.setCursor:(Ljavafx/scene/Cursor;)V
        //  2204: aload_0        
        //  2205: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2208: new             Ljavafx/scene/image/Image;
        //  2211: dup            
        //  2212: ldc_w           -2023458660
        //  2215: sipush          -13057
        //  2218: i2c            
        //  2219: ineg           
        //  2220: iadd           
        //  2221: ldc_w           2023458660
        //  2224: sipush          -13036
        //  2227: i2c            
        //  2228: iadd           
        //  2229: lload_2        
        //  2230: l2i            
        //  2231: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2234: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //  2237: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //  2240: aload_0        
        //  2241: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2244: iconst_1       
        //  2245: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //  2248: aload_0        
        //  2249: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2252: iconst_1       
        //  2253: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //  2256: getstatic       cr/riselauncher/scopes/c.j:Z
        //  2259: aload_0        
        //  2260: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2263: ldc2_w          325.0
        //  2266: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //  2269: aload_0        
        //  2270: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2273: ldc_w           -2023458660
        //  2276: sipush          -13066
        //  2279: i2c            
        //  2280: ineg           
        //  2281: iadd           
        //  2282: ldc_w           -2023458660
        //  2285: sipush          -8795
        //  2288: i2c            
        //  2289: ineg           
        //  2290: iadd           
        //  2291: lload_2        
        //  2292: l2i            
        //  2293: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2296: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  2299: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //  2302: aload_0        
        //  2303: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2306: ldc2_w          523.0
        //  2309: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //  2312: aload_0        
        //  2313: getfield        cr/riselauncher/scopes/b.j:Ljavafx/scene/layout/AnchorPane;
        //  2316: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2319: aload_0        
        //  2320: getfield        cr/riselauncher/scopes/b.q:Ljavafx/scene/image/ImageView;
        //  2323: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2328: pop            
        //  2329: new             Ljavafx/scene/media/Media;
        //  2332: dup            
        //  2333: aload_0        
        //  2334: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  2337: invokevirtual   java/lang/Class.getClassLoader:()Ljava/lang/ClassLoader;
        //  2340: ldc_w           -2023458660
        //  2343: sipush          -13045
        //  2346: i2c            
        //  2347: ineg           
        //  2348: iadd           
        //  2349: ldc_w           -2023458660
        //  2352: sipush          -31298
        //  2355: i2c            
        //  2356: ineg           
        //  2357: iadd           
        //  2358: lload_2        
        //  2359: l2i            
        //  2360: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2363: invokevirtual   java/lang/ClassLoader.getResource:(Ljava/lang/String;)Ljava/net/URL;
        //  2366: invokevirtual   java/net/URL.toString:()Ljava/lang/String;
        //  2369: invokespecial   javafx/scene/media/Media.<init>:(Ljava/lang/String;)V
        //  2372: astore          7
        //  2374: new             Ljavafx/scene/media/MediaPlayer;
        //  2377: dup            
        //  2378: aload           7
        //  2380: invokespecial   javafx/scene/media/MediaPlayer.<init>:(Ljavafx/scene/media/Media;)V
        //  2383: astore          8
        //  2385: aload           8
        //  2387: iconst_1       
        //  2388: invokevirtual   javafx/scene/media/MediaPlayer.setAutoPlay:(Z)V
        //  2391: aload           8
        //  2393: iconst_m1      
        //  2394: invokevirtual   javafx/scene/media/MediaPlayer.setCycleCount:(I)V
        //  2397: aload           8
        //  2399: invokevirtual   javafx/scene/media/MediaPlayer.play:()V
        //  2402: new             Ljavafx/scene/media/MediaView;
        //  2405: dup            
        //  2406: aload           8
        //  2408: invokespecial   javafx/scene/media/MediaView.<init>:(Ljavafx/scene/media/MediaPlayer;)V
        //  2411: astore          9
        //  2413: aload           9
        //  2415: ldc2_w          600.0
        //  2418: invokevirtual   javafx/scene/media/MediaView.setFitHeight:(D)V
        //  2421: aload           9
        //  2423: iconst_1       
        //  2424: invokevirtual   javafx/scene/media/MediaView.setPreserveRatio:(Z)V
        //  2427: new             Ljavafx/scene/layout/StackPane;
        //  2430: dup            
        //  2431: invokespecial   javafx/scene/layout/StackPane.<init>:()V
        //  2434: astore          10
        //  2436: aload           10
        //  2438: iconst_1       
        //  2439: invokevirtual   javafx/scene/layout/StackPane.setPickOnBounds:(Z)V
        //  2442: aload           10
        //  2444: ldc2_w          600.0
        //  2447: invokevirtual   javafx/scene/layout/StackPane.setPrefWidth:(D)V
        //  2450: aload           10
        //  2452: ldc2_w          600.0
        //  2455: invokevirtual   javafx/scene/layout/StackPane.setPrefHeight:(D)V
        //  2458: aload           10
        //  2460: ldc2_w          400.0
        //  2463: invokevirtual   javafx/scene/layout/StackPane.setLayoutX:(D)V
        //  2466: aload           10
        //  2468: invokevirtual   javafx/scene/layout/StackPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2471: aload           9
        //  2473: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2478: pop            
        //  2479: aload_0        
        //  2480: new             Ljavafx/scene/image/ImageView;
        //  2483: dup            
        //  2484: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //  2487: putfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2490: aload_0        
        //  2491: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2494: new             Ljavafx/scene/image/Image;
        //  2497: dup            
        //  2498: ldc_w           -2023458660
        //  2501: sipush          -13074
        //  2504: i2c            
        //  2505: ineg           
        //  2506: iadd           
        //  2507: ldc_w           -2023458660
        //  2510: sipush          -8283
        //  2513: i2c            
        //  2514: ineg           
        //  2515: iadd           
        //  2516: lload_2        
        //  2517: l2i            
        //  2518: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2521: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //  2524: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //  2527: aload_0        
        //  2528: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2531: iconst_1       
        //  2532: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //  2535: aload_0        
        //  2536: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2539: ldc2_w          600.0
        //  2542: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //  2545: aload_0        
        //  2546: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2549: ldc2_w          600.0
        //  2552: invokevirtual   javafx/scene/image/ImageView.setFitHeight:(D)V
        //  2555: aload_0        
        //  2556: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2559: iconst_1       
        //  2560: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //  2563: aload_0        
        //  2564: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2567: ldc2_w          400.0
        //  2570: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //  2573: aload_0        
        //  2574: getfield        cr/riselauncher/scopes/b.i:Ljavafx/scene/image/ImageView;
        //  2577: ldc_w           -2023458660
        //  2580: sipush          -13058
        //  2583: i2c            
        //  2584: ineg           
        //  2585: iadd           
        //  2586: ldc_w           2023458660
        //  2589: sipush          -16457
        //  2592: i2c            
        //  2593: iadd           
        //  2594: lload_2        
        //  2595: l2i            
        //  2596: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2599: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  2602: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //  2605: aload_0        
        //  2606: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  2609: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2612: aload           10
        //  2614: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2619: pop            
        //  2620: aload           8
        //  2622: invokevirtual   javafx/scene/media/MediaPlayer.play:()V
        //  2625: aload_0        
        //  2626: new             Ljavafx/scene/image/ImageView;
        //  2629: dup            
        //  2630: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //  2633: putfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2636: aload_0        
        //  2637: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2640: ldc_w           -2023458660
        //  2643: sipush          -13029
        //  2646: i2c            
        //  2647: ineg           
        //  2648: iadd           
        //  2649: ldc_w           -2023458660
        //  2652: sipush          -30914
        //  2655: iadd           
        //  2656: lload_2        
        //  2657: l2i            
        //  2658: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2661: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  2664: invokevirtual   javafx/scene/image/ImageView.setCursor:(Ljavafx/scene/Cursor;)V
        //  2667: aload_0        
        //  2668: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2671: new             Ljavafx/scene/image/Image;
        //  2674: dup            
        //  2675: ldc_w           -2023458660
        //  2678: sipush          -13055
        //  2681: i2c            
        //  2682: ineg           
        //  2683: iadd           
        //  2684: ldc_w           2023458660
        //  2687: sipush          -10236
        //  2690: i2c            
        //  2691: iadd           
        //  2692: lload_2        
        //  2693: l2i            
        //  2694: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2697: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //  2700: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //  2703: aload_0        
        //  2704: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2707: iconst_1       
        //  2708: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //  2711: aload_0        
        //  2712: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2715: ldc2_w          15.0
        //  2718: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //  2721: aload_0        
        //  2722: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2725: ldc2_w          15.0
        //  2728: invokevirtual   javafx/scene/image/ImageView.setFitHeight:(D)V
        //  2731: aload_0        
        //  2732: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2735: iconst_1       
        //  2736: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //  2739: aload_0        
        //  2740: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2743: ldc2_w          970.0
        //  2746: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //  2749: aload_0        
        //  2750: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2753: ldc_w           -2023458660
        //  2756: sipush          -13038
        //  2759: i2c            
        //  2760: ineg           
        //  2761: iadd           
        //  2762: ldc_w           -2023458660
        //  2765: sipush          -17216
        //  2768: i2c            
        //  2769: ineg           
        //  2770: iadd           
        //  2771: lload_2        
        //  2772: l2i            
        //  2773: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2776: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  2779: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //  2782: aload_0        
        //  2783: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2786: ldc2_w          15.0
        //  2789: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //  2792: aload_0        
        //  2793: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  2796: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2799: aload_0        
        //  2800: getfield        cr/riselauncher/scopes/b.d:Ljavafx/scene/image/ImageView;
        //  2803: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2808: pop            
        //  2809: aload_0        
        //  2810: new             Ljavafx/scene/image/ImageView;
        //  2813: dup            
        //  2814: invokespecial   javafx/scene/image/ImageView.<init>:()V
        //  2817: putfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2820: aload_0        
        //  2821: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2824: ldc_w           -2023458660
        //  2827: sipush          -13029
        //  2830: i2c            
        //  2831: ineg           
        //  2832: iadd           
        //  2833: ldc_w           -2023458660
        //  2836: sipush          -30914
        //  2839: iadd           
        //  2840: lload_2        
        //  2841: l2i            
        //  2842: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2845: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  2848: invokevirtual   javafx/scene/image/ImageView.setCursor:(Ljavafx/scene/Cursor;)V
        //  2851: aload_0        
        //  2852: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2855: new             Ljavafx/scene/image/Image;
        //  2858: dup            
        //  2859: ldc_w           -2023458660
        //  2862: sipush          -13075
        //  2865: i2c            
        //  2866: ineg           
        //  2867: iadd           
        //  2868: ldc_w           2023458660
        //  2871: sipush          -27238
        //  2874: i2c            
        //  2875: iadd           
        //  2876: lload_2        
        //  2877: l2i            
        //  2878: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2881: invokespecial   javafx/scene/image/Image.<init>:(Ljava/lang/String;)V
        //  2884: invokevirtual   javafx/scene/image/ImageView.setImage:(Ljavafx/scene/image/Image;)V
        //  2887: aload_0        
        //  2888: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2891: iconst_1       
        //  2892: invokevirtual   javafx/scene/image/ImageView.setPickOnBounds:(Z)V
        //  2895: aload_0        
        //  2896: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2899: ldc2_w          709.0
        //  2902: invokevirtual   javafx/scene/image/ImageView.setFitWidth:(D)V
        //  2905: aload_0        
        //  2906: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2909: ldc2_w          74.0
        //  2912: invokevirtual   javafx/scene/image/ImageView.setFitHeight:(D)V
        //  2915: aload_0        
        //  2916: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2919: iconst_1       
        //  2920: invokevirtual   javafx/scene/image/ImageView.setPreserveRatio:(Z)V
        //  2923: aload_0        
        //  2924: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2927: ldc2_w          883.0
        //  2930: invokevirtual   javafx/scene/image/ImageView.setLayoutX:(D)V
        //  2933: aload_0        
        //  2934: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2937: ldc_w           -2023458660
        //  2940: sipush          -13072
        //  2943: i2c            
        //  2944: ineg           
        //  2945: iadd           
        //  2946: ldc_w           -2023458660
        //  2949: sipush          -19235
        //  2952: i2c            
        //  2953: ineg           
        //  2954: iadd           
        //  2955: lload_2        
        //  2956: l2i            
        //  2957: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  2960: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  2963: invokevirtual   javafx/scene/image/ImageView.setId:(Ljava/lang/String;)V
        //  2966: aload_0        
        //  2967: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2970: ldc2_w          491.0
        //  2973: invokevirtual   javafx/scene/image/ImageView.setLayoutY:(D)V
        //  2976: aload_0        
        //  2977: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  2980: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  2983: aload_0        
        //  2984: getfield        cr/riselauncher/scopes/b.c:Ljavafx/scene/image/ImageView;
        //  2987: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  2992: pop            
        //  2993: aload_0        
        //  2994: new             Ljavafx/scene/shape/Rectangle;
        //  2997: dup            
        //  2998: invokespecial   javafx/scene/shape/Rectangle.<init>:()V
        //  3001: putfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3004: aload_0        
        //  3005: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3008: dconst_0       
        //  3009: invokevirtual   javafx/scene/shape/Rectangle.setStrokeWidth:(D)V
        //  3012: aload_0        
        //  3013: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3016: ldc_w           -2023458660
        //  3019: sipush          -13037
        //  3022: i2c            
        //  3023: ineg           
        //  3024: iadd           
        //  3025: ldc_w           2023458660
        //  3028: sipush          -23862
        //  3031: i2c            
        //  3032: iadd           
        //  3033: lload_2        
        //  3034: l2i            
        //  3035: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3038: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  3041: invokevirtual   javafx/scene/shape/Rectangle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  3044: aload_0        
        //  3045: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3048: ldc2_w          200.0
        //  3051: invokevirtual   javafx/scene/shape/Rectangle.setWidth:(D)V
        //  3054: aload_0        
        //  3055: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3058: ldc2_w          770.0
        //  3061: invokevirtual   javafx/scene/shape/Rectangle.setLayoutX:(D)V
        //  3064: aload_0        
        //  3065: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3068: ldc2_w          594.0
        //  3071: invokevirtual   javafx/scene/shape/Rectangle.setLayoutY:(D)V
        //  3074: aload_0        
        //  3075: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3078: ldc_w           -2023458660
        //  3081: sipush          -13091
        //  3084: i2c            
        //  3085: ineg           
        //  3086: iadd           
        //  3087: ldc_w           2023458660
        //  3090: sipush          -7906
        //  3093: i2c            
        //  3094: iadd           
        //  3095: lload_2        
        //  3096: l2i            
        //  3097: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3100: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3103: invokevirtual   javafx/scene/shape/Rectangle.setFill:(Ljavafx/scene/paint/Paint;)V
        //  3106: aload_0        
        //  3107: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3110: ldc_w           -2023458660
        //  3113: sipush          -13083
        //  3116: i2c            
        //  3117: ineg           
        //  3118: iadd           
        //  3119: ldc_w           -2023458660
        //  3122: sipush          -29247
        //  3125: i2c            
        //  3126: ineg           
        //  3127: iadd           
        //  3128: lload_2        
        //  3129: l2i            
        //  3130: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3133: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3136: invokevirtual   javafx/scene/shape/Rectangle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //  3139: aload_0        
        //  3140: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3143: ldc2_w          6.0
        //  3146: invokevirtual   javafx/scene/shape/Rectangle.setHeight:(D)V
        //  3149: aload_0        
        //  3150: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  3153: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  3156: aload_0        
        //  3157: getfield        cr/riselauncher/scopes/b.l:Ljavafx/scene/shape/Rectangle;
        //  3160: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3165: pop            
        //  3166: aload_0        
        //  3167: new             Ljavafx/scene/text/Text;
        //  3170: dup            
        //  3171: invokespecial   javafx/scene/text/Text.<init>:()V
        //  3174: putfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3177: aload_0        
        //  3178: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3181: getstatic       javafx/scene/text/TextAlignment.CENTER:Ljavafx/scene/text/TextAlignment;
        //  3184: invokevirtual   javafx/scene/text/Text.setTextAlignment:(Ljavafx/scene/text/TextAlignment;)V
        //  3187: aload_0        
        //  3188: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3191: ldc_w           -2023458660
        //  3194: sipush          -13029
        //  3197: i2c            
        //  3198: ineg           
        //  3199: iadd           
        //  3200: ldc_w           -2023458660
        //  3203: sipush          -30914
        //  3206: iadd           
        //  3207: lload_2        
        //  3208: l2i            
        //  3209: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3212: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  3215: invokevirtual   javafx/scene/text/Text.setCursor:(Ljavafx/scene/Cursor;)V
        //  3218: aload_0        
        //  3219: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3222: dconst_0       
        //  3223: invokevirtual   javafx/scene/text/Text.setStrokeWidth:(D)V
        //  3226: aload_0        
        //  3227: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3230: ldc_w           -2023458660
        //  3233: sipush          -13044
        //  3236: i2c            
        //  3237: ineg           
        //  3238: iadd           
        //  3239: ldc_w           2023458660
        //  3242: sipush          -25496
        //  3245: i2c            
        //  3246: iadd           
        //  3247: lload_2        
        //  3248: l2i            
        //  3249: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3252: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  3255: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  3258: aload_0        
        //  3259: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3262: ldc_w           -2023458660
        //  3265: sipush          -13059
        //  3268: i2c            
        //  3269: ineg           
        //  3270: iadd           
        //  3271: ldc_w           -2023458660
        //  3274: sipush          -8667
        //  3277: i2c            
        //  3278: ineg           
        //  3279: iadd           
        //  3280: lload_2        
        //  3281: l2i            
        //  3282: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3285: invokestatic    javafx/scene/text/TextAlignment.valueOf:(Ljava/lang/String;)Ljavafx/scene/text/TextAlignment;
        //  3288: invokevirtual   javafx/scene/text/Text.setTextAlignment:(Ljavafx/scene/text/TextAlignment;)V
        //  3291: aload_0        
        //  3292: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3295: ldc2_w          770.0
        //  3298: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //  3301: aload_0        
        //  3302: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3305: ldc_w           -2023458660
        //  3308: sipush          -13073
        //  3311: i2c            
        //  3312: ineg           
        //  3313: iadd           
        //  3314: ldc_w           2023458660
        //  3317: sipush          31587
        //  3320: iadd           
        //  3321: lload_2        
        //  3322: l2i            
        //  3323: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3326: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  3329: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //  3332: aload_0        
        //  3333: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3336: ldc_w           -2023458660
        //  3339: sipush          -13080
        //  3342: i2c            
        //  3343: ineg           
        //  3344: iadd           
        //  3345: ldc_w           -2023458660
        //  3348: sipush          -10686
        //  3351: i2c            
        //  3352: ineg           
        //  3353: iadd           
        //  3354: lload_2        
        //  3355: l2i            
        //  3356: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3359: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  3362: invokevirtual   javafx/scene/text/Text.setId:(Ljava/lang/String;)V
        //  3365: aload_0        
        //  3366: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3369: ldc2_w          536.0
        //  3372: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //  3375: aload_0        
        //  3376: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3379: aload           6
        //  3381: ldc_w           -2023458660
        //  3384: sipush          -13069
        //  3387: i2c            
        //  3388: ineg           
        //  3389: iadd           
        //  3390: ldc_w           2023458660
        //  3393: sipush          -24261
        //  3396: i2c            
        //  3397: iadd           
        //  3398: lload_2        
        //  3399: l2i            
        //  3400: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3403: iconst_1       
        //  3404: anewarray       Ljava/lang/Object;
        //  3407: dup_x1         
        //  3408: swap           
        //  3409: iconst_0       
        //  3410: swap           
        //  3411: aastore        
        //  3412: invokevirtual   invokevirtual  !!! ERROR
        //  3415: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  3418: invokevirtual   javafx/scene/text/Text.setText:(Ljava/lang/String;)V
        //  3421: aload_0        
        //  3422: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3425: ldc_w           -2023458660
        //  3428: sipush          -13041
        //  3431: i2c            
        //  3432: ineg           
        //  3433: iadd           
        //  3434: ldc_w           2023458660
        //  3437: sipush          -32577
        //  3440: i2c            
        //  3441: iadd           
        //  3442: lload_2        
        //  3443: l2i            
        //  3444: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3447: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3450: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //  3453: aload_0        
        //  3454: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3457: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //  3460: ldc_w           -2023458660
        //  3463: sipush          -13086
        //  3466: i2c            
        //  3467: ineg           
        //  3468: iadd           
        //  3469: ldc_w           2023458660
        //  3472: sipush          -5698
        //  3475: i2c            
        //  3476: iadd           
        //  3477: lload_2        
        //  3478: l2i            
        //  3479: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3482: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3487: pop            
        //  3488: aload_0        
        //  3489: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  3492: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  3495: aload_0        
        //  3496: getfield        cr/riselauncher/scopes/b.g:Ljavafx/scene/text/Text;
        //  3499: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3504: pop            
        //  3505: istore          4
        //  3507: aload_0        
        //  3508: new             Ljavafx/scene/text/Text;
        //  3511: dup            
        //  3512: invokespecial   javafx/scene/text/Text.<init>:()V
        //  3515: putfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3518: aload_0        
        //  3519: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3522: getstatic       javafx/scene/text/TextAlignment.CENTER:Ljavafx/scene/text/TextAlignment;
        //  3525: invokevirtual   javafx/scene/text/Text.setTextAlignment:(Ljavafx/scene/text/TextAlignment;)V
        //  3528: aload_0        
        //  3529: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3532: ldc_w           -2023458660
        //  3535: sipush          -13029
        //  3538: i2c            
        //  3539: ineg           
        //  3540: iadd           
        //  3541: ldc_w           -2023458660
        //  3544: sipush          -30914
        //  3547: iadd           
        //  3548: lload_2        
        //  3549: l2i            
        //  3550: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3553: invokestatic    javafx/scene/Cursor.cursor:(Ljava/lang/String;)Ljavafx/scene/Cursor;
        //  3556: invokevirtual   javafx/scene/text/Text.setCursor:(Ljavafx/scene/Cursor;)V
        //  3559: aload_0        
        //  3560: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3563: dconst_0       
        //  3564: invokevirtual   javafx/scene/text/Text.setStrokeWidth:(D)V
        //  3567: aload_0        
        //  3568: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3571: ldc_w           -2023458660
        //  3574: sipush          -13044
        //  3577: i2c            
        //  3578: ineg           
        //  3579: iadd           
        //  3580: ldc_w           2023458660
        //  3583: sipush          -25496
        //  3586: i2c            
        //  3587: iadd           
        //  3588: lload_2        
        //  3589: l2i            
        //  3590: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3593: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  3596: invokevirtual   javafx/scene/text/Text.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  3599: aload_0        
        //  3600: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3603: ldc_w           -2023458660
        //  3606: sipush          -13089
        //  3609: i2c            
        //  3610: ineg           
        //  3611: iadd           
        //  3612: ldc_w           2023458660
        //  3615: sipush          -9359
        //  3618: i2c            
        //  3619: iadd           
        //  3620: lload_2        
        //  3621: l2i            
        //  3622: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3625: invokestatic    javafx/scene/text/TextAlignment.valueOf:(Ljava/lang/String;)Ljavafx/scene/text/TextAlignment;
        //  3628: invokevirtual   javafx/scene/text/Text.setTextAlignment:(Ljavafx/scene/text/TextAlignment;)V
        //  3631: aload_0        
        //  3632: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3635: ldc2_w          770.0
        //  3638: invokevirtual   javafx/scene/text/Text.setLayoutX:(D)V
        //  3641: aload_0        
        //  3642: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3645: ldc_w           -2023458660
        //  3648: sipush          -13071
        //  3651: i2c            
        //  3652: ineg           
        //  3653: iadd           
        //  3654: ldc_w           -2023458660
        //  3657: sipush          -31231
        //  3660: iadd           
        //  3661: lload_2        
        //  3662: l2i            
        //  3663: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3666: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  3669: invokevirtual   javafx/scene/text/Text.setStyle:(Ljava/lang/String;)V
        //  3672: aload_0        
        //  3673: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3676: ldc_w           -2023458660
        //  3679: sipush          -13063
        //  3682: i2c            
        //  3683: ineg           
        //  3684: iadd           
        //  3685: ldc_w           2023458660
        //  3688: sipush          -22904
        //  3691: i2c            
        //  3692: iadd           
        //  3693: lload_2        
        //  3694: l2i            
        //  3695: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3698: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  3701: invokevirtual   javafx/scene/text/Text.setId:(Ljava/lang/String;)V
        //  3704: aload_0        
        //  3705: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3708: ldc2_w          560.0
        //  3711: invokevirtual   javafx/scene/text/Text.setLayoutY:(D)V
        //  3714: aload_0        
        //  3715: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3718: ldc_w           -2023458660
        //  3721: sipush          -13041
        //  3724: i2c            
        //  3725: ineg           
        //  3726: iadd           
        //  3727: ldc_w           2023458660
        //  3730: sipush          -32577
        //  3733: i2c            
        //  3734: iadd           
        //  3735: lload_2        
        //  3736: l2i            
        //  3737: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3740: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3743: invokevirtual   javafx/scene/text/Text.setFill:(Ljavafx/scene/paint/Paint;)V
        //  3746: aload_0        
        //  3747: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3750: invokevirtual   javafx/scene/text/Text.getStyleClass:()Ljavafx/collections/ObservableList;
        //  3753: ldc_w           -2023458660
        //  3756: sipush          -13093
        //  3759: i2c            
        //  3760: ineg           
        //  3761: iadd           
        //  3762: ldc_w           -2023458660
        //  3765: sipush          -17927
        //  3768: i2c            
        //  3769: ineg           
        //  3770: iadd           
        //  3771: lload_2        
        //  3772: l2i            
        //  3773: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3776: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3781: pop            
        //  3782: aload_0        
        //  3783: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  3786: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  3789: aload_0        
        //  3790: getfield        cr/riselauncher/scopes/b.v:Ljavafx/scene/text/Text;
        //  3793: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3798: pop            
        //  3799: aload_0        
        //  3800: new             Ljavafx/scene/shape/Rectangle;
        //  3803: dup            
        //  3804: invokespecial   javafx/scene/shape/Rectangle.<init>:()V
        //  3807: putfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3810: aload_0        
        //  3811: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3814: dconst_0       
        //  3815: invokevirtual   javafx/scene/shape/Rectangle.setStrokeWidth:(D)V
        //  3818: aload_0        
        //  3819: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3822: ldc_w           -2023458660
        //  3825: sipush          -13037
        //  3828: i2c            
        //  3829: ineg           
        //  3830: iadd           
        //  3831: ldc_w           2023458660
        //  3834: sipush          -23862
        //  3837: i2c            
        //  3838: iadd           
        //  3839: lload_2        
        //  3840: l2i            
        //  3841: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3844: invokestatic    javafx/scene/shape/StrokeType.valueOf:(Ljava/lang/String;)Ljavafx/scene/shape/StrokeType;
        //  3847: invokevirtual   javafx/scene/shape/Rectangle.setStrokeType:(Ljavafx/scene/shape/StrokeType;)V
        //  3850: aload_0        
        //  3851: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3854: ldc2_w          6.0
        //  3857: invokevirtual   javafx/scene/shape/Rectangle.setWidth:(D)V
        //  3860: aload_0        
        //  3861: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3864: ldc2_w          994.0
        //  3867: invokevirtual   javafx/scene/shape/Rectangle.setLayoutX:(D)V
        //  3870: aload_0        
        //  3871: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3874: ldc2_w          491.0
        //  3877: invokevirtual   javafx/scene/shape/Rectangle.setLayoutY:(D)V
        //  3880: aload_0        
        //  3881: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3884: ldc_w           -2023458660
        //  3887: sipush          -13091
        //  3890: i2c            
        //  3891: ineg           
        //  3892: iadd           
        //  3893: ldc_w           2023458660
        //  3896: sipush          -7906
        //  3899: i2c            
        //  3900: iadd           
        //  3901: lload_2        
        //  3902: l2i            
        //  3903: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3906: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3909: invokevirtual   javafx/scene/shape/Rectangle.setFill:(Ljavafx/scene/paint/Paint;)V
        //  3912: aload_0        
        //  3913: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3916: ldc_w           -2023458660
        //  3919: sipush          -13083
        //  3922: i2c            
        //  3923: ineg           
        //  3924: iadd           
        //  3925: ldc_w           -2023458660
        //  3928: sipush          -29247
        //  3931: i2c            
        //  3932: ineg           
        //  3933: iadd           
        //  3934: lload_2        
        //  3935: l2i            
        //  3936: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  3939: invokestatic    javafx/scene/paint/Paint.valueOf:(Ljava/lang/String;)Ljavafx/scene/paint/Paint;
        //  3942: invokevirtual   javafx/scene/shape/Rectangle.setStroke:(Ljavafx/scene/paint/Paint;)V
        //  3945: aload_0        
        //  3946: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3949: ldc2_w          75.0
        //  3952: invokevirtual   javafx/scene/shape/Rectangle.setHeight:(D)V
        //  3955: aload_0        
        //  3956: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  3959: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  3962: aload_0        
        //  3963: getfield        cr/riselauncher/scopes/b.u:Ljavafx/scene/shape/Rectangle;
        //  3966: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  3971: pop            
        //  3972: aload_0        
        //  3973: new             Ljavafx/scene/control/ProgressIndicator;
        //  3976: dup            
        //  3977: invokespecial   javafx/scene/control/ProgressIndicator.<init>:()V
        //  3980: putfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  3983: aload_0        
        //  3984: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  3987: ldc2_w          70.0
        //  3990: invokevirtual   javafx/scene/control/ProgressIndicator.setPrefHeight:(D)V
        //  3993: aload_0        
        //  3994: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  3997: iconst_0       
        //  3998: invokevirtual   javafx/scene/control/ProgressIndicator.setVisible:(Z)V
        //  4001: aload_0        
        //  4002: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  4005: ldc2_w          70.0
        //  4008: invokevirtual   javafx/scene/control/ProgressIndicator.setPrefWidth:(D)V
        //  4011: aload_0        
        //  4012: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  4015: ldc2_w          885.0
        //  4018: invokevirtual   javafx/scene/control/ProgressIndicator.setLayoutX:(D)V
        //  4021: aload_0        
        //  4022: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  4025: ldc_w           -2023458660
        //  4028: sipush          -13042
        //  4031: i2c            
        //  4032: ineg           
        //  4033: iadd           
        //  4034: ldc_w           -2023458660
        //  4037: sipush          -32292
        //  4040: iadd           
        //  4041: lload_2        
        //  4042: l2i            
        //  4043: invokestatic    cr/riselauncher/scopes/b.a:(III)Ljava/lang/String;
        //  4046: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //  4049: invokevirtual   javafx/scene/control/ProgressIndicator.setId:(Ljava/lang/String;)V
        //  4052: aload_0        
        //  4053: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  4056: ldc2_w          493.0
        //  4059: invokevirtual   javafx/scene/control/ProgressIndicator.setLayoutY:(D)V
        //  4062: aload_0        
        //  4063: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  4066: invokevirtual   javafx/scene/layout/AnchorPane.getChildren:()Ljavafx/collections/ObservableList;
        //  4069: aload_0        
        //  4070: getfield        cr/riselauncher/scopes/b.h:Ljavafx/scene/control/ProgressIndicator;
        //  4073: invokeinterface javafx/collections/ObservableList.add:(Ljava/lang/Object;)Z
        //  4078: pop            
        //  4079: aload_0        
        //  4080: getfield        cr/riselauncher/scopes/b.p:Ljavafx/scene/layout/AnchorPane;
        //  4083: iload           4
        //  4085: ifeq            4101
        //  4088: getstatic       cr/application/RiseApplication.b:I
        //  4091: istore          5
        //  4093: iinc            5, 1
        //  4096: iload           5
        //  4098: putstatic       cr/application/RiseApplication.b:I
        //  4101: areturn        
        //    StackMapTable: 00 01 FF 10 05 00 0A 07 00 02 07 00 63 04 01 00 07 00 41 07 02 02 07 02 1A 07 02 29 07 02 30 00 01 07 01 31
        // 
        // The error that occurred was:
        // 
        // java.lang.reflect.GenericSignatureFormatError
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.error(SignatureParser.java:70)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseSimpleClassTypeSignature(SignatureParser.java:224)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseClassTypeSignature(SignatureParser.java:194)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFieldTypeSignature(SignatureParser.java:173)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseTypeSignature(SignatureParser.java:327)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseZeroOrMoreTypeSignatures(SignatureParser.java:444)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseFormalParameters(SignatureParser.java:419)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodTypeSignature(SignatureParser.java:407)
        //     at com.strobel.assembler.metadata.signatures.SignatureParser.parseMethodSignature(SignatureParser.java:88)
        //     at com.strobel.assembler.metadata.MetadataParser.parseMethodSignature(MetadataParser.java:234)
        //     at com.strobel.assembler.metadata.ClassFileReader.defineMethods(ClassFileReader.java:895)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:441)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] x2 = new String[68];
        int n = 0;
        String s;
        int n2 = (s = "\u00cd\u0017\u0087\u008fb\u00fa\u00c6µ\u00f5\u0093\f¡\u00c8\u008d\u00e9\u0094T:\u00e2b \u0002+-\u00f5G\u0004m¤¢¬\u000e\u0080\u0007\u00d1:\u0083t\u0000O\u00e0\u00d2\u0091\u00cc\u00f6\u00d0\u0006\u00c6\u00dc\u00eb@\u00fb\u009c\u000e\u0012#\u0083¾\u00c9\u00e4I]\u00c9\u0090´\u0084R\u00d8\"\u00db%\u0088\u008d5\u00c6\u0084n:\u00e8\u000bq\u00f0I¯\u00d7\u0007\u0185\u0088\u0107\u00f0\r¥\t\u00c1\u0107\t\u00da\u014a¦_\u000b\u0104\u000bS\u001d²\u00fd\u00ef½AJ~\u00fd\u0084\u00c5\u009c[{7v\u008b\u0088\u00c2W\u01b9\u00cek\u00fd:ie\u001a.\u0005\u01fe\u0019ª{T¼\\\u00f3\u00d1\u00ce\u00e4qP_\u00d0»\u01e8\u00ea\u0084\u00fdG\u00cc\u0181»¶O)7\u008dw\u00f4s\u00d8nI¢£\u00feZ.\u00d3\u00cc\u00d4\u00cd\u0098¨P«R\u00f3\u008bH\u008d\u0005¢½ ·\u00ca\u000be\u00997t#\u00ecG\u000fJ³\u00e1\u0006^º\u00f8\u008c\u0099\u0005\u0005\u00dd\u00f2\u00db\u00d9g\u000e\u00e38\u008f.\u00d5±\u0080\u01fc¿C~¼^@\u000b\u0094\u008f\t¶\u00e4´¿\u0004U\u00d2\u0002\u0005\u00e3v\u0088\u00ce\u00cf\u0007I7©\u0015\u00ea\u0095!\u0006¦\u015cS\u00e3\u00f2»\u0007R\u0082¸\u00e9{\u00f1\u0015\u0018\u009acm\u0001?+m\u0090\u0084\u00ce¤¥\u009fF\u0003\u00e4\u0014\fXª³\u009ag§\fT¿4\u00ca-rk\u009b\u00f0!(\u000f\u001f\u0012\u00f2\u0091s2\u001e\\\u012c \u0100\u0089\u0083¤\u0081\u0016\u007f\u001ao½\u00c3,\u000f\u00ce \u0089J\u00e3\u008eBc\"\ni32\u00eb\u0095\u00e8j\u00de-\u00f3\b}£\u0087\u00c6/\b\u0010®\u0004f[J\u0093\u0005m\u00e0\u00e6\u008f\u0005\\\u00f7>\u00f6\u00f6\u00042L\u01a4\u001f\u00ec¢\u0090\u00f2\u00da\u00edk\u009cm\u00c4\\k\u008fK¦\u0095YBxy\u00d6\u00f7 X\u001bj2\u01eb\u0087\u0010V_¢»\u00f2\u00dc&\u000f\"\u008e¢\u00d3½>\u0001\u00c5RU»)\u0092·«;A S\u00ea\u0004±(\u0090t\u00d0\u00c6\u00cdM\u00c7j\u00e1\u0131{\u01fb]S\u00edr»\u0000)w\u00e9\u0090\u0007B5=\u00f5\u001aIZ\u000eJ-\u0088\u007f¨\u00dceZLp\u0004\u0098D\\\u0017=\u00ff\u0099\u0092¡Y¾\u00c1\u00fa\u001d\u00edp\u00f4·~\u00da¯\u00dc\u00e9\u0019\u00db8\u00e8\b\u00f03\u008eT\u0096\u00f4\u00e3\u0013\u0018\u00fcE¡\u00c5¦³^\u009c\u00e6¶n\u0005\u0084\u0019\u007f\fiy(h¯\u0019\u00fa:\tr«»A\u001d\u0019\u00f2\u0095\u00d8\u0005\u00c3®'\u00e8\u00e4\u001e\u000e\u000e1S\u00c82\u000b\u00fe\u0083«\u0081\u00c7m\u0018½\u0002P6\u001c\u00e4d\u001eX\u00d5k\u0007\u009a\u00f9\u008b\u00fa\u0004\u0006f(\u00ea\r¾0\u001a\u00f2_\u00d9:\u00e0b(¾¼\u0080\b}¡°¹\u00f4µg\u0095\u0018%N\u009a¤\u00c1\u009f²\u0019{\u0006\u00dd\u0013\u00f2\u00db¾Rªx\u00fe\u00d4O½\u00e6®\u0012\u0012\u00de²I¼\u007f\f\u0087\u0085yD³\u0018&t\u0000\u009a{\u00062\u00cd\u00c0A\u001do\u0012C\u00d7\u0098h\u00f9[¤\u0003\u0090\u00e9\u00e6¡Ld\u00feI\u00cbs\b\u0086\u00fe¹w_\u00cb\u00977\u0004\u00e5¡T\u0012\t\u00d6\u0003sV\u0082»Y\u0096F\u0012·B\u0006\u00da*\r\u00de\u00c9\u00df°\u000f\u008aq\u0001Y\u00e67\u00e5\u0004K\fv\f\u0012\u0082K \u00fb\u00fe)DM\u008c e\u0098<C\u00f0¬\n\u00ee\u001b\u00c4\u001e¦®F\u00deB1e\u0003\u001e³\u008a\u00cf¥\u00d8A/B\u00d4\u0019,¥b\u00ed2\u0015\u0016\u00e6q\u00e2C\u00cecS\u0086G\u00f5Zm\u0002\u0014³®iXµ\u009cl\u0014\u0005\u0125\u00e8\u00c6\u0013±\u0004a\u0090#*\u0007\u00cc\u0096kk\u0001¡Z\u001c]r\u0095# o\u008e\u0007\u00fc\u00c5-k\u00ec\u00d4w¹\u00c5C\u00ec\r\"\u00cf\u00df\u00d8:Ysm\b\u001c\u001b\u009c\u00eeq_\u00d7\u00c8\b\r\u009b\u00c8\u00dbq^R\u0085\u0004\u0013D\u00cb¾\u0005\u00e68\u0097\u0094+\nOK\u00f6\u00e4\r\t\u007f\u00e6Eq\bdC¤\u00daK\u008b\u009c\u00de\u000e\u000b~¬;\u0089\u00e0\u00e0\u00c79\u00cc\u00d6-\u00e9\u00dc\u0004\u00d2|O²\u000e\u00c2\u007f\u0095\u001b®\u00e4\u0004G¥\u00d2@'\u0095D\u0005(aZ\u0011K\u000e\u00ea\u0011\u009c\u00f8*,5DF³E\u00e0lV\u0007\u00ee\u00cd\u00feQ¯\u0018\u0091\r\u00f6(\u0013\u00f1~¹\u001e\u00ec\u00e6¿)\u009f\u009f\u000e\u0086)\u001d\u00d1¿½&l\u00e1·\u00c8\u008b\u0084\u00d1").length();
        int n3 = 26;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n5 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    int length;
                    int n7;
                    final int n6 = n7 = (length = charArray.length);
                    int n8 = 0;
                    while (true) {
                        Label_0252: {
                            if (n6 > 1) {
                                break Label_0252;
                            }
                            length = (n7 = n8);
                            do {
                                final char c = charArray[n7];
                                char c2 = '\0';
                                switch (n8 % 7) {
                                    case 0: {
                                        c2 = 'x';
                                        break;
                                    }
                                    case 1: {
                                        c2 = '\t';
                                        break;
                                    }
                                    case 2: {
                                        c2 = '\u000f';
                                        break;
                                    }
                                    case 3: {
                                        c2 = '4';
                                        break;
                                    }
                                    case 4: {
                                        c2 = '\u001a';
                                        break;
                                    }
                                    case 5: {
                                        c2 = '7';
                                        break;
                                    }
                                    default: {
                                        c2 = '\u001c';
                                        break;
                                    }
                                }
                                charArray[length] = (char)(c ^ c2);
                                ++n8;
                            } while (n6 == 0);
                        }
                        if (n6 > n8) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n5) {
                        default: {
                            x2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = ">\u00017²\b\u000e\u0013y\u0080[\u00e1\u00d9a\u00db<z`9\u001a\u0005¤\"@Rl\u00f7\u00fa\u00e7\u00079\u0007@;+\u008f\u0015\u00c3\u00c6").length();
                            n3 = 30;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            x2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n5 = 0;
                }
            }
            break;
        }
        x = x2;
        y = new String[68];
    }
    
    private static String a(final int n, int n2, final int n3) {
        final int n4 = (n ^ n3 ^ 0xFFFFF548) & 0xFFFF;
        if (b.y[n4] == null) {
            final char[] charArray = b.x[n4].toCharArray();
            int n5 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n5 = 247;
                    break;
                }
                case 1: {
                    n5 = 20;
                    break;
                }
                case 2: {
                    n5 = 123;
                    break;
                }
                case 3: {
                    n5 = 74;
                    break;
                }
                case 4: {
                    n5 = 42;
                    break;
                }
                case 5: {
                    n5 = 175;
                    break;
                }
                case 6: {
                    n5 = 150;
                    break;
                }
                case 7: {
                    n5 = 170;
                    break;
                }
                case 8: {
                    n5 = 69;
                    break;
                }
                case 9: {
                    n5 = 249;
                    break;
                }
                case 10: {
                    n5 = 86;
                    break;
                }
                case 11: {
                    n5 = 54;
                    break;
                }
                case 12: {
                    n5 = 57;
                    break;
                }
                case 13: {
                    n5 = 37;
                    break;
                }
                case 14: {
                    n5 = 16;
                    break;
                }
                case 15: {
                    n5 = 182;
                    break;
                }
                case 16: {
                    n5 = 51;
                    break;
                }
                case 17: {
                    n5 = 246;
                    break;
                }
                case 18: {
                    n5 = 194;
                    break;
                }
                case 19: {
                    n5 = 236;
                    break;
                }
                case 20: {
                    n5 = 75;
                    break;
                }
                case 21: {
                    n5 = 181;
                    break;
                }
                case 22: {
                    n5 = 13;
                    break;
                }
                case 23: {
                    n5 = 168;
                    break;
                }
                case 24: {
                    n5 = 243;
                    break;
                }
                case 25: {
                    n5 = 215;
                    break;
                }
                case 26: {
                    n5 = 177;
                    break;
                }
                case 27: {
                    n5 = 90;
                    break;
                }
                case 28: {
                    n5 = 179;
                    break;
                }
                case 29: {
                    n5 = 88;
                    break;
                }
                case 30: {
                    n5 = 5;
                    break;
                }
                case 31: {
                    n5 = 29;
                    break;
                }
                case 32: {
                    n5 = 40;
                    break;
                }
                case 33: {
                    n5 = 10;
                    break;
                }
                case 34: {
                    n5 = 250;
                    break;
                }
                case 35: {
                    n5 = 111;
                    break;
                }
                case 36: {
                    n5 = 169;
                    break;
                }
                case 37: {
                    n5 = 184;
                    break;
                }
                case 38: {
                    n5 = 119;
                    break;
                }
                case 39: {
                    n5 = 192;
                    break;
                }
                case 40: {
                    n5 = 186;
                    break;
                }
                case 41: {
                    n5 = 102;
                    break;
                }
                case 42: {
                    n5 = 159;
                    break;
                }
                case 43: {
                    n5 = 49;
                    break;
                }
                case 44: {
                    n5 = 21;
                    break;
                }
                case 45: {
                    n5 = 110;
                    break;
                }
                case 46: {
                    n5 = 36;
                    break;
                }
                case 47: {
                    n5 = 89;
                    break;
                }
                case 48: {
                    n5 = 217;
                    break;
                }
                case 49: {
                    n5 = 83;
                    break;
                }
                case 50: {
                    n5 = 245;
                    break;
                }
                case 51: {
                    n5 = 52;
                    break;
                }
                case 52: {
                    n5 = 3;
                    break;
                }
                case 53: {
                    n5 = 223;
                    break;
                }
                case 54: {
                    n5 = 44;
                    break;
                }
                case 55: {
                    n5 = 142;
                    break;
                }
                case 56: {
                    n5 = 34;
                    break;
                }
                case 57: {
                    n5 = 116;
                    break;
                }
                case 58: {
                    n5 = 103;
                    break;
                }
                case 59: {
                    n5 = 93;
                    break;
                }
                case 60: {
                    n5 = 91;
                    break;
                }
                case 61: {
                    n5 = 212;
                    break;
                }
                case 62: {
                    n5 = 104;
                    break;
                }
                case 63: {
                    n5 = 39;
                    break;
                }
                case 64: {
                    n5 = 244;
                    break;
                }
                case 65: {
                    n5 = 43;
                    break;
                }
                case 66: {
                    n5 = 95;
                    break;
                }
                case 67: {
                    n5 = 185;
                    break;
                }
                case 68: {
                    n5 = 198;
                    break;
                }
                case 69: {
                    n5 = 124;
                    break;
                }
                case 70: {
                    n5 = 221;
                    break;
                }
                case 71: {
                    n5 = 255;
                    break;
                }
                case 72: {
                    n5 = 24;
                    break;
                }
                case 73: {
                    n5 = 72;
                    break;
                }
                case 74: {
                    n5 = 25;
                    break;
                }
                case 75: {
                    n5 = 188;
                    break;
                }
                case 76: {
                    n5 = 174;
                    break;
                }
                case 77: {
                    n5 = 122;
                    break;
                }
                case 78: {
                    n5 = 6;
                    break;
                }
                case 79: {
                    n5 = 144;
                    break;
                }
                case 80: {
                    n5 = 27;
                    break;
                }
                case 81: {
                    n5 = 63;
                    break;
                }
                case 82: {
                    n5 = 92;
                    break;
                }
                case 83: {
                    n5 = 161;
                    break;
                }
                case 84: {
                    n5 = 81;
                    break;
                }
                case 85: {
                    n5 = 114;
                    break;
                }
                case 86: {
                    n5 = 166;
                    break;
                }
                case 87: {
                    n5 = 231;
                    break;
                }
                case 88: {
                    n5 = 58;
                    break;
                }
                case 89: {
                    n5 = 235;
                    break;
                }
                case 90: {
                    n5 = 253;
                    break;
                }
                case 91: {
                    n5 = 202;
                    break;
                }
                case 92: {
                    n5 = 35;
                    break;
                }
                case 93: {
                    n5 = 151;
                    break;
                }
                case 94: {
                    n5 = 143;
                    break;
                }
                case 95: {
                    n5 = 193;
                    break;
                }
                case 96: {
                    n5 = 105;
                    break;
                }
                case 97: {
                    n5 = 73;
                    break;
                }
                case 98: {
                    n5 = 62;
                    break;
                }
                case 99: {
                    n5 = 171;
                    break;
                }
                case 100: {
                    n5 = 126;
                    break;
                }
                case 101: {
                    n5 = 220;
                    break;
                }
                case 102: {
                    n5 = 201;
                    break;
                }
                case 103: {
                    n5 = 68;
                    break;
                }
                case 104: {
                    n5 = 96;
                    break;
                }
                case 105: {
                    n5 = 48;
                    break;
                }
                case 106: {
                    n5 = 82;
                    break;
                }
                case 107: {
                    n5 = 70;
                    break;
                }
                case 108: {
                    n5 = 148;
                    break;
                }
                case 109: {
                    n5 = 160;
                    break;
                }
                case 110: {
                    n5 = 242;
                    break;
                }
                case 111: {
                    n5 = 130;
                    break;
                }
                case 112: {
                    n5 = 153;
                    break;
                }
                case 113: {
                    n5 = 19;
                    break;
                }
                case 114: {
                    n5 = 67;
                    break;
                }
                case 115: {
                    n5 = 213;
                    break;
                }
                case 116: {
                    n5 = 108;
                    break;
                }
                case 117: {
                    n5 = 53;
                    break;
                }
                case 118: {
                    n5 = 197;
                    break;
                }
                case 119: {
                    n5 = 154;
                    break;
                }
                case 120: {
                    n5 = 229;
                    break;
                }
                case 121: {
                    n5 = 156;
                    break;
                }
                case 122: {
                    n5 = 2;
                    break;
                }
                case 123: {
                    n5 = 71;
                    break;
                }
                case 124: {
                    n5 = 125;
                    break;
                }
                case 125: {
                    n5 = 131;
                    break;
                }
                case 126: {
                    n5 = 85;
                    break;
                }
                case 127: {
                    n5 = 61;
                    break;
                }
                case 128: {
                    n5 = 112;
                    break;
                }
                case 129: {
                    n5 = 207;
                    break;
                }
                case 130: {
                    n5 = 228;
                    break;
                }
                case 131: {
                    n5 = 135;
                    break;
                }
                case 132: {
                    n5 = 203;
                    break;
                }
                case 133: {
                    n5 = 164;
                    break;
                }
                case 134: {
                    n5 = 9;
                    break;
                }
                case 135: {
                    n5 = 173;
                    break;
                }
                case 136: {
                    n5 = 141;
                    break;
                }
                case 137: {
                    n5 = 66;
                    break;
                }
                case 138: {
                    n5 = 222;
                    break;
                }
                case 139: {
                    n5 = 132;
                    break;
                }
                case 140: {
                    n5 = 18;
                    break;
                }
                case 141: {
                    n5 = 97;
                    break;
                }
                case 142: {
                    n5 = 234;
                    break;
                }
                case 143: {
                    n5 = 180;
                    break;
                }
                case 144: {
                    n5 = 79;
                    break;
                }
                case 145: {
                    n5 = 248;
                    break;
                }
                case 146: {
                    n5 = 191;
                    break;
                }
                case 147: {
                    n5 = 136;
                    break;
                }
                case 148: {
                    n5 = 1;
                    break;
                }
                case 149: {
                    n5 = 219;
                    break;
                }
                case 150: {
                    n5 = 149;
                    break;
                }
                case 151: {
                    n5 = 121;
                    break;
                }
                case 152: {
                    n5 = 4;
                    break;
                }
                case 153: {
                    n5 = 101;
                    break;
                }
                case 154: {
                    n5 = 26;
                    break;
                }
                case 155: {
                    n5 = 31;
                    break;
                }
                case 156: {
                    n5 = 204;
                    break;
                }
                case 157: {
                    n5 = 133;
                    break;
                }
                case 158: {
                    n5 = 55;
                    break;
                }
                case 159: {
                    n5 = 183;
                    break;
                }
                case 160: {
                    n5 = 128;
                    break;
                }
                case 161: {
                    n5 = 87;
                    break;
                }
                case 162: {
                    n5 = 120;
                    break;
                }
                case 163: {
                    n5 = 17;
                    break;
                }
                case 164: {
                    n5 = 118;
                    break;
                }
                case 165: {
                    n5 = 78;
                    break;
                }
                case 166: {
                    n5 = 196;
                    break;
                }
                case 167: {
                    n5 = 224;
                    break;
                }
                case 168: {
                    n5 = 208;
                    break;
                }
                case 169: {
                    n5 = 33;
                    break;
                }
                case 170: {
                    n5 = 94;
                    break;
                }
                case 171: {
                    n5 = 28;
                    break;
                }
                case 172: {
                    n5 = 176;
                    break;
                }
                case 173: {
                    n5 = 230;
                    break;
                }
                case 174: {
                    n5 = 59;
                    break;
                }
                case 175: {
                    n5 = 146;
                    break;
                }
                case 176: {
                    n5 = 11;
                    break;
                }
                case 177: {
                    n5 = 32;
                    break;
                }
                case 178: {
                    n5 = 210;
                    break;
                }
                case 179: {
                    n5 = 145;
                    break;
                }
                case 180: {
                    n5 = 30;
                    break;
                }
                case 181: {
                    n5 = 162;
                    break;
                }
                case 182: {
                    n5 = 84;
                    break;
                }
                case 183: {
                    n5 = 140;
                    break;
                }
                case 184: {
                    n5 = 157;
                    break;
                }
                case 185: {
                    n5 = 199;
                    break;
                }
                case 186: {
                    n5 = 15;
                    break;
                }
                case 187: {
                    n5 = 214;
                    break;
                }
                case 188: {
                    n5 = 98;
                    break;
                }
                case 189: {
                    n5 = 152;
                    break;
                }
                case 190: {
                    n5 = 107;
                    break;
                }
                case 191: {
                    n5 = 237;
                    break;
                }
                case 192: {
                    n5 = 47;
                    break;
                }
                case 193: {
                    n5 = 129;
                    break;
                }
                case 194: {
                    n5 = 80;
                    break;
                }
                case 195: {
                    n5 = 127;
                    break;
                }
                case 196: {
                    n5 = 7;
                    break;
                }
                case 197: {
                    n5 = 251;
                    break;
                }
                case 198: {
                    n5 = 209;
                    break;
                }
                case 199: {
                    n5 = 77;
                    break;
                }
                case 200: {
                    n5 = 254;
                    break;
                }
                case 201: {
                    n5 = 137;
                    break;
                }
                case 202: {
                    n5 = 172;
                    break;
                }
                case 203: {
                    n5 = 12;
                    break;
                }
                case 204: {
                    n5 = 233;
                    break;
                }
                case 205: {
                    n5 = 60;
                    break;
                }
                case 206: {
                    n5 = 167;
                    break;
                }
                case 207: {
                    n5 = 115;
                    break;
                }
                case 208: {
                    n5 = 76;
                    break;
                }
                case 209: {
                    n5 = 205;
                    break;
                }
                case 210: {
                    n5 = 117;
                    break;
                }
                case 211: {
                    n5 = 225;
                    break;
                }
                case 212: {
                    n5 = 38;
                    break;
                }
                case 213: {
                    n5 = 106;
                    break;
                }
                case 214: {
                    n5 = 232;
                    break;
                }
                case 215: {
                    n5 = 100;
                    break;
                }
                case 216: {
                    n5 = 46;
                    break;
                }
                case 217: {
                    n5 = 158;
                    break;
                }
                case 218: {
                    n5 = 65;
                    break;
                }
                case 219: {
                    n5 = 200;
                    break;
                }
                case 220: {
                    n5 = 113;
                    break;
                }
                case 221: {
                    n5 = 99;
                    break;
                }
                case 222: {
                    n5 = 239;
                    break;
                }
                case 223: {
                    n5 = 195;
                    break;
                }
                case 224: {
                    n5 = 134;
                    break;
                }
                case 225: {
                    n5 = 14;
                    break;
                }
                case 226: {
                    n5 = 147;
                    break;
                }
                case 227: {
                    n5 = 155;
                    break;
                }
                case 228: {
                    n5 = 187;
                    break;
                }
                case 229: {
                    n5 = 45;
                    break;
                }
                case 230: {
                    n5 = 22;
                    break;
                }
                case 231: {
                    n5 = 218;
                    break;
                }
                case 232: {
                    n5 = 178;
                    break;
                }
                case 233: {
                    n5 = 0;
                    break;
                }
                case 234: {
                    n5 = 240;
                    break;
                }
                case 235: {
                    n5 = 41;
                    break;
                }
                case 236: {
                    n5 = 139;
                    break;
                }
                case 237: {
                    n5 = 206;
                    break;
                }
                case 238: {
                    n5 = 216;
                    break;
                }
                case 239: {
                    n5 = 238;
                    break;
                }
                case 240: {
                    n5 = 138;
                    break;
                }
                case 241: {
                    n5 = 241;
                    break;
                }
                case 242: {
                    n5 = 109;
                    break;
                }
                case 243: {
                    n5 = 165;
                    break;
                }
                case 244: {
                    n5 = 8;
                    break;
                }
                case 245: {
                    n5 = 23;
                    break;
                }
                case 246: {
                    n5 = 190;
                    break;
                }
                case 247: {
                    n5 = 227;
                    break;
                }
                case 248: {
                    n5 = 64;
                    break;
                }
                case 249: {
                    n5 = 252;
                    break;
                }
                case 250: {
                    n5 = 56;
                    break;
                }
                case 251: {
                    n5 = 189;
                    break;
                }
                case 252: {
                    n5 = 226;
                    break;
                }
                case 253: {
                    n5 = 163;
                    break;
                }
                case 254: {
                    n5 = 211;
                    break;
                }
                default: {
                    n5 = 50;
                    break;
                }
            }
            final int n6 = n5;
            int n7 = ((n2 ^= n3) & 0xFF) - n6;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            int n8 = ((n2 & 0xFFFF) >>> 8) - n6;
            if (n8 < '\0') {
                n8 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n9 = i % 2;
                final char[] array = charArray;
                final int n10 = i;
                final char c = array[n10];
                if (n9 == 0) {
                    array[n10] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n10] = (char)(c ^ n8);
                    n8 = (((n8 >>> 3 | n8 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            b.y[n4] = new String(charArray).intern();
        }
        return b.y[n4];
    }
}
