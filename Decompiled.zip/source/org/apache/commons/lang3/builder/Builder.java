// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.lang3.builder;

public interface Builder<T>
{
    T build();
}
