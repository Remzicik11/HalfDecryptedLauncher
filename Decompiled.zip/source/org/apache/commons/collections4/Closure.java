// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4;

public interface Closure<T>
{
    void execute(final T p0);
}
