// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4;

public interface Unmodifiable
{
}
