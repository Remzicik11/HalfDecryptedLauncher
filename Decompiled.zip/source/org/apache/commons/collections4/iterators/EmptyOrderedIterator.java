// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4.iterators;

import org.apache.commons.collections4.ResettableIterator;
import org.apache.commons.collections4.OrderedIterator;

public class EmptyOrderedIterator<E> extends AbstractEmptyIterator<E> implements OrderedIterator<E>, ResettableIterator<E>
{
    public static final OrderedIterator INSTANCE;
    
    public static <E> OrderedIterator<E> emptyOrderedIterator() {
        return (OrderedIterator<E>)EmptyOrderedIterator.INSTANCE;
    }
    
    protected EmptyOrderedIterator() {
    }
    
    static {
        INSTANCE = new EmptyOrderedIterator();
    }
}
