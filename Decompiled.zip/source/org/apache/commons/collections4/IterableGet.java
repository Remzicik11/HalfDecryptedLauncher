// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4;

public interface IterableGet<K, V> extends Get<K, V>
{
    MapIterator<K, V> mapIterator();
}
