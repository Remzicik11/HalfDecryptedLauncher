// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4.bag;

import org.apache.commons.collections4.set.TransformedSet;
import java.util.Set;
import java.util.Collection;
import org.apache.commons.collections4.Transformer;
import org.apache.commons.collections4.Bag;
import org.apache.commons.collections4.collection.TransformedCollection;

public class TransformedBag<E> extends TransformedCollection<E> implements Bag<E>
{
    private static final long serialVersionUID = 5421170911299074185L;
    
    public static <E> Bag<E> transformingBag(final Bag<E> bag, final Transformer<? super E, ? extends E> transformer) {
        return new TransformedBag<E>(bag, transformer);
    }
    
    public static <E> Bag<E> transformedBag(final Bag<E> bag, final Transformer<? super E, ? extends E> transformer) {
        final TransformedBag<E> decorated = new TransformedBag<E>(bag, transformer);
        if (bag.size() > 0) {
            final E[] values = (E[])bag.toArray();
            bag.clear();
            for (final E value : values) {
                decorated.decorated().add(transformer.transform((Object)value));
            }
        }
        return decorated;
    }
    
    protected TransformedBag(final Bag<E> bag, final Transformer<? super E, ? extends E> transformer) {
        super(bag, transformer);
    }
    
    protected Bag<E> getBag() {
        return (Bag<E>)(Bag)this.decorated();
    }
    
    @Override
    public boolean equals(final Object object) {
        return object == this || this.decorated().equals(object);
    }
    
    @Override
    public int hashCode() {
        return this.decorated().hashCode();
    }
    
    @Override
    public int getCount(final Object object) {
        return this.getBag().getCount(object);
    }
    
    @Override
    public boolean remove(final Object object, final int nCopies) {
        return this.getBag().remove(object, nCopies);
    }
    
    @Override
    public boolean add(final E object, final int nCopies) {
        return this.getBag().add(this.transform(object), nCopies);
    }
    
    @Override
    public Set<E> uniqueSet() {
        final Set<E> set = this.getBag().uniqueSet();
        return TransformedSet.transformingSet(set, this.transformer);
    }
}
