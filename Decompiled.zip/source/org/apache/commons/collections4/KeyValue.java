// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.collections4;

public interface KeyValue<K, V>
{
    K getKey();
    
    V getValue();
}
