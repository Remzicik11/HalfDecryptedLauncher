// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.lang.mutable;

public interface Mutable
{
    Object getValue();
    
    void setValue(final Object p0);
}
