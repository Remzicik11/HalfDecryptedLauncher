// 
// Decompiled by Procyon v0.5.36
// 

package org.hamcrest;

public interface SelfDescribing
{
    void describeTo(final Description p0);
}
