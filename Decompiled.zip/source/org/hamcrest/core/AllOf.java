// 
// Decompiled by Procyon v0.5.36
// 

package org.hamcrest.core;

import org.hamcrest.Factory;
import java.util.Arrays;
import org.hamcrest.SelfDescribing;
import org.hamcrest.Description;
import java.util.Iterator;
import org.hamcrest.Matcher;
import org.hamcrest.BaseMatcher;

public class AllOf<T> extends BaseMatcher<T>
{
    private final Iterable<Matcher<? extends T>> matchers;
    
    public AllOf(final Iterable<Matcher<? extends T>> matchers) {
        this.matchers = matchers;
    }
    
    public boolean matches(final Object o) {
        for (final Matcher<? extends T> matcher : this.matchers) {
            if (!matcher.matches(o)) {
                return false;
            }
        }
        return true;
    }
    
    public void describeTo(final Description description) {
        description.appendList("(", " and ", ")", this.matchers);
    }
    
    @Factory
    public static <T> Matcher<T> allOf(final Matcher<? extends T>... matchers) {
        return allOf((Iterable<Matcher<? extends T>>)Arrays.asList(matchers));
    }
    
    @Factory
    public static <T> Matcher<T> allOf(final Iterable<Matcher<? extends T>> matchers) {
        return new AllOf<T>(matchers);
    }
}
